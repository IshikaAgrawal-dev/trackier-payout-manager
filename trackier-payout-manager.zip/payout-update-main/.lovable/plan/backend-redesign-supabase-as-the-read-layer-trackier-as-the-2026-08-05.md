# Backend redesign: Supabase as the read layer, Trackier as the write layer

## Recommended architecture

Stop reading Trackier live from the dropdowns. Cache Trackier's campaigns, publishers and goals in the Lovable Cloud database, refresh them with a background sync, and let the UI read from the database with indexed, server-side search. Trackier stays the system of record for writes only (payouts, publisher assignment).

```text
Trackier API
   |  (sync only: scheduled every 15 min + Manual Sync button)
   v
sync-trackier edge function  --UPSERT-->  campaigns / publishers / campaign_goals
                                              |
                                     indexed search (trigram + btree)
                                              v
                                        UI dropdowns (instant)

UI write actions --> trackier-upload-payouts / campaign-publisher-action --> Trackier
                                    |
                                    +--> payout_uploads + audit_logs (unchanged)
```

## Why this and not more patching

The dropdown problems are all one root cause: every page load walks Trackier's whole paginated dataset inside a 150s edge function. Trackier's own gateway times out at scale, so results are partial and slow no matter how the pagination is tuned. Once the data lives in Postgres, a 10,000-row publisher search is a single indexed query in a few milliseconds, and Trackier being slow or down no longer blocks the tool.

## Database

New tables (all with row-level security, admin/authenticated read, service-role write):

- `campaigns` — `trackier_id` (unique), `title`, `status`, `is_active`, `hash_id`, `raw` jsonb, `synced_at`
- `publishers` — `trackier_id` (unique), `name`, `hash_id`, `long_id`, `status`, `raw` jsonb, `synced_at`
- `campaign_goals` — `campaign_trackier_id`, `goal_trackier_id` (unique together), `title`, `payout`, `revenue`, `raw`
- `sync_runs` — `entity`, `started_at`, `finished_at`, `status`, `records_upserted`, `error`

Indexes: unique on each `trackier_id`, btree on `is_active`, and `pg_trgm` GIN indexes on `campaigns.title` and `publishers.name` so name search is instant. Search runs server-side through a `search_campaigns` / `search_publishers` RPC returning the top 200 matches.

All writes use `INSERT ... ON CONFLICT (trackier_id) DO UPDATE`, so re-syncing never duplicates.

## Sync

One new edge function `sync-trackier` (`?entity=campaigns|publishers|goals|all`):

- Pages Trackier with bounded concurrency, upserts each page as it arrives (so a partial run still commits data), and records the outcome in `sync_runs`.
- Runs on a `pg_cron` schedule every 15 minutes.
- Exposed to the UI as a **Sync now** button plus a "last synced" timestamp in the header area — the only visible UI addition.

## Frontend changes (data layer only)

- `loadCampaigns` / `loadPublishers` in `src/pages/Index.tsx` query the `campaigns` / `publishers` tables instead of invoking `trackier-campaigns` / `trackier-publishers`. Same `Campaign` / `Publisher` shapes are returned (the `raw` jsonb is spread back in) so every downstream matching helper — `findExistingPayout`, `computeStatus`, `publisherMatchIds` — is untouched.
- The dropdown search boxes become debounced server-side searches; the paging controls stay exactly as they look today.
- Goals: `trackier-goals` keeps hitting Trackier live for `existingPayouts`, because payout matching must see the current live state. Only the goal list itself is served from cache.

## Unchanged on purpose

Payout upload flow, duplicate / will-update detection, publisher assignment, audit logs, auth, roles, theme, and every existing screen.

## Technical notes

- Sync writes with the service-role key inside the edge function; the client only ever reads.
- `trackier-campaigns` / `trackier-publishers` stay deployed as fallbacks and for the Debug page.
- First run backfills the full dataset; later runs are the same upsert path, so they are effectively incremental.
