# Fix payout upload timeout

## Approach
- Split large payout uploads into small frontend batches so each backend request stays well below the 150-second function limit.
- Process independent rows concurrently inside each batch while retaining one live campaign lookup per campaign and preserving the existing match/update/create decisions and payloads.
- Keep successful and failed row results aggregated into the existing UI result shape, including partial results if a batch fails.
- Deploy the updated function and verify the app build plus function behavior/logs.

## Technical details
- Deduplicate campaign fetches with a shared promise cache so concurrent rows never issue duplicate campaign reads.
- Bound concurrency to avoid overwhelming Trackier or the database.
- Write payout history and audit records concurrently only after the Trackier operation succeeds.
