# Premium workflow-first console redesign

## Goal
Transform the existing one-page console into a premium, operations-focused workflow using the selected **Electric Graphite**, **Sora + Manrope**, and **Premium payout orchestrator / Guided Rail** direction. Preserve every API call, state transition, calculation, matching rule, assignment action, and permission check.

## What will change
- Reframe the page around five visible stages: Campaigns, Publishers, Adjustment, Review, and Upload.
- Add a compact progress strip and sticky workflow rail that reflect existing selection, preview, and upload state.
- Restyle campaign and publisher selection as one cohesive stage with clearer search, paste-ID guidance, selection counts, removable chips, and the existing bulk controls.
- Redesign payout adjustment into a synchronized 0–100% calculation area with 50%, 75%, 100%, and Custom controls, while retaining the existing percentage-based calculation.
- Turn payout preview into a dedicated review stage with compact totals, a dense sticky-header table, restrained status badges, and intentional empty/loading states.
- Present upload as a clear confirmation stage and add a responsive sticky bottom summary with Review and Upload actions.
- Keep publisher assignment available as an operational secondary workflow without interrupting the payout sequence.
- Refine success/error presentation with compact notifications while preserving access to existing technical error details.
- Apply fast, subtle motion, accessible focus states, responsive stacking, and horizontal table scrolling.

## Visual system
- Dark: deep graphite/navy surfaces led by `#070B12`, restrained electric blue actions, semantic green/amber/red states.
- Light: soft cool-gray page, white working surfaces, navy text, subtle borders and shadows.
- Sora for headings and Manrope for body text; monospace only for IDs, amounts, and technical values.
- Reduce large floating cards in favor of one cohesive canvas, dividers, compact metrics, and elevated controls only where useful.

## Technical details
- Update presentation code in the console page, application shell, theme tokens, and existing reusable UI styling only.
- Clamp every adjustment control to 0–100 and keep input, presets, slider, and displayed value synchronized.
- Reuse existing handlers (`handleSync`, `handleFetch`, `handleUpload`, `handlePublisherAction`, reset, selectors, and row edits) without modifying their data logic.
- Verify dark and light themes at desktop and mobile widths, including selection, empty review, populated review, sticky controls, and overflow behavior.
- Confirm the preview builds cleanly and check runtime/console diagnostics after implementation.

## Out of scope
No changes to Trackier endpoints or payloads, database/backend/auth, campaign or publisher syncing, payout/revenue/goal calculations, matching/duplicate classification, assignment behavior, audit logs, or user roles.
