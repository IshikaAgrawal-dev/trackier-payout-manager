# Trackier Payout Manager (Claude Code guide)

Vite + React 18 + TypeScript + shadcn/ui + Tailwind SPA. Backend is the existing Lovable Cloud Supabase project: Postgres (RLS), email/password Auth, and Deno edge functions that hold the Trackier key. Do not migrate the project or change the schema without a clear need.

## Commands
- `npm ci` · `npm run dev` (port 8080) · `npm run build` · `npm run preview`
- `npm test` (frontend) · `npm run test:rules` (payout safety rules against the real edge-function and Index.tsx code) · `npm run test:all`
- Deploy: see DEPLOY.md (Vercel). Env: only `VITE_SUPABASE_URL`, `VITE_SUPABASE_PROJECT_ID`, `VITE_SUPABASE_PUBLISHABLE_KEY`.

## Layout
- `src/pages/Index.tsx` payout console: campaigns -> publishers -> adjustment (0-100%) -> review (New / Will update / Duplicate) -> upload; publisher assignment is a separate secondary action. Helpers: `findExistingPayout`, `computeStatus`, `requestedGeosFor`.
- `src/pages/GeoMigration.tsx` (admin), `Logs.tsx` (admin audit), `Users.tsx` (admin), `Debug.tsx`, `Login.tsx`. Routes in `src/App.tsx`; auth in `src/contexts/AuthContext.tsx`.
- `supabase/functions/`: `trackier-upload-payouts` (payout create/update), `trackier-goals` (live goals + existing payouts), `campaign-publisher-action` (assign/remove/block/unblock), `trackier-geo-migration`, `sync-trackier` (cache), `trackier-campaigns|publishers|debug`, `admin-invite-user`, `bootstrap-admin`, `mcp` (generated; unused by the web app).

## Payout rules (do not change unless fixing a specific bug; tests enforce them)
1. Identical existing payout -> Duplicate, skipped.
2. Matching payout with a different value -> edit via its real Trackier payout `_id`.
3. Create only when no match exists (after a live re-check).
4. Match on campaign + publisher (numeric id or hash/long id) + goal + exact geo. `IN` != `ALL`.
5. A failed update never falls back to create.
6. The default campaign payout (no pubIds) is never matched or edited by a publisher-specific update.
7. Publisher assignment never touches payout values.
Known existing feature: "Apply to all publishers" creates a payout without pubIds (a campaign-level payout). It is separate from rules 2-6 and was left as is.

## Security
Never put the Trackier key, `SERVICE_ROLE_KEY` or any secret in `src/` or a `VITE_*` var. The browser only holds the publishable key. All Trackier access goes through edge functions that call `requireUser` and write `audit_logs`. If a rule changes, update `tests/` in the same change.

## Gotchas
- `package-lock.json` must resolve from `registry.npmjs.org` only (it once pointed at a Lovable-internal registry, which breaks installs elsewhere).
- `supabase/functions/mcp/index.ts` is generated from `src/lib/mcp` by the Vite plugin on build; do not hand-edit.
- `npm run lint` has pre-existing errors in generated/shadcn files; they do not affect the build.
