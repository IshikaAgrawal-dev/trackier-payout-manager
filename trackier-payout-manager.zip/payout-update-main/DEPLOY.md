# Trackier Payout Manager: run, build, deploy

A standard Vite + React + TypeScript single-page app. It talks only to your existing Lovable Cloud Supabase project (auth, database, edge functions). All Trackier calls happen inside the Supabase edge functions; the browser never sees a Trackier key or a service-role key.

## Run locally

```sh
npm ci            # exact, reproducible install (lockfile is public-registry only)
npm run dev       # http://localhost:8080
```

`.env` already points at the existing Supabase project, so login and data work immediately with your existing users.

## Build and check

```sh
npm run build         # production build into dist/
npm run preview       # serve dist/ locally (http://localhost:4173)
npm run test:all      # unit tests + payout-safety-rule tests (see below)
```

## Environment variables (frontend only)

| Variable | Value | Secret? |
|---|---|---|
| `VITE_SUPABASE_URL` | your existing project URL (`https://<ref>.supabase.co`) | No, public |
| `VITE_SUPABASE_PROJECT_ID` | the project ref | No, public |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | the project's publishable (anon) key | No, public by design; protected by RLS |

Copy the three values from the existing `.env`. The Trackier key, `TRACKIER_BASE_URL`, `SYNC_CRON_SECRET` and the service-role key are **Supabase edge-function secrets**. They already exist in your Lovable Cloud project and must never be added to Vercel or to any `VITE_*` variable.

## Deploy on Vercel

1. Put this folder in a Git repository (GitHub/GitLab/Bitbucket). `.env` contains only the three public values above.
2. Vercel → **Add New → Project** → import the repository.
3. Settings are auto-detected from `vercel.json`: Framework **Vite**, Build command `npm run build`, Output directory `dist`. Leave Root Directory at the repo root.
4. **Settings → Environment Variables:** add the three `VITE_SUPABASE_*` variables for Production (and Preview if you use previews).
5. Click **Deploy**. Open the `*.vercel.app` URL and sign in with your existing console account.
6. Changing a variable later requires a **Redeploy**, because Vite inlines `VITE_*` values at build time.

`vercel.json` already contains the single-page-app rewrite (deep links like `/logs` and `/users` work on refresh) and basic security headers.

Equivalent hosts (Netlify, Cloudflare Pages): build `npm run build`, publish `dist`, add the same 3 variables, and rewrite `/*` to `/index.html`.

## Do I need to change anything in Supabase?

No. Login is email + password (`signInWithPassword`); users are created by an admin through the `admin-invite-user` function, so there are no OAuth or magic-link redirect URLs to allow-list. The edge functions send permissive CORS headers, so a new hosting domain works without changes. For a custom domain, add it in Vercel.

## Edge functions

Unchanged. They are deployed in your existing project (managed by Lovable Cloud, or `supabase functions deploy <name>` if you manage them yourself). The browser calls them with the signed-in user's token; each one re-checks the user (`requireUser`), the admin role where needed, and writes the audit log.

## Payout safety rules and their automated tests

`npm run test:rules` runs the real edge-function source (Deno, Supabase and Trackier stubbed, no network) and the real classification helpers from `src/pages/Index.tsx`:

- identical existing payout → Duplicate, nothing written
- matching payout, different value → edited via its real Trackier payout ID (`POST /campaigns/{id}/payouts/{payoutId}`), never created
- failed update → reported failed, **no replacement payout created**
- match on campaign + publisher + goal + exact geo; `IN` and `ALL` never interchangeable
- default campaign payout (no publisher ids) never matched or edited
- create only when no match exists, after a live re-check
- publisher assign/remove/block/unblock calls only `POST /campaigns/access`, never a payout endpoint, and sends no payout values
- geo migration edits only the geo field of existing payouts by payout ID, never creates, admin only

These tests were mutation-checked: deliberately breaking the geo rule, or allowing a create after a failed update, makes them fail.

## Needs your live credentials / manual action

1. Sign in on the deployed site with a real user (confirms the Supabase project, RLS and roles).
2. Build a preview for one test campaign and one test publisher; compare payout IDs and values with Trackier.
3. Upload a payout change on a test campaign; confirm in Trackier that the same payout ID changed, no new payout row appeared and the default payout is unchanged; confirm the `EDIT_PAYOUT` row in Logs.
4. Try assign/block on a test publisher; confirm in Trackier and in Logs.
5. As an admin, migrate geo for one test payout and confirm only the geo changed.
6. A blank login page or "Invalid API key" means the Vercel build is missing the three `VITE_*` variables.
