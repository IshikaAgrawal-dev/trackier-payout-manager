# Trackier Payout Manager (Extract & Engage)

See **DEPLOY.md** to run, build and deploy, and **CLAUDE.md** for architecture and the payout safety rules.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://payout-update.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/3b633367-4b8f-48a1-8c6e-8201833e5545).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
