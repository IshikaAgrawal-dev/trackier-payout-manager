DROP POLICY IF EXISTS "Authenticated read campaigns" ON public.campaigns;
CREATE POLICY "Admins read campaigns" ON public.campaigns FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'::app_role));
DROP POLICY IF EXISTS "Authenticated read publishers" ON public.publishers;
CREATE POLICY "Admins read publishers" ON public.publishers FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'::app_role));
DROP POLICY IF EXISTS "Authenticated read campaign payouts" ON public.campaign_payouts;
CREATE POLICY "Admins read campaign payouts" ON public.campaign_payouts FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'::app_role));
DROP POLICY IF EXISTS "Authenticated read campaign goals" ON public.campaign_goals;
CREATE POLICY "Admins read campaign goals" ON public.campaign_goals FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'::app_role));