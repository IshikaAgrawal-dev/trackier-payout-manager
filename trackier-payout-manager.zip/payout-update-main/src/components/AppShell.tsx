import { ReactNode } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useTheme } from "@/contexts/ThemeContext";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
  DropdownMenuLabel, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Link, useLocation } from "react-router-dom";
import { LogOut, Palette, Users, LayoutDashboard, ScrollText, Zap, Bug, Bell, Sun, Moon, Globe } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export function AppShell({ children }: { children: ReactNode }) {
  const { user, isAdmin, signOut } = useAuth();
  const { setTheme, mode, toggleMode } = useTheme();
  const loc = useLocation();

  const initials = (user?.email ?? "?").slice(0, 2).toUpperCase();

  const navItem = (to: string, label: string, icon: ReactNode) => {
    const active = loc.pathname === to;
    return (
      <Link
        to={to}
        aria-current={active ? "page" : undefined}
        className={`focus-ring flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
          active
            ? "bg-secondary text-foreground"
            : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
        }`}
      >
        {icon}
        {label}
      </Link>
    );
  };

  return (
    <TooltipProvider delayDuration={300} skipDelayDuration={200}>
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b hairline bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex h-14 max-w-[1500px] items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary shadow-soft">
              <Zap className="h-4 w-4 text-primary-foreground" />
            </div>
            <div className="flex items-center gap-2">
              <p className="text-[15px] font-semibold leading-tight tracking-tight">
                Trackier Ops
              </p>
              <span className="hidden rounded-md border hairline bg-secondary/70 px-2 py-0.5 text-[10px] font-semibold uppercase text-muted-foreground lg:inline">
                Internal
              </span>
            </div>
          </div>

          <nav className="hidden items-center gap-1 md:flex">
            {navItem("/", "Console", <LayoutDashboard className="h-4 w-4" />)}
            {isAdmin && navItem("/geo-migration", "Geo Migration", <Globe className="h-4 w-4" />)}
            {isAdmin && navItem("/logs", "Audit Logs", <ScrollText className="h-4 w-4" />)}
            {isAdmin && navItem("/users", "Users", <Users className="h-4 w-4" />)}
            {isAdmin && navItem("/debug", "Debug", <Bug className="h-4 w-4" />)}
          </nav>

          <div className="flex items-center gap-1.5">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="focus-ring rounded-lg"
                  onClick={toggleMode}
                  aria-label={mode === "dark" ? "Switch to light theme" : "Switch to dark theme"}
                >
                  {mode === "dark"
                    ? <Sun className="h-4 w-4 text-muted-foreground" />
                    : <Moon className="h-4 w-4 text-muted-foreground" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>{mode === "dark" ? "Light theme" : "Dark theme"}</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="focus-ring rounded-lg" aria-label="Notifications">
                  <Bell className="h-4 w-4 text-muted-foreground" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>No new notifications</TooltipContent>
            </Tooltip>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="focus-ring rounded-lg" aria-label="Change theme">
                  <Palette className="h-4 w-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Accent</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setTheme("default")}>Default (Blue)</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTheme("neon")}>Violet</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTheme("pastel")}>Slate</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="focus-ring gap-2 rounded-lg pl-1.5" aria-label="User menu">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full border hairline bg-secondary text-[11px] font-semibold">
                    {initials}
                  </span>
                  <span className="hidden max-w-[160px] truncate text-sm text-muted-foreground sm:inline">
                    {user?.email}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel className="text-xs font-normal">
                  <div className="text-sm font-medium text-foreground">{user?.email}</div>
                  <div className="mt-1 text-xs text-primary">
                    {isAdmin ? "Admin" : "User"}
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={signOut} className="gap-2">
                  <LogOut className="h-4 w-4" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1500px] animate-fade-in px-4 pb-28 pt-6 sm:px-6 lg:px-8 lg:pt-8">{children}</main>
    </div>
    </TooltipProvider>
  );
}
