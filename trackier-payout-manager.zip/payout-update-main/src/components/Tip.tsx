import { ReactNode, useRef, useState } from "react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

/**
 * Informative tooltip wrapper.
 * - Hover/focus opens after the provider delay (300ms).
 * - Touch devices: long-press (500ms) opens it.
 * Purely presentational — never alters the wrapped element's behaviour.
 */
export function Tip({
  content,
  children,
  side = "top",
  asChild = true,
}: {
  content: ReactNode;
  children: ReactNode;
  side?: "top" | "right" | "bottom" | "left";
  asChild?: boolean;
}) {
  const [open, setOpen] = useState<boolean | undefined>(undefined);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const clear = () => {
    if (timer.current) {
      clearTimeout(timer.current);
      timer.current = null;
    }
  };

  return (
    <Tooltip open={open} onOpenChange={setOpen}>
      <TooltipTrigger
        asChild={asChild}
        onTouchStart={() => {
          clear();
          timer.current = setTimeout(() => setOpen(true), 500);
        }}
        onTouchEnd={() => {
          clear();
          setTimeout(() => setOpen(false), 2500);
        }}
        onTouchCancel={() => {
          clear();
          setOpen(false);
        }}
      >
        {children}
      </TooltipTrigger>
      <TooltipContent
        side={side}
        align="center"
        collisionPadding={12}
        avoidCollisions
        className="max-w-[260px] text-xs leading-relaxed"
      >
        {content}
      </TooltipContent>
    </Tooltip>
  );
}
