import { createContext, useContext, useEffect, useState, ReactNode } from "react";

type Theme = "default" | "neon" | "pastel";
type Mode = "light" | "dark";
const KEY = "tcc-theme";
const MODE_KEY = "tcc-mode";

const Ctx = createContext<
  { theme: Theme; setTheme: (t: Theme) => void; mode: Mode; setMode: (m: Mode) => void; toggleMode: () => void }
  | undefined
>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(
    () => (typeof window !== "undefined" && (localStorage.getItem(KEY) as Theme)) || "default"
  );
  const [mode, setModeState] = useState<Mode>(() => {
    if (typeof window === "undefined") return "light";
    const stored = localStorage.getItem(MODE_KEY) as Mode | null;
    if (stored === "light" || stored === "dark") return stored;
    return "light";
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "default") root.removeAttribute("data-theme");
    else root.setAttribute("data-theme", theme);
    localStorage.setItem(KEY, theme);
  }, [theme]);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", mode === "dark");
    root.style.colorScheme = mode;
    localStorage.setItem(MODE_KEY, mode);
  }, [mode]);

  return (
    <Ctx.Provider
      value={{
        theme,
        setTheme: setThemeState,
        mode,
        setMode: setModeState,
        toggleMode: () => setModeState((m) => (m === "dark" ? "light" : "dark")),
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useTheme() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useTheme must be inside ThemeProvider");
  return c;
}
