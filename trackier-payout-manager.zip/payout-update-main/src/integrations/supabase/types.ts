export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          campaign_id: string | null
          created_at: string
          goal_id: string | null
          id: string
          payload: Json | null
          publisher_id: string | null
          user_email: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          campaign_id?: string | null
          created_at?: string
          goal_id?: string | null
          id?: string
          payload?: Json | null
          publisher_id?: string | null
          user_email?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          campaign_id?: string | null
          created_at?: string
          goal_id?: string | null
          id?: string
          payload?: Json | null
          publisher_id?: string | null
          user_email?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      campaign_goals: {
        Row: {
          campaign_trackier_id: string
          created_at: string
          goal_trackier_id: string
          id: string
          payout: number | null
          raw: Json
          revenue: number | null
          synced_at: string
          title: string | null
          updated_at: string
        }
        Insert: {
          campaign_trackier_id: string
          created_at?: string
          goal_trackier_id: string
          id?: string
          payout?: number | null
          raw?: Json
          revenue?: number | null
          synced_at?: string
          title?: string | null
          updated_at?: string
        }
        Update: {
          campaign_trackier_id?: string
          created_at?: string
          goal_trackier_id?: string
          id?: string
          payout?: number | null
          raw?: Json
          revenue?: number | null
          synced_at?: string
          title?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      campaign_payouts: {
        Row: {
          campaign_trackier_id: string
          created_at: string
          currency: string | null
          geo: Json
          goal_trackier_id: string | null
          id: string
          payout: number | null
          payout_trackier_id: string
          publisher_ids: Json
          raw: Json
          revenue: number | null
          synced_at: string
          updated_at: string
        }
        Insert: {
          campaign_trackier_id: string
          created_at?: string
          currency?: string | null
          geo?: Json
          goal_trackier_id?: string | null
          id?: string
          payout?: number | null
          payout_trackier_id: string
          publisher_ids?: Json
          raw?: Json
          revenue?: number | null
          synced_at?: string
          updated_at?: string
        }
        Update: {
          campaign_trackier_id?: string
          created_at?: string
          currency?: string | null
          geo?: Json
          goal_trackier_id?: string | null
          id?: string
          payout?: number | null
          payout_trackier_id?: string
          publisher_ids?: Json
          raw?: Json
          revenue?: number | null
          synced_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      campaigns: {
        Row: {
          created_at: string
          hash_id: string | null
          id: string
          is_active: boolean
          raw: Json
          status: string | null
          synced_at: string
          title: string | null
          trackier_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          hash_id?: string | null
          id?: string
          is_active?: boolean
          raw?: Json
          status?: string | null
          synced_at?: string
          title?: string | null
          trackier_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          hash_id?: string | null
          id?: string
          is_active?: boolean
          raw?: Json
          status?: string | null
          synced_at?: string
          title?: string | null
          trackier_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      payout_uploads: {
        Row: {
          adjusted_payout: number
          base_payout: number
          campaign_id: string
          created_at: string
          goal_id: string | null
          id: string
          percentage: number
          publisher_id: string
          status: string
          trackier_response: Json | null
          user_id: string | null
        }
        Insert: {
          adjusted_payout: number
          base_payout: number
          campaign_id: string
          created_at?: string
          goal_id?: string | null
          id?: string
          percentage: number
          publisher_id: string
          status?: string
          trackier_response?: Json | null
          user_id?: string | null
        }
        Update: {
          adjusted_payout?: number
          base_payout?: number
          campaign_id?: string
          created_at?: string
          goal_id?: string | null
          id?: string
          percentage?: number
          publisher_id?: string
          status?: string
          trackier_response?: Json | null
          user_id?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          email: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          email: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          email?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      publishers: {
        Row: {
          created_at: string
          hash_id: string | null
          id: string
          long_id: string | null
          name: string | null
          raw: Json
          status: string | null
          synced_at: string
          trackier_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          hash_id?: string | null
          id?: string
          long_id?: string | null
          name?: string | null
          raw?: Json
          status?: string | null
          synced_at?: string
          trackier_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          hash_id?: string | null
          id?: string
          long_id?: string | null
          name?: string | null
          raw?: Json
          status?: string | null
          synced_at?: string
          trackier_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      sync_runs: {
        Row: {
          created_at: string
          entity: string
          error: string | null
          finished_at: string | null
          id: string
          records_upserted: number
          started_at: string
          status: string
        }
        Insert: {
          created_at?: string
          entity: string
          error?: string | null
          finished_at?: string | null
          id?: string
          records_upserted?: number
          started_at?: string
          status?: string
        }
        Update: {
          created_at?: string
          entity?: string
          error?: string | null
          finished_at?: string | null
          id?: string
          records_upserted?: number
          started_at?: string
          status?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
