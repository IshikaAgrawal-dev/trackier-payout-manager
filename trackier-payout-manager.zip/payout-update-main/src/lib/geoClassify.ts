export type GeoClass = "IN" | "ALL" | "REVIEW";

export interface Classification {
  geo: GeoClass;
  reason: string;
}

/**
 * Campaign geo classification from the campaign NAME only (per the migration spec).
 * A campaign is auto-classified ONLY when its name carries an explicit, reliable
 * geo indicator. Brand compounds that merely contain a geo word (e.g. "Air India",
 * "Indian Oil") are excluded — the spec forbids classifying on unreliable tokens.
 * Everything else is "Needs Review" and must be classified manually before apply.
 */
const INTERNATIONAL_RE = /\b(international|global|worldwide|intl)\b/i;

const INDIA_RE = /\bindia\b/i;
// Names where "India" is part of a brand/entity name, not a geo indicator.
const INDIA_BRAND_EXCEPTIONS =
  /\b(air india|south india bank|union bank of india|state bank of india|bank of india)\b/i;

export function classifyCampaign(title: string): Classification {
  const name = (title ?? "").trim();

  const intlMatch = name.match(INTERNATIONAL_RE);
  if (intlMatch) {
    return {
      geo: "ALL",
      reason: `Explicit geo indicator: "${intlMatch[0]}" indicates international targeting`,
    };
  }

  const indiaMatch = name.match(INDIA_RE);
  if (indiaMatch && !INDIA_BRAND_EXCEPTIONS.test(name)) {
    return {
      geo: "IN",
      reason: 'Explicit geo indicator: "India" in campaign name (not part of a brand name)',
    };
  }

  return {
    geo: "REVIEW",
    reason: "No reliable geo indicator in campaign name — manual review required",
  };
}
