import { auth, defineMcp } from "@lovable.dev/mcp-js";
import listPayoutUploadsTool from "./tools/list-payout-uploads";
import listAuditLogsTool from "./tools/list-audit-logs";
import whoamiTool from "./tools/whoami";

const projectRef = import.meta.env.VITE_SUPABASE_PROJECT_ID ?? "project-ref-unset";

export default defineMcp({
  name: "extract-engage",
  title: "Extract & Engage",
  version: "0.1.0",
  instructions:
    "Tools for the Trackier Campaign Console. Use `whoami` to check the connected account, `list_payout_uploads` to review payout upload history, and `list_audit_logs` to review console activity. All data is scoped to the signed-in user's permissions.",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [whoamiTool, listPayoutUploadsTool, listAuditLogsTool],
});