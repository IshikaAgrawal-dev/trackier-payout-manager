import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_audit_logs",
  title: "List audit logs",
  description:
    "List recent console audit log entries visible to the signed-in user, newest first. Optionally filter by action or campaign.",
  inputSchema: {
    action: z.string().trim().min(1).optional().describe("Filter by action name."),
    campaign_id: z.string().trim().min(1).optional().describe("Filter by Trackier campaign id."),
    limit: z.number().int().min(1).max(100).default(25).describe("Maximum rows to return (1-100)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ action, campaign_id, limit }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const supabase = supabaseForUser(ctx);
    let query = supabase
      .from("audit_logs")
      .select("id, action, user_email, campaign_id, goal_id, publisher_id, payload, created_at")
      .order("created_at", { ascending: false })
      .limit(limit ?? 25);
    if (action) query = query.eq("action", action);
    if (campaign_id) query = query.eq("campaign_id", campaign_id);
    const { data, error } = await query;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data ?? []) }],
      structuredContent: { rows: data ?? [], count: data?.length ?? 0 },
    };
  },
});