import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_payout_uploads",
  title: "List payout uploads",
  description:
    "List recent Trackier payout upload records visible to the signed-in user, newest first. Optionally filter by campaign, publisher, or status.",
  inputSchema: {
    campaign_id: z.string().trim().min(1).optional().describe("Filter by Trackier campaign id."),
    publisher_id: z.string().trim().min(1).optional().describe("Filter by Trackier publisher id."),
    status: z.string().trim().min(1).optional().describe("Filter by upload status, e.g. success or failed."),
    limit: z.number().int().min(1).max(100).default(25).describe("Maximum rows to return (1-100)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ campaign_id, publisher_id, status, limit }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const supabase = supabaseForUser(ctx);
    let query = supabase
      .from("payout_uploads")
      .select("id, campaign_id, publisher_id, goal_id, base_payout, percentage, adjusted_payout, status, created_at")
      .order("created_at", { ascending: false })
      .limit(limit ?? 25);
    if (campaign_id) query = query.eq("campaign_id", campaign_id);
    if (publisher_id) query = query.eq("publisher_id", publisher_id);
    if (status) query = query.eq("status", status);
    const { data, error } = await query;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data ?? []) }],
      structuredContent: { rows: data ?? [], count: data?.length ?? 0 },
    };
  },
});