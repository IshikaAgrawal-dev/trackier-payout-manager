import { useState } from "react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Bug } from "lucide-react";

type DebugResult = {
  requestedPath?: string;
  fullUrl?: string;
  baseUrl?: string;
  hasApiKey?: boolean;
  upstreamStatus?: number;
  upstreamOk?: boolean;
  extractedCount?: number;
  upstreamBody?: unknown;
  error?: string;
};

const Debug = () => {
  const [loading, setLoading] = useState<string | null>(null);
  const [results, setResults] = useState<Record<string, DebugResult | { invokeError: string }>>({});

  const run = async (resource: "campaigns" | "publishers") => {
    setLoading(resource);
    const { data, error } = await supabase.functions.invoke(
      `trackier-debug?resource=${resource}&page=1&limit=10`,
    );
    setLoading(null);
    setResults((prev) => ({
      ...prev,
      [resource]: error ? { invokeError: error.message } : (data as DebugResult),
    }));
  };

  const renderResult = (key: string) => {
    const r = results[key];
    if (!r) return null;
    if ("invokeError" in r) {
      return (
        <pre className="mt-3 p-3 rounded-lg bg-destructive/10 border border-destructive/40 text-destructive text-xs overflow-auto">
          Edge function invoke error: {r.invokeError}
        </pre>
      );
    }
    return (
      <div className="mt-3 space-y-2 text-sm">
        <div className="flex flex-wrap gap-2">
          <Badge variant={r.upstreamOk ? "default" : "destructive"}>
            Upstream {r.upstreamStatus ?? "?"}
          </Badge>
          <Badge variant={r.hasApiKey ? "default" : "destructive"}>
            API key: {r.hasApiKey ? "set" : "missing"}
          </Badge>
          <Badge variant={r.baseUrl ? "default" : "destructive"}>
            Base URL: {r.baseUrl || "missing"}
          </Badge>
          <Badge variant="outline">extracted: {r.extractedCount ?? 0}</Badge>
        </div>
        <div className="text-xs text-muted-foreground break-all">
          GET {r.fullUrl}
        </div>
        {r.error && (
          <pre className="p-3 rounded-lg bg-destructive/10 border border-destructive/40 text-destructive text-xs overflow-auto">
            {r.error}
          </pre>
        )}
        <pre className="p-3 rounded-lg bg-secondary/40 border border-border text-xs overflow-auto max-h-96">
          {JSON.stringify(r.upstreamBody, null, 2)}
        </pre>
      </div>
    );
  };

  return (
    <AppShell>
      <h1 className="sr-only">Trackier API Debug</h1>
      <div className="space-y-6">
        <section className="glow-card p-6 md:p-8">
          <div className="flex items-center gap-2 mb-2">
            <Bug className="h-5 w-5 text-primary" />
            <h2 className="font-display text-xl font-semibold">Trackier Debug</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-5">
            Calls Trackier's <code>/campaigns</code> and <code>/publishers</code> endpoints
            and surfaces the raw HTTP status and response body.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Campaigns</h3>
                <Button size="sm" onClick={() => run("campaigns")} disabled={loading === "campaigns"}>
                  {loading === "campaigns" ? <Loader2 className="h-4 w-4 animate-spin" /> : "Fetch"}
                </Button>
              </div>
              {renderResult("campaigns")}
            </div>

            <div>
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Publishers</h3>
                <Button size="sm" onClick={() => run("publishers")} disabled={loading === "publishers"}>
                  {loading === "publishers" ? <Loader2 className="h-4 w-4 animate-spin" /> : "Fetch"}
                </Button>
              </div>
              {renderResult("publishers")}
            </div>
          </div>
        </section>
      </div>
    </AppShell>
  );
};

export default Debug;