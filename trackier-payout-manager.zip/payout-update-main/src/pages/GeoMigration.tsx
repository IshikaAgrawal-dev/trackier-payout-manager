import { useEffect, useMemo, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";
import { Tip } from "@/components/Tip";
import { cn } from "@/lib/utils";
import { classifyCampaign, type GeoClass } from "@/lib/geoClassify";
import {
  Globe, Loader2, RefreshCw, Search, DatabaseZap, CheckCircle2, XCircle, ShieldAlert, Download,
} from "lucide-react";

interface PayoutInfo {
  _id: string;
  geo: string[];
  isDefault: boolean;
  goalId: string | null;
  publisherCount: number;
  payout: number | null;
}

interface CampaignPayoutData {
  payouts: PayoutInfo[];
  error?: string | null;
}

interface DerivedRow {
  id: string;
  title: string;
  geo: GeoClass;
  reason: string;
  data: CampaignPayoutData | null;
  currentGeos: string[] | null;
  defaultUpdates: number;
  publisherUpdates: number;
  conflicts: number;
  onTargetCount: number;
  payoutCount: number;
  dataError: string | null;
  status: string;
  statusTone: "ready" | "ok" | "warn" | "muted";
}

const geoJoin = (geo: string[] | undefined | null) => {
  const list = (geo ?? []).map((g) => String(g).trim().toUpperCase()).filter(Boolean);
  return Array.from(new Set(list)).sort().join(",") || "ALL";
};

const PREVIEW_BATCH = 25;
const PREVIEW_CONCURRENCY = 3;
const APPLY_BATCH_CAMPAIGNS = 6;

const GeoMigration = () => {
  const [campaigns, setCampaigns] = useState<{ id: string; title: string }[]>([]);
  const [loadingList, setLoadingList] = useState(true);
  const [overrides, setOverrides] = useState<Record<string, GeoClass>>({});
  const [payoutData, setPayoutData] = useState<Record<string, CampaignPayoutData>>({});
  const [fetchProgress, setFetchProgress] = useState<{ done: number; total: number } | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState("");
  const [classFilter, setClassFilter] = useState<"all" | GeoClass>("all");
  const [applying, setApplying] = useState(false);
  const [applyProgress, setApplyProgress] = useState<{ done: number; total: number } | null>(null);
  const [result, setResult] = useState<{
    campaigns: number;
    updated: number;
    skipped: number;
    conflictsSkipped: number;
    failed: { campaignId: string; payoutId: string; reason: string }[];
  } | null>(null);

  useEffect(() => {
    (async () => {
      setLoadingList(true);
      const { data, error } = await supabase
        .from("campaigns")
        .select("trackier_id,title")
        .order("title");
      setLoadingList(false);
      if (error) {
        toast({ title: "Could not load campaigns", description: error.message, variant: "destructive" });
        return;
      }
      setCampaigns((data ?? []).map((c) => ({ id: String(c.trackier_id), title: c.title ?? "" })));
    })();
  }, []);

  const geoOf = (id: string, title: string): GeoClass => overrides[id] ?? classifyCampaign(title).geo;
  const reasonOf = (id: string, title: string): string =>
    overrides[id]
      ? "Manually classified during review"
      : classifyCampaign(title).reason;

  const rows: DerivedRow[] = useMemo(() => {
    return campaigns.map((c) => {
      const geo = geoOf(c.id, c.title);
      const data = payoutData[c.id] ?? null;
      const target = geo === "REVIEW" ? null : geo;
      const other = geo === "IN" ? "ALL" : "IN";
      let defaultUpdates = 0, publisherUpdates = 0, conflicts = 0, onTargetCount = 0;
      const geos = new Set<string>();
      if (data) {
        for (const p of data.payouts) {
          const g = geoJoin(p.geo);
          geos.add(g);
          if (target && g === other) {
            if (p.isDefault) defaultUpdates++; else publisherUpdates++;
          } else if (target && g !== target) {
            conflicts++;
          } else if (target) {
            onTargetCount++;
          }
        }
      }
      let status = "Waiting for payout data";
      let statusTone: DerivedRow["statusTone"] = "muted";
      if (data?.error) {
        status = "Fetch failed";
        statusTone = "warn";
      } else if (data) {
        if (geo === "REVIEW") {
          status = "Needs classification";
        } else if (conflicts > 0 && defaultUpdates + publisherUpdates === 0) {
          status = `Conflicts only — ${conflicts} skipped`;
          statusTone = "warn";
        } else if (conflicts > 0) {
          status = `Ready — ${conflicts} conflicts skipped`;
          statusTone = "ready";
        } else if (defaultUpdates + publisherUpdates > 0) {
          status = "Ready to update";
          statusTone = "ready";
        } else if (data.payouts.length > 0) {
          status = "Already on target";
          statusTone = "ok";
        } else {
          status = "No payouts found";
          statusTone = "muted";
        }
      }
      return {
        id: c.id, title: c.title, geo, reason: reasonOf(c.id, c.title),
        data, currentGeos: data ? Array.from(geos) : null,
        defaultUpdates, publisherUpdates, conflicts, onTargetCount,
        payoutCount: data?.payouts.length ?? 0,
        dataError: data?.error ?? null,
        status, statusTone,
      };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [campaigns, overrides, payoutData]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (classFilter !== "all" && r.geo !== classFilter) return false;
      if (q && !(`${r.title} ${r.id}`.toLowerCase().includes(q))) return false;
      return true;
    });
  }, [rows, search, classFilter]);

  const stats = useMemo(() => {
    const ready = rows.filter((r) => r.statusTone === "ready");
    return {
      total: rows.length,
      india: rows.filter((r) => r.geo === "IN").length,
      international: rows.filter((r) => r.geo === "ALL").length,
      review: rows.filter((r) => r.geo === "REVIEW").length,
      readyCampaigns: ready.length,
      readyPayouts: ready.reduce((s, r) => s + r.defaultUpdates + r.publisherUpdates, 0),
      conflicts: rows.reduce((s, r) => s + (r.geo !== "REVIEW" ? r.conflicts : 0), 0),
    };
  }, [rows]);

  const payoutsLoaded = fetchProgress == null && Object.keys(payoutData).length > 0;

  const fetchPreview = async () => {
    if (!campaigns.length) return;
    setResult(null);
    const ids = campaigns.map((c) => c.id);
    setFetchProgress({ done: 0, total: ids.length });
    const batches: string[][] = [];
    for (let i = 0; i < ids.length; i += PREVIEW_BATCH) batches.push(ids.slice(i, i + PREVIEW_BATCH));
    let done = 0;
    let hadError = false;
    for (let i = 0; i < batches.length; i += PREVIEW_CONCURRENCY) {
      const group = batches.slice(i, i + PREVIEW_CONCURRENCY);
      const responses = await Promise.all(
        group.map((batch) =>
          supabase.functions.invoke("trackier-geo-migration", {
            body: { action: "preview", campaignIds: batch },
          }),
        ),
      );
      const merged: Record<string, CampaignPayoutData> = {};
      for (const resp of responses) {
        if (resp.error || !(resp.data as { results?: unknown })?.results) {
          hadError = true;
          continue;
        }
        for (const r of (resp.data as { results: { campaignId: string; payouts: PayoutInfo[]; error: string | null }[] }).results) {
          merged[r.campaignId] = { payouts: r.payouts, error: r.error };
        }
      }
      done += group.reduce((s, b) => s + b.length, 0);
      setPayoutData((prev) => ({ ...prev, ...merged }));
      setFetchProgress({ done, total: ids.length });
    }
    setFetchProgress(null);
    if (hadError) {
      toast({
        title: "Some payout data could not be loaded",
        description: "Part of the preview is incomplete. Re-run the fetch to fill the gaps.",
        variant: "destructive",
      });
    }
  };

  const eligible = useMemo(
    () =>
      rows.filter(
        (r) => r.geo !== "REVIEW" && r.data && !r.data.error && r.defaultUpdates + r.publisherUpdates > 0,
      ),
    [rows],
  );

  const applyScope = useMemo(() => {
    if (selected.size) return eligible.filter((r) => selected.has(r.id));
    return eligible;
  }, [eligible, selected]);

  const applyMigration = async () => {
    if (!applyScope.length || applying) return;
    setApplying(true);
    setResult(null);
    const rowsPayload = applyScope.flatMap((r) => {
      const target = r.geo as "IN" | "ALL";
      const other = target === "IN" ? "ALL" : "IN";
      return (r.data?.payouts ?? [])
        .filter((p) => geoJoin(p.geo) === other)
        .map((p) => ({ campaignId: r.id, payoutId: p._id, targetGeo: target }));
    });
    // Batch by campaign so each campaign is fetched once per request.
    const byCampaign = new Map<string, typeof rowsPayload>();
    for (const row of rowsPayload) {
      const list = byCampaign.get(row.campaignId) ?? [];
      list.push(row);
      byCampaign.set(row.campaignId, list);
    }
    const groups: { campaignId: string; rows: typeof rowsPayload }[] = Array.from(
      byCampaign,
      ([campaignId, list]) => ({ campaignId, rows: list }),
    );
    setApplyProgress({ done: 0, total: rowsPayload.length });
    let updated = 0, skipped = 0;
    const failed: { campaignId: string; payoutId: string; reason: string }[] = [];
    const appliedIds = new Map<string, Set<string>>();
    for (let i = 0; i < groups.length; i += APPLY_BATCH_CAMPAIGNS) {
      const chunk = groups.slice(i, i + APPLY_BATCH_CAMPAIGNS);
      const body = chunk.flatMap((g) => g.rows);
      const { data, error } = await supabase.functions.invoke("trackier-geo-migration", {
        body: { action: "apply", rows: body },
      });
      if (error || !data) {
        for (const row of body) failed.push({ ...row, reason: error?.message ?? "Request failed" });
      } else {
        const res = data as {
          success: { campaignId: string; payoutId: string }[];
          skipped: { campaignId: string; payoutId: string }[];
          failed: { campaignId: string; payoutId: string; reason: string }[];
        };
        updated += res.success.length;
        skipped += res.skipped.length;
        failed.push(...res.failed);
        for (const s of res.success) {
          const set = appliedIds.get(s.campaignId) ?? new Set<string>();
          set.add(s.payoutId);
          appliedIds.set(s.campaignId, set);
        }
      }
      setApplyProgress({ done: Math.min(i + APPLY_BATCH_CAMPAIGNS, groups.length) * 0, total: rowsPayload.length });
    }
    // Reflect applied geos locally so statuses flip to "Already on target".
    if (appliedIds.size) {
      setPayoutData((prev) => {
        const next = { ...prev };
        for (const [campaignId, ids] of appliedIds) {
          const entry = next[campaignId];
          if (!entry) continue;
          next[campaignId] = {
            ...entry,
            payouts: entry.payouts.map((p) =>
              ids.has(p._id) ? { ...p, geo: [p.geo.length && geoJoin(p.geo) === "IN" ? "ALL" : "IN"] } : p,
            ),
          };
        }
        return next;
      });
    }
    setApplyProgress(null);
    setApplying(false);
    setResult({
      campaigns: appliedIds.size,
      updated,
      skipped,
      conflictsSkipped: applyScope.reduce((s, r) => s + r.conflicts, 0),
      failed,
    });
    if (failed.length) {
      toast({
        title: `Migration finished with ${failed.length} failure(s)`,
        description: "Check the result report for details.",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Migration complete",
        description: `${updated} payout(s) updated across ${appliedIds.size} campaign(s).`,
      });
    }
  };

  const toggleRow = (id: string, checked: boolean) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (checked) next.add(id); else next.delete(id);
      return next;
    });
  };

  const allVisibleSelected = filtered.length > 0 && filtered.every((r) => selected.has(r.id));

  const bulkClassify = (geo: GeoClass | null) => {
    if (!selected.size) return;
    setOverrides((prev) => {
      const next = { ...prev };
      for (const id of selected) {
        if (geo) next[id] = geo; else delete next[id];
      }
      return next;
    });
  };

  const setOverride = (id: string, geo: GeoClass | null) => {
    setOverrides((prev) => {
      const next = { ...prev };
      if (geo) next[id] = geo; else delete next[id];
      return next;
    });
  };

  const busy = applying || fetchProgress != null;

  const statusChip = (r: DerivedRow) => {
    const cls =
      r.statusTone === "ready"
        ? "bg-success/15 text-success border-success/30"
        : r.statusTone === "ok"
          ? "bg-primary/10 text-primary border-primary/25"
          : r.statusTone === "warn"
            ? "bg-warning/15 text-warning border-warning/30"
            : "hairline bg-secondary text-muted-foreground";
    return <Tip content={r.dataError ?? r.status}><span className={cn("inline-block whitespace-nowrap rounded-full border px-2.5 py-1 text-[11px] font-medium", cls)}>{r.status}</span></Tip>;
  };

  return (
    <AppShell>
      <h1 className="sr-only">Geo Migration</h1>
      <div className="panel p-4 md:p-6">
        <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-muted-foreground" />
              <h2 className="text-[22px] font-semibold tracking-tight">Geo Migration</h2>
            </div>
            <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
              Classify campaigns by name, review every payout's current geo, then update only the geo field on
              existing payouts — amounts, revenue, publishers and goals are preserved. Nothing changes until you
              confirm.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="focus-ring h-9 rounded-lg"
              onClick={fetchPreview}
              disabled={busy || loadingList || !campaigns.length}
            >
              {fetchProgress ? <Loader2 className="h-4 w-4 animate-spin" /> : <DatabaseZap className="h-4 w-4" />}
              Fetch payout data
            </Button>
          </div>
        </div>

        {fetchProgress && (
          <div className="mb-4 rounded-lg border hairline bg-surface-1/50 p-3">
            <div className="mb-2 flex items-center justify-between text-xs">
              <span className="font-medium">Fetching live payouts from Trackier…</span>
              <span className="font-mono text-muted-foreground">
                {fetchProgress.done}/{fetchProgress.total}
              </span>
            </div>
            <Progress value={(fetchProgress.done / Math.max(1, fetchProgress.total)) * 100} className="h-1.5" />
          </div>
        )}

        <div className="mb-4 grid grid-cols-2 gap-px overflow-hidden rounded-lg border hairline bg-border sm:grid-cols-3 lg:grid-cols-6">
          {[
            { label: "Campaigns", value: stats.total, cls: "" },
            { label: "India (IN)", value: stats.india, cls: "text-primary" },
            { label: "International (ALL)", value: stats.international, cls: "text-primary" },
            { label: "Needs review", value: stats.review, cls: "text-warning" },
            { label: "Ready campaigns", value: stats.readyCampaigns, cls: "text-success" },
            { label: "Payouts to update", value: stats.readyPayouts, cls: "text-success" },
          ].map((item) => (
            <div key={item.label} className="bg-card px-4 py-3">
              <p className={cn("font-mono text-2xl font-semibold", item.cls)}>{item.value}</p>
              <p className="mt-1 text-[10px] font-bold uppercase text-muted-foreground">{item.label}</p>
            </div>
          ))}
        </div>

        <div className="mb-3 flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search name or ID…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="focus-ring h-9 w-56 rounded-lg pl-8"
            />
          </div>
          <Select value={classFilter} onValueChange={(v) => setClassFilter(v as "all" | GeoClass)}>
            <SelectTrigger className="focus-ring h-9 w-[190px] rounded-lg">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All classifications</SelectItem>
              <SelectItem value="IN">India (IN)</SelectItem>
              <SelectItem value="ALL">International (ALL)</SelectItem>
              <SelectItem value="REVIEW">Needs review</SelectItem>
            </SelectContent>
          </Select>
          <span className="text-xs text-muted-foreground">{filtered.length} shown</span>
          {selected.size > 0 && (
            <div className="ml-auto flex items-center gap-2">
              <span className="text-xs font-medium">{selected.size} selected</span>
              <Button variant="outline" size="sm" className="focus-ring h-8 rounded-lg" onClick={() => bulkClassify("IN")} disabled={busy}>
                Set India
              </Button>
              <Button variant="outline" size="sm" className="focus-ring h-8 rounded-lg" onClick={() => bulkClassify("ALL")} disabled={busy}>
                Set International
              </Button>
              <Button variant="ghost" size="sm" className="focus-ring h-8 rounded-lg" onClick={() => bulkClassify(null)} disabled={busy}>
                Needs review
              </Button>
            </div>
          )}
        </div>

        <div className="max-h-[600px] overflow-auto rounded-xl border hairline">
          <Table>
            <TableHeader className="sticky top-0 z-10 bg-surface-2/95 backdrop-blur">
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-10">
                  <Checkbox
                    aria-label="Select all shown campaigns"
                    checked={allVisibleSelected ? true : filtered.some((r) => selected.has(r.id)) ? "indeterminate" : false}
                    onCheckedChange={(v) => {
                      setSelected((prev) => {
                        const next = new Set(prev);
                        if (v) filtered.forEach((r) => next.add(r.id));
                        else filtered.forEach((r) => next.delete(r.id));
                        return next;
                      });
                    }}
                  />
                </TableHead>
                <TableHead>Campaign</TableHead>
                <TableHead>Classification</TableHead>
                <TableHead>Reason</TableHead>
                <TableHead>Current geo</TableHead>
                <TableHead>Target geo</TableHead>
                <TableHead className="text-right">Default payouts</TableHead>
                <TableHead className="text-right">Publisher payouts</TableHead>
                <TableHead className="text-right">Conflicts</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((r, i) => (
                <TableRow key={r.id} className={i % 2 === 1 ? "row-stripe" : ""}>
                  <TableCell>
                    <Checkbox
                      aria-label={`Select campaign ${r.id}`}
                      checked={selected.has(r.id)}
                      onCheckedChange={(v) => toggleRow(r.id, !!v)}
                    />
                  </TableCell>
                  <TableCell>
                    <div className="max-w-[260px]">
                      <p className="truncate text-[13px] font-medium" title={r.title}>{r.title}</p>
                      <p className="font-mono text-[11px] text-muted-foreground">#{r.id}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Select
                      value={r.geo}
                      onValueChange={(v) => setOverride(r.id, v as GeoClass)}
                      disabled={busy}
                    >
                      <SelectTrigger className="focus-ring h-8 w-[130px] rounded-lg text-xs" aria-label={`Classification for campaign ${r.id}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="IN">India (IN)</SelectItem>
                        <SelectItem value="ALL">International (ALL)</SelectItem>
                        <SelectItem value="REVIEW">Needs review</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Tip content={r.reason}>
                      <span className="block max-w-[220px] truncate text-xs text-muted-foreground">{r.reason}</span>
                    </Tip>
                  </TableCell>
                  <TableCell>
                    {r.currentGeos == null ? (
                      <span className="text-xs text-muted-foreground">—</span>
                    ) : r.currentGeos.length ? (
                      <div className="flex flex-wrap gap-1">
                        {r.currentGeos.map((g) => (
                          <span key={g} className="rounded border hairline bg-secondary/60 px-1.5 py-0.5 font-mono text-[10px]">{g}</span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">No payouts</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {r.geo === "REVIEW" ? (
                      <span className="text-xs text-muted-foreground">—</span>
                    ) : (
                      <span className="rounded border border-primary/25 bg-primary/10 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-primary">{r.geo}</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-mono text-xs">
                    {r.data ? (r.defaultUpdates > 0 ? r.defaultUpdates : <span className="text-muted-foreground">0</span>) : "—"}
                  </TableCell>
                  <TableCell className="text-right font-mono text-xs">
                    {r.data ? (r.publisherUpdates > 0 ? r.publisherUpdates : <span className="text-muted-foreground">0</span>) : "—"}
                  </TableCell>
                  <TableCell className="text-right font-mono text-xs">
                    {r.data ? (
                      r.conflicts > 0 ? (
                        <Tip content="Payouts with a specific geo (neither ALL nor IN) are never changed — resolve them manually in Trackier.">
                          <span className="inline-flex items-center gap-1 text-warning">
                            <ShieldAlert className="h-3.5 w-3.5" />{r.conflicts}
                          </span>
                        </Tip>
                      ) : (
                        <span className="text-muted-foreground">0</span>
                      )
                    ) : "—"}
                  </TableCell>
                  <TableCell>{statusChip(r)}</TableCell>
                </TableRow>
              ))}
              {!filtered.length && (
                <TableRow>
                  <TableCell colSpan={10} className="py-10 text-center text-sm text-muted-foreground">
                    {loadingList ? "Loading campaigns…" : "No campaigns match the current filters."}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {result && (
          <div className="mt-4 rounded-xl border hairline bg-card p-4">
            <div className="mb-2 flex items-center gap-2">
              {result.failed.length ? <XCircle className="h-4 w-4 text-warning" /> : <CheckCircle2 className="h-4 w-4 text-success" />}
              <p className="text-sm font-semibold">Migration report</p>
            </div>
            <div className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border hairline bg-border sm:grid-cols-4">
              <div className="bg-card px-4 py-3"><p className="font-mono text-xl font-semibold text-success">{result.updated}</p><p className="text-[10px] font-bold uppercase text-muted-foreground">Payouts updated</p></div>
              <div className="bg-card px-4 py-3"><p className="font-mono text-xl font-semibold">{result.campaigns}</p><p className="text-[10px] font-bold uppercase text-muted-foreground">Campaigns touched</p></div>
              <div className="bg-card px-4 py-3"><p className="font-mono text-xl font-semibold">{result.skipped}</p><p className="text-[10px] font-bold uppercase text-muted-foreground">Already on target</p></div>
              <div className="bg-card px-4 py-3"><p className="font-mono text-xl font-semibold">{result.conflictsSkipped}</p><p className="text-[10px] font-bold uppercase text-muted-foreground">Conflicts skipped</p></div>
            </div>
            {result.failed.length > 0 && (
              <div className="mt-3 max-h-[200px] overflow-auto rounded-lg border border-warning/30 bg-warning/5 p-3">
                <p className="mb-1 text-xs font-semibold text-warning">{result.failed.length} failed update(s)</p>
                <ul className="space-y-1 font-mono text-[11px] text-muted-foreground">
                  {result.failed.map((f, i) => (
                    <li key={`${f.campaignId}-${f.payoutId}-${i}`}>
                      campaign {f.campaignId} · payout {f.payoutId} · {f.reason}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <p className="mt-2 text-xs text-muted-foreground">
              Every change is recorded in Audit Logs as GEO_MIGRATION with the payout ID and geo transition.
            </p>
          </div>
        )}
      </div>

      <div className="fixed bottom-0 left-0 right-0 z-40 border-t hairline bg-background/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-[1500px] items-center justify-between gap-3 px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4 text-xs">
            <span className="font-medium">
              {payoutsLoaded ? (
                <>
                  Ready: <span className="font-mono text-success">{applyScope.length}</span> campaign(s) ·{" "}
                  <span className="font-mono text-success">
                    {applyScope.reduce((s, r) => s + r.defaultUpdates + r.publisherUpdates, 0)}
                  </span>{" "}
                  payout(s) to update
                </>
              ) : (
                "Fetch payout data to enable the migration"
              )}
            </span>
            {applyProgress && (
              <span className="flex items-center gap-2 font-mono text-muted-foreground">
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                {applyProgress.done}/{applyProgress.total} rows
              </span>
            )}
          </div>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                className="focus-ring gap-2 rounded-lg"
                disabled={!payoutsLoaded || busy || applyScope.length === 0}
              >
                <Download className="h-4 w-4" />
                Apply migration
                {applyScope.length > 0 && (
                  <Badge variant="outline" className="ml-1 border-foreground/20 text-foreground">
                    {applyScope.reduce((s, r) => s + r.defaultUpdates + r.publisherUpdates, 0)}
                  </Badge>
                )}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Confirm geo migration</AlertDialogTitle>
                <AlertDialogDescription>
                  {applyScope.length} campaign(s) and{" "}
                  {applyScope.reduce((s, r) => s + r.defaultUpdates + r.publisherUpdates, 0)} payout(s) will be
                  updated in Trackier: only the geo field changes ({stats.india > 0 ? "ALL → IN on India campaigns" : ""}
                  {stats.india > 0 && stats.international > 0 ? "; " : ""}
                  {stats.international > 0 ? "IN → ALL on international campaigns" : ""}). Payout amounts, revenue,
                  publishers and goals are preserved. {stats.conflicts} conflict payout(s) with specific geos are
                  skipped. Existing payouts are edited in place — nothing is created or deleted.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={applyMigration}>Confirm & update Trackier</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </AppShell>
  );
};

export default GeoMigration;
