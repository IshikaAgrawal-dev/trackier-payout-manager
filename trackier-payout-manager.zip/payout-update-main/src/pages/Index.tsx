import { ReactNode, useEffect, useMemo, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Loader2, RefreshCw, Search, Upload, RotateCcw, CheckCircle2, XCircle, DatabaseZap,
  Megaphone, Users2, Clock, Activity, ListChecks, Inbox, X, SlidersHorizontal, Wand2,
} from "lucide-react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Tip } from "@/components/Tip";
import { cn } from "@/lib/utils";

const PAGE_SIZE = 100;

/* ---------- presentational helpers (no logic) ---------- */

function KpiCard({
  icon, label, value, hint, tone = "default",
}: {
  icon: ReactNode; label: string; value: string; hint?: string; tone?: "default" | "success";
}) {
  return (
    <div className="kpi p-4">
      <div className="flex items-center gap-2 text-muted-foreground">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg border hairline bg-secondary/60">
          {icon}
        </span>
        <span className="text-[13px] font-medium">{label}</span>
      </div>
      <p className={cn("mt-3 text-2xl font-semibold tracking-tight", tone === "success" && "text-success")}>
        {value}
      </p>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

function SelectionChips({
  ids, resolve, onRemove, emptyLabel,
}: {
  ids: string[]; resolve: (id: string) => string; onRemove: (id: string) => void; emptyLabel: string;
}) {
  if (!ids.length) {
    return <p className="text-sm text-muted-foreground">{emptyLabel}</p>;
  }
  const shown = ids.slice(0, 6);
  return (
    <div className="flex flex-wrap gap-1.5">
      {shown.map((id) => (
        <span key={id} className="chip max-w-[220px]">
          <span className="truncate">{resolve(id)}</span>
          <button
            type="button"
            aria-label={`Remove ${resolve(id)}`}
            onClick={() => onRemove(id)}
            className="focus-ring rounded-full text-muted-foreground transition-colors hover:text-foreground"
          >
            <X className="h-3 w-3" />
          </button>
        </span>
      ))}
      {ids.length > shown.length && (
        <span className="chip text-muted-foreground">+{ids.length - shown.length} more</span>
      )}
    </div>
  );
}

function EmptyState({ icon, title, description }: { icon: ReactNode; title: string; description: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed hairline bg-surface-1/40 px-6 py-10 text-center">
      <span className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl border hairline bg-secondary/50 text-muted-foreground">
        {icon}
      </span>
      <p className="text-sm font-medium">{title}</p>
      <p className="mt-1 max-w-sm text-xs text-muted-foreground">{description}</p>
    </div>
  );
}

const statusBadge: Record<RowStatus, { label: string; className: string; help: string }> = {
  new: {
    label: "New",
    className: "border-success/30 bg-success/15 text-success",
    help: "No matching payout exists. A new publisher-specific payout will be created.",
  },
  will_update: {
    label: "Will update",
    className: "border-warning/30 bg-warning/15 text-warning",
    help: "A matching publisher-specific payout exists with a different payout value. The existing payout will be updated.",
  },
  duplicate: {
    label: "Duplicate",
    className: "hairline bg-secondary text-muted-foreground",
    help: "An identical payout already exists. No changes will be made.",
  },
};

// Trackier may return the active flag in several shapes ("ACTIVE", "active",
// 1, true, isActive, ...). Normalize so only genuinely active campaigns are
// ever treated as selectable, regardless of capitalization or field name.
function isActiveCampaignRow(c: Record<string, unknown>): boolean {
  // Only Trackier's actual status field decides — never flags or presence.
  const raw = c.status ?? c.campaign_status ?? c.campaignStatus;
  return typeof raw === "string" && raw.trim().toLowerCase() === "active";
}

// Rows are cached in the database by the sync job; map them back to the exact
// shapes the matching logic below already expects.
function toCampaign(row: Record<string, unknown>): Campaign {
  const raw = (row.raw as Record<string, unknown>) || {};
  return {
    ...raw,
    id: String(row.trackier_id),
    title: (row.title as string) ?? (raw.title as string) ?? undefined,
    name: (raw.name as string) ?? (row.title as string) ?? undefined,
    status: (row.status as string) ?? undefined,
    hashId: (row.hash_id as string) ?? (raw.hashId as string) ?? undefined,
  } as Campaign;
}

function toPublisher(row: Record<string, unknown>): Publisher {
  const raw = (row.raw as Record<string, unknown>) || {};
  return {
    ...raw,
    id: String(row.trackier_id),
    company: (raw.company as string) ?? (row.name as string) ?? undefined,
    name: (row.name as string) ?? (raw.name as string) ?? undefined,
    hashId: (row.hash_id as string) ?? (raw.hashId as string) ?? undefined,
    publisherLongId: (raw.publisherLongId as string) ?? (row.long_id as string) ?? undefined,
    longId: (raw.longId as string) ?? (row.long_id as string) ?? undefined,
  } as Publisher;
}

function escapeLike(q: string) {
  return q.replace(/[%,()]/g, " ").trim();
}

type Campaign = { id: string; title?: string; name?: string; status?: string; [k: string]: unknown };
type Publisher = { id: string; company?: string; name?: string; [k: string]: unknown };
type Goal = { id: string; title?: string; name?: string; payout?: number; revenue?: number };

// Build a single lowercased haystack from all string fields of an object — robust to unknown API shapes
function buildHaystack(obj: Record<string, unknown>): string {
  const parts: string[] = [];
  for (const v of Object.values(obj)) {
    if (v == null) continue;
    if (typeof v === "string" || typeof v === "number") parts.push(String(v));
  }
  return parts.join(" ").toLowerCase();
}

function getDisplayName(obj: Record<string, unknown>): string {
  const candidates = ["company", "companyName", "name", "title", "username", "firstName", "first_name", "fullName", "email"];
  for (const k of candidates) {
    const v = obj[k];
    if (typeof v === "string" && v.trim()) return v;
  }
  return "";
}

function mergeById<T extends { id: string }>(current: T[], incoming: T[]): T[] {
  const map = new Map<string, T>();
  current.forEach((item) => map.set(String(item.id), item));
  incoming.forEach((item) => map.set(String(item.id), item));
  return Array.from(map.values());
}

const ALL_PUBLISHERS_ID = "__all__";

type RowStatus = "new" | "will_update" | "duplicate";

interface PayoutRow {
  key: string;
  campaignId: string;
  campaignName: string;
  goalId: string | null;
  goalLabel: string;
  basePayout: number;
  adjustedPayout: number;
  publisherId: string;
  publisherName: string;
  status: RowStatus;
  existingPayout: number | null;
  existingPayoutId: string | null;
  publisherMatchIds: string[];
  geo: string[];
  // legacy alias used by some bits of the UI
  isDuplicate: boolean;
}

interface ExistingPayout {
  id: string;
  pubIds: string[];
  goalId: string | null;
  geo: string[];
  payout: number;
  revenue: number;
  currency: string | null;
}

function normalizeId(v: unknown): string {
  return String(v ?? "").trim().toLowerCase();
}

function normalizeGoalKey(v: unknown): string | null {
  const s = String(v ?? "").trim();
  if (!s || s.toLowerCase() === "default" || s === "0") return null;
  return s;
}

// Geo normalization: uppercase, trimmed, de-duplicated, sorted. Empty → ["ALL"].
function normalizeGeo(v: unknown): string[] {
  const list = (Array.isArray(v) ? v : v == null || v === "" ? [] : String(v).split(","))
    .map((g) => String(g).trim().toUpperCase())
    .filter(Boolean);
  const uniq = Array.from(new Set(list)).sort();
  return uniq.length ? uniq : ["ALL"];
}
const geoKeyOf = (v: unknown) => normalizeGeo(v).join(",");

// Distinct exact geo sets of publisher-specific payouts for this publisher + goal.
// Falls back to ["ALL"] when no publisher-specific payout exists yet.
function requestedGeosFor(payouts: ExistingPayout[], publisherMatchIds: string[], goalId: string | null): string[][] {
  const matchIds = new Set(publisherMatchIds.map(normalizeId).filter(Boolean));
  const goalKey = normalizeGoalKey(goalId);
  const keys = new Set<string>();
  payouts.forEach((p) => {
    const pubIds = (p.pubIds ?? []).map(normalizeId).filter(Boolean);
    if (!pubIds.length || !pubIds.some((id) => matchIds.has(id))) return;
    const pGoal = normalizeGoalKey(p.goalId);
    if (goalKey ? pGoal !== goalKey : pGoal !== null) return;
    keys.add(geoKeyOf(p.geo));
  });
  if (!keys.size) return [["ALL"]];
  return Array.from(keys).sort().map((k) => k.split(","));
}

// Match an existing Trackier payout on campaign (already scoped) + publisher + goal + geo.
// pubIds may arrive as "679", ["679"], [679] or as a Mongo hash id — all normalized here.
function findExistingPayout(
  payouts: ExistingPayout[],
  publisherMatchIds: string[],
  goalId: string | null,
  adjustedPayout: number | undefined,
  requestedGeo: string[],
): ExistingPayout | undefined {
  const wantGeo = geoKeyOf(requestedGeo);
  const matchIds = new Set(publisherMatchIds.map(normalizeId).filter(Boolean));
  const goalKey = normalizeGoalKey(goalId);
  const specificMatches: ExistingPayout[] = [];
  payouts.forEach((p) => {
    const pubIds = (p.pubIds ?? []).map(normalizeId).filter(Boolean);
    // Publisher-Specific Payout MUST have the publisher present in pubIds.
    // Never match the Default Payout (pubIds empty) — it must never be modified.
    if (pubIds.length === 0) return;
    const pubMatch = pubIds.some((id) => matchIds.has(id));
    const pGoal = normalizeGoalKey(p.goalId);
    const goalMatch = goalKey ? pGoal === goalKey : pGoal === null;
    if (!goalMatch || !pubMatch) return;
    // GEO must match exactly (normalized set). IN ≠ ALL.
    const haveGeo = geoKeyOf(p.geo);
    if (haveGeo !== wantGeo) {
      console.log(`[payout-match] Geo mismatch: ${haveGeo} != ${wantGeo}`, { payoutId: p.id });
      return;
    }
    specificMatches.push(p);
  });
  if (!specificMatches.length) return undefined;
  if (adjustedPayout == null) return specificMatches[0];
  // Prefer an exact payout match so identical rows classify as Duplicate.
  const exact = specificMatches.find(
    (p) => Math.round(p.payout * 10000) === Math.round(adjustedPayout * 10000),
  );
  return exact ?? specificMatches[0];
}

function computeStatus(existing: ExistingPayout | undefined, adjusted: number): RowStatus {
  if (!existing) return "new";
  // round to 4 decimals (matches our adjustedPayout precision) to avoid float noise
  const a = Math.round(existing.payout * 10000) / 10000;
  const b = Math.round(adjusted * 10000) / 10000;
  return a === b ? "duplicate" : "will_update";
}

function logMatch(args: {
  campaignId: string;
  publisherId: string;
  matchIds: string[];
  goalId: string | null;
  geo: string[];
  adjusted: number;
  existing?: ExistingPayout;
  status: RowStatus;
}) {
  console.log("[payout-match]", {
    campaignId: args.campaignId,
    publisherId: args.publisherId,
    publisherMatchIds: args.matchIds,
    goalId: args.goalId ?? "default",
    requestedGeo: args.geo,
    calculatedPayout: args.adjusted,
    existingPayoutId: args.existing?.id ?? null,
    existingPubIds: args.existing?.pubIds ?? null,
    existingGoalId: args.existing?.goalId ?? null,
    existingGeo: args.existing?.geo ?? null,
    existingPayout: args.existing?.payout ?? null,
    status: args.status.toUpperCase(),
  });
}

const Index = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [publishers, setPublishers] = useState<Publisher[]>([]);
  const [loadingCampaigns, setLoadingCampaigns] = useState(false);
  const [loadingPublishers, setLoadingPublishers] = useState(false);
  const [campaignPage, setCampaignPage] = useState(0);
  const [publisherPage, setPublisherPage] = useState(0);
  const [campaignsHasMore, setCampaignsHasMore] = useState(true);
  const [publishersHasMore, setPublishersHasMore] = useState(true);

  const [campaignIds, setCampaignIds] = useState<string[]>([]);
  const [publisherIds, setPublisherIds] = useState<string[]>([]);
  const [applyAll, setApplyAll] = useState<boolean>(false);
  const [percentage, setPercentage] = useState<number>(100);
  const [rows, setRows] = useState<PayoutRow[]>([]);
  const [fetching, setFetching] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [results, setResults] = useState<{ success: any[]; failed: any[] } | null>(null);

  // Publisher assignment
  const [assignAction, setAssignAction] = useState<string>("assign");
  const [assigning, setAssigning] = useState(false);

  // Search terms are pushed to the database (indexed) instead of filtering in the browser.
  const [campaignQuery, setCampaignQuery] = useState("");
  const [publisherQuery, setPublisherQuery] = useState("");
  const [syncing, setSyncing] = useState(false);
  const [lastSync, setLastSync] = useState<string | null>(null);
  const [activeCampaignTotal, setActiveCampaignTotal] = useState<number | null>(null);

  const loadCampaigns = async (page = 1, append = false, q = campaignQuery) => {
    setLoadingCampaigns(true);
    const needle = escapeLike(q);
    let query = supabase
      .from("campaigns")
      .select("trackier_id,title,status,hash_id,raw")
      .eq("is_active", true);
    if (needle) query = query.or(`title.ilike.%${needle}%,trackier_id.ilike.%${needle}%`);
    const { data, error } = await query
      .order("title", { ascending: true, nullsFirst: false })
      .range((page - 1) * PAGE_SIZE, page * PAGE_SIZE - 1);
    setLoadingCampaigns(false);
    if (error) {
      toast({ title: "Failed to load campaigns", description: error.message, variant: "destructive" });
      return;
    }
    // Data-level guard: even if a stale cache row slips through, inactive /
    // paused / archived campaigns never reach the selector.
    const incoming = (data ?? [])
      .map((row) => toCampaign(row as Record<string, unknown>))
      .filter((c) => isActiveCampaignRow(c as unknown as Record<string, unknown>));
    if (page === 1 && !needle) {
      const { count } = await supabase
        .from("campaigns")
        .select("trackier_id", { count: "exact", head: true })
        .eq("is_active", true)
        .ilike("status", "active");
      if (count != null) setActiveCampaignTotal(count);
    }
    setCampaignPage(page);
    setCampaignsHasMore(incoming.length === PAGE_SIZE);
    setCampaigns((current) => mergeById(append ? current : [], incoming));
  };

  const loadPublishers = async (page = 1, append = false, q = publisherQuery) => {
    setLoadingPublishers(true);
    const needle = escapeLike(q);
    let query = supabase.from("publishers").select("trackier_id,name,hash_id,long_id,status,raw");
    if (needle) query = query.or(`name.ilike.%${needle}%,trackier_id.ilike.%${needle}%`);
    const { data, error } = await query
      .order("name", { ascending: true, nullsFirst: false })
      .range((page - 1) * PAGE_SIZE, page * PAGE_SIZE - 1);
    setLoadingPublishers(false);
    if (error) {
      toast({ title: "Failed to load publishers", description: error.message, variant: "destructive" });
      return;
    }
    const incoming = (data ?? []).map((row) => toPublisher(row as Record<string, unknown>));
    setPublisherPage(page);
    setPublishersHasMore(incoming.length === PAGE_SIZE);
    setPublishers((current) => mergeById(append ? current : [], incoming));
  };

  const loadLastSync = async () => {
    const { data } = await supabase
      .from("sync_runs")
      .select("finished_at,status,entity,records_upserted")
      .in("status", ["success", "partial"])
      .order("finished_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (data?.finished_at) setLastSync(new Date(data.finished_at as string).toLocaleString());
    return (data?.finished_at as string | undefined) ?? null;
  };

  // Initial load
  useEffect(() => {
    // Keep the cache warm: refresh in the background when it is older than 30 min.
    void (async () => {
      const finishedAt = await loadLastSync();
      // sync_runs is admin-only, so non-admins never see a timestamp. Auto-sync at
      // most once per browser session to avoid a refresh storm.
      if (!finishedAt) {
        if (sessionStorage.getItem("autoSyncDone")) return;
        sessionStorage.setItem("autoSyncDone", "1");
        void handleSync();
        return;
      }
      const stale = !finishedAt || Date.now() - new Date(finishedAt).getTime() > 30 * 60 * 1000;
      if (stale) void handleSync();
    })();
  }, []);

  // Debounced server-side search — the dropdown never waits on Trackier.
  useEffect(() => {
    const t = setTimeout(() => { void loadCampaigns(1, false, campaignQuery); }, 250);
    return () => clearTimeout(t);
  }, [campaignQuery]);

  useEffect(() => {
    const t = setTimeout(() => { void loadPublishers(1, false, publisherQuery); }, 250);
    return () => clearTimeout(t);
  }, [publisherQuery]);

  const handleSync = async () => {
    setSyncing(true);
    // Each call runs within the edge-function time budget and reports where it
    // stopped, so we resume until every page is cached.
    const totals: Record<string, number> = {};
    let failure: string | null = null;
    for (const entity of ["campaigns", "publishers"] as const) {
      let startPage = 1;
      for (let hop = 0; hop < 20; hop++) {
        const { data, error } = await supabase.functions.invoke(
          `sync-trackier?entity=${entity}&startPage=${startPage}`,
          { body: { entity } },
        );
        if (error) { failure = error.message; break; }
        const r = ((data as any)?.results ?? [])[0];
        if (!r) break;
        totals[entity] = (totals[entity] ?? 0) + Number(r.records ?? 0);
        if (r.error) { failure = String(r.error); break; }
        if (r.done || r.skipped) break;
        startPage = Number(r.nextPage ?? startPage + 1);
      }
      if (failure) break;
    }
    setSyncing(false);
    toast({
      title: failure ? "Sync finished with errors" : "Sync complete",
      description:
        Object.entries(totals).map(([k, v]) => `${k}: ${v}`).join(" · ") + (failure ? ` — ${failure}` : ""),
      variant: failure ? "destructive" : undefined,
    });
    await Promise.all([loadLastSync(), loadCampaigns(1, false), loadPublishers(1, false)]);
  };

  const handleFetch = async () => {
    if (!campaignIds.length) {
      toast({ title: "Select at least one campaign", variant: "destructive" });
      return;
    }
    if (!applyAll && !publisherIds.length) {
      toast({ title: "Select at least one publisher (or check Apply to all)", variant: "destructive" });
      return;
    }
    setFetching(true);
    setResults(null);
    const session = (await supabase.auth.getSession()).data.session;

    const allRows: PayoutRow[] = [];
    const failedCampaigns: string[] = [];

    for (const cid of campaignIds) {
      const resp = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/trackier-goals?campaignId=${encodeURIComponent(cid)}`,
        {
          headers: {
            Authorization: `Bearer ${session?.access_token}`,
            apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          },
        }
      );
      const goalsData = await resp.json();
      if (!resp.ok) {
        failedCampaigns.push(cid);
        continue;
      }

      const camp = campaigns.find((c) => String(c.id) === String(cid));
      const campName = camp?.title || camp?.name || `Campaign ${cid}`;
      const goals: Goal[] = goalsData.goals || [];
      const isDefault = !!goalsData.isDefault || goals.length === 0;
      const defaultRevenue = Number(goalsData.defaultRevenue ?? goalsData.basePayout ?? 0);
      const existingPayouts: ExistingPayout[] = (goalsData.existingPayouts || []) as ExistingPayout[];

      const targetPubs: { id: string; name: string; matchIds: string[] }[] = applyAll
        ? [{ id: ALL_PUBLISHERS_ID, name: "All publishers", matchIds: [] }]
        : publisherIds.map((pid) => {
            const pub = publishers.find((p) => String(p.id) === String(pid));
            const matchIds = [
              pid,
              pub?.hashId,
              pub?.publisherLongId,
              pub?.longId,
              pub?._id,
            ].map((v) => String(v ?? '').trim()).filter(Boolean);
            return { id: pid, name: pub?.company || pub?.name || `Publisher ${pid}`, matchIds };
          });

      for (const pub of targetPubs) {
        const isAll = pub.id === ALL_PUBLISHERS_ID;
        if (isDefault) {
          const base = defaultRevenue;
          const adjusted = +(base * percentage / 100).toFixed(4);
          const geos = isAll ? [["ALL"]] : requestedGeosFor(existingPayouts, pub.matchIds, null);
          for (const geo of geos) {
          const existing = isAll ? undefined : findExistingPayout(existingPayouts, pub.matchIds, null, adjusted, geo);
          const status = isAll ? "new" : computeStatus(existing, adjusted);
          logMatch({ campaignId: cid, publisherId: pub.id, matchIds: pub.matchIds, goalId: null, geo, adjusted, existing, status });
          allRows.push({
            key: `${cid}-default-${pub.id}-${geo.join(",")}`,
            geo,
            campaignId: cid, campaignName: campName,
            goalId: null, goalLabel: "default",
            basePayout: base,
            adjustedPayout: adjusted,
            publisherId: pub.id, publisherName: pub.name,
            status,
            existingPayout: existing ? existing.payout : null,
            existingPayoutId: existing ? existing.id : null,
            publisherMatchIds: pub.matchIds,
            isDuplicate: status === "duplicate",
          });
          }
        } else {
          for (const g of goals) {
            const rev = Number(g.revenue ?? 0);
            const pay = Number(g.payout ?? 0);
            const base = rev > 0 ? rev : pay;
            const adjusted = +(base * percentage / 100).toFixed(4);
            const geos = isAll ? [["ALL"]] : requestedGeosFor(existingPayouts, pub.matchIds, String(g.id));
            for (const geo of geos) {
            const existing = isAll ? undefined : findExistingPayout(existingPayouts, pub.matchIds, String(g.id), adjusted, geo);
            const status = isAll ? "new" : computeStatus(existing, adjusted);
            logMatch({ campaignId: cid, publisherId: pub.id, matchIds: pub.matchIds, goalId: String(g.id), geo, adjusted, existing, status });
            allRows.push({
              key: `${cid}-${g.id}-${pub.id}-${geo.join(",")}`,
              geo,
              campaignId: cid, campaignName: campName,
              goalId: String(g.id), goalLabel: g.title || g.name || `Goal ${g.id}`,
              basePayout: base,
              adjustedPayout: adjusted,
              publisherId: pub.id, publisherName: pub.name,
              status,
              existingPayout: existing ? existing.payout : null,
              existingPayoutId: existing ? existing.id : null,
              publisherMatchIds: pub.matchIds,
              isDuplicate: status === "duplicate",
            });
            }
          }
        }
      }
    }

    setRows(allRows);
    setFetching(false);
    if (failedCampaigns.length) {
      toast({ title: `Failed to fetch ${failedCampaigns.length} campaign(s)`, description: failedCampaigns.join(", "), variant: "destructive" });
    }
    if (!allRows.length) {
      toast({ title: "No rows to display", variant: "destructive" });
    } else {
      toast({ title: `${allRows.length} payout rows ready` });
    }
  };

  // Recompute status whenever the adjusted payout changes (slider or manual edit)
  const recomputeStatus = (r: PayoutRow): PayoutRow => {
    if (r.publisherId === ALL_PUBLISHERS_ID) return { ...r, status: "new", isDuplicate: false };
    if (r.existingPayout == null) return { ...r, status: "new", isDuplicate: false };
    const a = Math.round(r.existingPayout * 10000) / 10000;
    const b = Math.round(r.adjustedPayout * 10000) / 10000;
    const status: RowStatus = a === b ? "duplicate" : "will_update";
    return { ...r, status, isDuplicate: status === "duplicate" };
  };

  // Live update adjusted payouts when slider moves
  useEffect(() => {
    setRows((prev) =>
      prev.map((r) => recomputeStatus({
        ...r,
        adjustedPayout: +(r.basePayout * percentage / 100).toFixed(4),
      }))
    );
  }, [percentage]);

  const updateRowPayout = (key: string, val: number) => {
    setRows((prev) => prev.map((r) => (r.key === key ? recomputeStatus({ ...r, adjustedPayout: val }) : r)));
  };

  const handleReset = () => {
    setCampaignIds([]);
    setPublisherIds([]);
    setApplyAll(false);
    setPercentage(100);
    setRows([]);
    setResults(null);
  };

  const handleUpload = async () => {
    // Skip duplicates — only upload "new" or "will_update" rows
    const toUpload = rows.filter((r) => r.status !== "duplicate");
    const skipped = rows.length - toUpload.length;
    if (!toUpload.length) {
      toast({
        title: "Nothing to upload",
        description: skipped ? `${skipped} row(s) are duplicates and were skipped.` : undefined,
        variant: "destructive",
      });
      return;
    }
    console.log("[upload] sending", toUpload.length, "row(s); skipped", skipped, "duplicate(s)");
    setUploading(true);
    const uploadRows = toUpload.map((r) => ({
          campaignId: r.campaignId,
          goalId: r.goalId || undefined,
          publisherId: r.publisherId === ALL_PUBLISHERS_ID ? undefined : r.publisherId,
          publisherMatchIds: r.publisherMatchIds,
          applyAll: r.publisherId === ALL_PUBLISHERS_ID,
          basePayout: r.basePayout,
          adjustedPayout: r.adjustedPayout,
          percentage,
          existingPayoutId: r.existingPayoutId || undefined,
          geo: r.geo ?? ["ALL"],
        }));
    const combined = { success: [] as unknown[], failed: [] as unknown[] };
    const batchSize = 8;

    try {
      for (let start = 0; start < uploadRows.length; start += batchSize) {
        const batch = uploadRows.slice(start, start + batchSize);
        const { data, error } = await supabase.functions.invoke("trackier-upload-payouts", {
          body: { rows: batch },
        });
        if (error) {
          combined.failed.push(...batch.map((row) => ({ row, reason: error.message })));
          continue;
        }
        const result = data as { success?: unknown[]; failed?: unknown[] } | null;
        combined.success.push(...(result?.success ?? []));
        combined.failed.push(...(result?.failed ?? []));
      }
    } finally {
      setUploading(false);
    }
    setResults(combined as any);
    toast({
      title: "Upload complete",
      description: `${combined.success.length} succeeded · ${combined.failed.length} failed${skipped ? ` · ${skipped} duplicate(s) skipped` : ""}`,
      variant: combined.success.length === 0 && combined.failed.length > 0 ? "destructive" : undefined,
    });
  };

  const filteredCampaigns = useMemo(() => campaigns, [campaigns]);

  const handlePublisherAction = async () => {
    if (!campaignIds.length) {
      toast({ title: "Select at least one campaign", variant: "destructive" });
      return;
    }
    if (!publisherIds.length) {
      toast({ title: "Select at least one publisher", variant: "destructive" });
      return;
    }
    if (!assignAction) {
      toast({ title: "Select an action", variant: "destructive" });
      return;
    }
    // Trackier v2 Admin API uses numeric ids for campaigns and publishers
    // (matching the GET /campaigns and GET /publishers responses).
    const payload = {
      campaign_ids: campaignIds.map((v) => Number(v)).filter((n) => Number.isFinite(n)),
      publisher_ids: publisherIds.map((v) => Number(v)).filter((n) => Number.isFinite(n)),
      type: assignAction,
    };
    console.log("[publisher-action] selected campaigns", campaignIds);
    console.log("[publisher-action] selected publishers", publisherIds);
    console.log("[publisher-action] action", assignAction);
    console.log("[publisher-action] payload", payload);
    setAssigning(true);
    const { data, error } = await supabase.functions.invoke("campaign-publisher-action", { body: payload });
    setAssigning(false);
    console.log("[publisher-action] response", { data, error });
    if (error) {
      toast({ title: "Action failed", description: error.message, variant: "destructive" });
      return;
    }
    const d = data as any;
    const succeeded = Number(d?.requestsSucceeded ?? 0);
    const failed = Number(d?.requestsFailed ?? 0);
    const attempts: any[] = Array.isArray(d?.results) ? d.results : Array.isArray(d?.attempts) ? d.attempts : [];
    console.log("[publisher-action] attempts", attempts);
    const attemptSummary = attempts
      .map((a) => {
        const body = typeof a?.response === "string" ? a.response : JSON.stringify(a?.response);
        return `${a?.status} ${a?.method} ${a?.endpoint} → ${String(body).slice(0, 160)}`;
      })
      .join("\n");
    if (d?.ok) {
      toast({
        title: `Publishers ${assignAction} successful`,
        description: `${succeeded} request(s) succeeded on ${d?.endpoint ?? ""}`,
      });
    } else {
      const responseBody = typeof d?.response === "string" ? d.response : JSON.stringify(d?.response);
      toast({
        title: `Trackier returned HTTP ${d?.status ?? "error"}`,
        description: responseBody || attemptSummary || `${succeeded} succeeded · ${failed} failed.`,
        variant: "destructive",
      });
    }
  };

  const newCount = rows.filter((r) => r.status === "new").length;
  const updateCount = rows.filter((r) => r.status === "will_update").length;
  const duplicateCount = rows.filter((r) => r.status === "duplicate").length;
  const readyCount = newCount + updateCount;
  const selectionComplete = campaignIds.length > 0;
  const publisherComplete = applyAll || publisherIds.length > 0;
  const reviewComplete = rows.length > 0;

  return (
    <AppShell>
      <h1 className="sr-only">Campaign Console — Manage Trackier Payouts</h1>
      <div className="mb-5 flex flex-col gap-3 border-b hairline pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
                    <h2 className="font-display text-2xl font-semibold leading-tight">Campaign Console</h2>
          <p className="mt-1 text-sm text-muted-foreground">Select, adjust, review, and publish Trackier payouts.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-[10px] font-semibold uppercase text-muted-foreground">Last sync</p>
            <p className="mt-0.5 text-xs font-medium">{lastSync ?? "Never"}</p>
          </div>
          <span className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <span className={cn("h-1.5 w-1.5 rounded-full", syncing ? "animate-pulse bg-warning" : lastSync ? "bg-success" : "bg-muted-foreground")} />
            {syncing ? "Syncing" : lastSync ? "Synced" : "Idle"}
          </span>
          <Button size="sm" variant="outline" onClick={handleSync} disabled={syncing}>
            {syncing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <DatabaseZap className="mr-2 h-4 w-4" />}
            Sync now
          </Button>
        </div>
      </div>

      <div>
        <div className="min-w-0 space-y-6">
          <div className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border hairline bg-border sm:grid-cols-4">
            <KpiCard icon={<Megaphone className="h-4 w-4" />} label="Active campaigns" value={String(activeCampaignTotal ?? campaigns.length)} hint="active in Trackier" />
            <KpiCard icon={<Users2 className="h-4 w-4" />} label="Publishers" value={String(publishers.length)} hint="loaded in cache" />
            <KpiCard icon={<ListChecks className="h-4 w-4" />} label="Changes ready" value={String(readyCount)} hint="new or updating" />
            <KpiCard icon={<Activity className="h-4 w-4" />} label="API status" value="Healthy" tone="success" hint="Trackier reachable" />
          </div>

          <p className="-mb-3 text-[11px] font-bold uppercase text-muted-foreground">Campaign &amp; publisher selection</p>
          <div className="grid gap-0 overflow-hidden rounded-xl border hairline bg-card shadow-soft lg:grid-cols-2 lg:divide-x lg:divide-border">
            <section id="campaigns" className="p-4 sm:p-5">
              <div className="mb-5 flex items-start justify-between gap-3">
                <div className="flex gap-3">
                  
                  <div>
                    <h3 className="font-display text-lg font-semibold">Campaigns</h3>
                    <p className="mt-1 text-xs text-muted-foreground">Only active campaigns are available.</p>
                  </div>
                </div>
                <span className={cn("chip", campaignIds.length && "border-success/30 bg-success/10 text-success")}>{campaignIds.length} selected</span>
              </div>
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Tip content="Search campaigns by ID or name. You can select multiple campaigns." side="bottom">
                    <div className="flex min-w-0 flex-1"><CampaignMultiSelect campaigns={campaigns} loading={loadingCampaigns} value={campaignIds} onChange={setCampaignIds} hasMore={campaignsHasMore} onLoadMore={() => loadCampaigns(campaignPage + 1, true)} query={campaignQuery} onQueryChange={setCampaignQuery} /></div>
                  </Tip>
                  <Tip content="Refresh the latest campaigns from the local cache."><Button variant="outline" size="icon" onClick={() => loadCampaigns(1, false)} disabled={loadingCampaigns} aria-label="Refresh campaigns">{loadingCampaigns ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}</Button></Tip>
                </div>
                <Input placeholder="Paste campaign IDs (comma-separated)" value={campaignIds.join(",")} onChange={(e) => setCampaignIds(Array.from(new Set(e.target.value.split(",").map((v) => v.trim()).filter(Boolean))))} />
                <p className="text-[11px] text-muted-foreground">Add multiple IDs separated by commas.</p>
                <SelectionChips ids={campaignIds} emptyLabel="Select active campaigns to begin." resolve={(id) => { const c = campaigns.find((x) => String(x.id) === id); return c ? (c.title || c.name || `Campaign ${id}`) : `Campaign ${id}`; }} onRemove={(id) => setCampaignIds(campaignIds.filter((v) => v !== id))} />
              </div>
            </section>

            <section id="publishers" className="border-t hairline p-4 sm:p-5 lg:border-t-0">
              <div className="mb-5 flex items-start justify-between gap-3">
                <div className="flex gap-3">
                  
                  <div><h3 className="font-display text-lg font-semibold">Publishers</h3><p className="mt-1 text-xs text-muted-foreground">Search by ID or name, or paste multiple IDs.</p></div>
                </div>
                <span className={cn("chip", publisherComplete && "border-success/30 bg-success/10 text-success")}>{applyAll ? "All" : publisherIds.length} selected</span>
              </div>
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Tip content="Search publishers by ID or name. Select one or more publishers." side="bottom"><div className="flex min-w-0 flex-1"><PublisherMultiSelect publishers={publishers} loading={loadingPublishers} value={publisherIds} onChange={setPublisherIds} disabled={applyAll} hasMore={publishersHasMore} onLoadMore={() => loadPublishers(publisherPage + 1, true)} query={publisherQuery} onQueryChange={setPublisherQuery} /></div></Tip>
                  <Tip content="Refresh the latest publishers from the local cache."><Button variant="outline" size="icon" onClick={() => loadPublishers(1, false)} disabled={loadingPublishers} aria-label="Refresh publishers">{loadingPublishers ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}</Button></Tip>
                </div>
                <Input placeholder="Paste publisher IDs (comma-separated)" value={publisherIds.join(",")} disabled={applyAll} onChange={(e) => { const parsed = Array.from(new Set(e.target.value.split(",").map((v) => v.trim()).filter(Boolean))); const unknown = parsed.filter((id) => !publishers.some((p) => String(p.id) === id)); if (unknown.length) toast({ title: `Unrecognized publisher ID(s): ${unknown.join(", ")}`, description: "They were added anyway — sync publishers if the list is outdated." }); setPublisherIds(parsed); }} />
                <p className="text-[11px] text-muted-foreground">Add multiple IDs separated by commas.</p>
                <Tip content="Apply this payout to every publisher instead of only the selected publishers." side="bottom">
                  <label className={cn("flex cursor-pointer items-start gap-3 rounded-md border px-3 py-3 text-sm transition-colors", applyAll ? "border-primary/40 bg-primary/10" : "hairline bg-surface-1/50 hover:bg-secondary/40")}>
                    <Checkbox checked={applyAll} onCheckedChange={(c) => { const value = !!c; setApplyAll(value); if (value) setPublisherIds([]); }} />
                    <span><span className="block font-semibold">Apply to all publishers</span><span className="mt-0.5 block text-xs text-muted-foreground">Overrides the selected publisher list.</span></span>
                  </label>
                </Tip>
                {!applyAll && <SelectionChips ids={publisherIds} emptyLabel="Select publishers for these campaigns." resolve={(id) => { const p = publishers.find((x) => String(x.id) === id); return p ? (p.company || p.name || `Publisher ${id}`) : `Publisher ${id}`; }} onRemove={(id) => setPublisherIds(publisherIds.filter((v) => v !== id))} />}
              </div>
            </section>
          </div>

          <section id="adjustment" className="rounded-xl border hairline bg-card p-4 shadow-soft sm:p-5">
            <div className="mb-4 flex items-start justify-between gap-3">
              <div className="flex gap-3"><div><h3 className="font-display text-lg font-semibold">Payout Adjustment</h3><p className="mt-1 text-xs text-muted-foreground">Adjusted payout = Base × adjustment %.</p></div></div>
              <Button variant="ghost" size="sm" onClick={handleReset}><RotateCcw className="mr-2 h-4 w-4" />Reset</Button>
            </div>
            <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_340px] xl:items-center">
              <div className="grid items-center gap-3 rounded-lg border hairline bg-surface-1/50 p-4 sm:grid-cols-[1fr_auto_1fr_auto_1fr]">
                <div><p className="text-[10px] font-bold uppercase text-muted-foreground">Base payout</p><p className="mt-1.5 font-mono text-2xl font-semibold tabular-nums">{rows.length ? rows[0].basePayout.toFixed(2) : "—"}</p><p className="mt-0.5 text-[11px] text-muted-foreground">From Trackier · read-only</p></div>
                <span className="hidden font-mono text-lg text-muted-foreground sm:block">×</span>
                <div>
                  <Label htmlFor="payout-percentage" className="text-[10px] font-bold uppercase text-primary">Adjustment</Label>
                  <div className="relative mt-1.5 w-32"><Input id="payout-percentage" type="number" inputMode="numeric" min={0} max={100} step={1} value={percentage} onChange={(e) => { const n = Number(e.target.value); if (!Number.isNaN(n)) setPercentage(Math.min(100, Math.max(0, Math.round(n)))); }} className="h-12 border-primary/40 pr-9 text-right font-mono text-2xl font-semibold tabular-nums focus-visible:ring-primary" aria-label="Payout adjustment percentage" /><span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 font-mono text-lg text-muted-foreground">%</span></div>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">Type 0–100</p>
                </div>
                <span className="hidden font-mono text-lg text-muted-foreground sm:block">=</span>
                <div><p className="text-[10px] font-bold uppercase text-muted-foreground">Adjusted payout</p><p className="mt-1.5 font-mono text-3xl font-semibold tabular-nums text-primary">{rows.length ? rows[0].adjustedPayout.toFixed(2) : "—"}</p><p className="mt-0.5 text-[11px] text-muted-foreground">Calculated · read-only</p></div>
              </div>
              <Tip content="Adjusted payout is calculated from the existing Trackier base payout." side="left">
                <div className="space-y-3">
                  <div className="grid grid-cols-4 gap-2">
                    {[50, 75, 100].map((preset) => <Button key={preset} type="button" size="sm" variant={percentage === preset ? "default" : "outline"} aria-pressed={percentage === preset} onClick={() => setPercentage(preset)}>{preset}%</Button>)}
                    <Button type="button" size="sm" variant={[50, 75, 100].includes(percentage) ? "outline" : "default"} onClick={() => document.getElementById("payout-percentage")?.focus()}>Custom</Button>
                  </div>
                  <Slider aria-label="Payout adjustment percentage slider" value={[percentage]} onValueChange={([value]) => setPercentage(Math.min(100, value))} min={0} max={100} step={1} />
                  <div className="flex justify-between font-mono text-[10px] text-muted-foreground"><span>0%</span><span>50%</span><span>100%</span></div>
                </div>
              </Tip>
            </div>
            <div className="mt-4 flex justify-end"><Tip content="Fetch campaign goals, revenue and existing publisher payouts, then calculate the adjusted payout." side="left"><Button onClick={handleFetch} disabled={fetching || !selectionComplete || !publisherComplete}>{fetching ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}{fetching ? "Fetching payout data…" : "Fetch payout data"}</Button></Tip></div>
          </section>

          <section className="rounded-xl border hairline bg-card p-4 shadow-soft sm:p-5">
            <div className="mb-5 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
              <div><h3 className="font-display text-lg font-semibold">Publisher Assignment</h3><p className="mt-1 text-xs text-muted-foreground">Assign, remove, block or unblock selected publishers.</p></div>
              <div className="flex flex-wrap items-end gap-2">
                <div className="w-36"><Label className="mb-1.5 block text-[10px] font-bold uppercase text-muted-foreground">Action</Label><Select value={assignAction} onValueChange={setAssignAction}><SelectTrigger><SelectValue placeholder="Choose action" /></SelectTrigger><SelectContent><SelectItem value="assign">Assign</SelectItem><SelectItem value="remove">Remove</SelectItem><SelectItem value="block">Block</SelectItem><SelectItem value="unblock">Unblock</SelectItem></SelectContent></Select></div>
                <Button onClick={handlePublisherAction} disabled={assigning || !campaignIds.length || !publisherIds.length} variant="outline">{assigning ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Wand2 className="mr-2 h-4 w-4" />}{assigning ? "Assigning publishers…" : "Apply action"}</Button>
              </div>
            </div>
            <div className="flex flex-wrap gap-4 text-xs text-muted-foreground"><span><strong className="font-mono text-foreground">{campaignIds.length}</strong> campaigns</span><span><strong className="font-mono text-foreground">{publisherIds.length}</strong> publishers</span><span><strong className="font-mono text-foreground">{campaignIds.length * publisherIds.length}</strong> affected combinations</span></div>
          </section>

          <section id="review" className="rounded-xl border hairline bg-card p-4 shadow-soft sm:p-5">
            <div className="mb-4 flex gap-3"><div><h3 className="font-display text-lg font-semibold">Review Changes &amp; Payout Preview</h3><p className="mt-1 text-xs text-muted-foreground">Review exactly what will be created, updated, or skipped.</p></div></div>
            <div className="mb-4 grid grid-cols-2 gap-px overflow-hidden rounded-lg border hairline bg-border sm:grid-cols-4">
              {[{label:"Total",value:rows.length,cls:""},{label:"New",value:newCount,cls:"text-success"},{label:"Will update",value:updateCount,cls:"text-warning"},{label:"Duplicate",value:duplicateCount,cls:"text-muted-foreground"}].map((item) => <div key={item.label} className="bg-card px-4 py-3"><p className={cn("font-mono text-2xl font-semibold",item.cls)}>{item.value}</p><p className="mt-1 text-[10px] font-bold uppercase text-muted-foreground">{item.label}</p></div>)}
            </div>
            {!rows.length ? <EmptyState icon={fetching ? <Loader2 className="h-5 w-5 animate-spin" /> : <Inbox className="h-5 w-5" />} title={fetching ? "Fetching payout data…" : "Select campaigns and publishers to begin"} description="Your payout review will appear here before anything is sent to Trackier." /> : (
              <div className="max-h-[560px] overflow-auto rounded-lg border hairline">
                <Table><TableHeader className="sticky top-0 z-10 bg-surface-2/95 backdrop-blur"><TableRow className="hover:bg-transparent"><TableHead>Campaign</TableHead><TableHead>Campaign ID</TableHead><TableHead>Goal</TableHead><TableHead className="text-right">Base payout</TableHead><TableHead className="text-right">Adjustment</TableHead><TableHead className="text-right">Adjusted payout</TableHead><TableHead>Publisher</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
                  <TableBody>{rows.map((row) => <TableRow key={row.key} className={cn("transition-colors hover:bg-secondary/40", row.status === "duplicate" && "opacity-60")}><TableCell className="font-medium">{row.campaignName}</TableCell><TableCell className="font-mono text-xs text-muted-foreground">{row.campaignId}</TableCell><TableCell>{row.goalId ? <span className="text-xs"><span className="block">{row.goalLabel}</span><span className="font-mono text-muted-foreground">{row.goalId}</span></span> : <Badge variant="outline">default</Badge>}<span className="mt-1 block font-mono text-[10px] text-muted-foreground">Geo {(row.geo ?? ["ALL"]).join(", ")}</span></TableCell><TableCell className="text-right font-mono font-semibold">{row.basePayout.toFixed(2)}</TableCell><TableCell className="text-right font-mono text-muted-foreground tabular-nums">{row.basePayout ? `${Math.round((row.adjustedPayout / row.basePayout) * 100)}%` : `${percentage}%`}</TableCell><TableCell className="text-right font-mono text-base font-semibold tabular-nums text-primary">{row.adjustedPayout.toFixed(2)}</TableCell><TableCell><div>{row.publisherName}</div><div className="font-mono text-xs text-muted-foreground">#{row.publisherId}</div></TableCell><TableCell><Tip content={statusBadge[row.status].help}><span className={cn("chip cursor-help uppercase", statusBadge[row.status].className)}>{statusBadge[row.status].label}</span></Tip></TableCell></TableRow>)}</TableBody>
                </Table>
              </div>
            )}
          </section>

          <section id="upload" className="rounded-xl border hairline bg-card p-4 shadow-soft sm:p-5">
            <div className="grid gap-6 lg:grid-cols-[1fr_auto] lg:items-center">
              <div className="flex gap-3"><div><h3 className="font-display text-lg font-semibold">Upload</h3><p className="mt-1 text-sm font-medium">{readyCount ? `${readyCount} changes ready` : rows.length ? "No changes to apply" : "Complete the review first"}</p><p className="mt-2 text-xs text-muted-foreground">{newCount} new payouts · {updateCount} existing payouts will be updated · {duplicateCount} duplicates will be skipped</p></div></div>
              <Tip content="Creates new publisher-specific payouts or updates existing ones based on the current selection." side="left"><Button onClick={handleUpload} disabled={uploading || !readyCount} size="lg" className="min-w-48 shadow-glow">{uploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}{uploading ? "Updating payouts…" : "Upload payouts"}</Button></Tip>
            </div>
          </section>

          {results && <section className="grid animate-fade-in grid-cols-1 gap-3 md:grid-cols-2"><div className="rounded-lg border border-success/25 bg-success/5 p-4"><div className="mb-2 flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-success" /><h3 className="text-sm font-semibold">Success ({results.success.length})</h3></div><ul className="max-h-40 space-y-1 overflow-auto font-mono text-xs text-muted-foreground">{results.success.map((item, index) => <li key={index}>✓ {item.campaignId}/{item.goalId || "default"} → {item.publisherId} = {item.adjustedPayout}</li>)}{!results.success.length && <li>No successful uploads.</li>}</ul></div><div className="rounded-lg border border-destructive/25 bg-destructive/5 p-4"><div className="mb-2 flex items-center gap-2"><XCircle className="h-4 w-4 text-destructive" /><h3 className="text-sm font-semibold">Failed ({results.failed.length})</h3></div><ul className="max-h-40 space-y-1 overflow-auto font-mono text-xs text-muted-foreground">{results.failed.map((item, index) => <Tip key={index} content={String(item.reason ?? "Unknown error")}><li className="cursor-help truncate">✗ {item.row?.publisherId} — {item.reason}</li></Tip>)}{!results.failed.length && <li>No failures.</li>}</ul></div></section>}
        </div>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t hairline bg-background/95 px-4 py-3 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1468px] items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-3 overflow-x-auto text-xs">
            <span className="shrink-0"><CheckCircle2 className={cn("mr-1 inline h-3.5 w-3.5", selectionComplete ? "text-success" : "text-muted-foreground")} />{campaignIds.length} campaigns</span>
            <span className="shrink-0"><CheckCircle2 className={cn("mr-1 inline h-3.5 w-3.5", publisherComplete ? "text-success" : "text-muted-foreground")} />{applyAll ? "All" : publisherIds.length} publishers</span>
            <span className="hidden shrink-0 sm:inline"><CheckCircle2 className="mr-1 inline h-3.5 w-3.5 text-success" />{percentage}% adjustment</span>
            <strong className="shrink-0 font-mono">{readyCount} changes ready</strong>
          </div>
          <div className="flex shrink-0 gap-2"><Button variant="outline" size="sm" onClick={() => document.getElementById("review")?.scrollIntoView({ behavior: "smooth" })}>Review</Button><Button size="sm" onClick={handleUpload} disabled={uploading || !readyCount}>{uploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}<span className="hidden sm:inline">Upload payouts</span><span className="sm:hidden">Upload</span></Button></div>
        </div>
      </div>
    </AppShell>
  );
};

// Multi-select for publishers (lightweight popover with search)
import {
  Popover, PopoverContent, PopoverTrigger,
} from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";

function PublisherMultiSelect({
  publishers, loading, value, onChange, disabled, hasMore, onLoadMore, query, onQueryChange,
}: {
  publishers: Publisher[]; loading: boolean; value: string[]; onChange: (v: string[]) => void; disabled?: boolean; hasMore: boolean; onLoadMore: () => void; query: string; onQueryChange: (v: string) => void;
}) {
  const [page, setPage] = useState(1);
  const pageSize = 100;
  // Searching happens in the database, so the list here is already the result set.
  const filtered = publishers;
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  useEffect(() => { setPage(1); }, [query]);
  const currentPage = Math.min(page, totalPages);
  const pageItems = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);
  const toggle = (id: string) => {
    console.log("Selected publisher ID:", id);
    onChange(value.includes(id) ? value.filter((v) => v !== id) : [...value, id]);
  };
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" disabled={disabled} className="focus-ring h-10 flex-1 justify-between rounded-lg font-normal">
          {disabled
            ? "All publishers"
            : loading ? "Loading…" : value.length ? `${value.length} publisher(s)` : `Select publishers (${publishers.length})`}
          <ChevronRight className="h-4 w-4 rotate-90 text-muted-foreground" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[360px] overflow-hidden rounded-xl p-0 shadow-card" align="start" onOpenAutoFocus={(e) => e.preventDefault()}>
        <div className="sticky top-0 z-10 border-b hairline bg-popover p-2">
          <Input
            className="focus-ring h-9 rounded-lg"
            placeholder="Search publishers…"
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            onKeyDown={(e) => e.stopPropagation()}
            autoFocus
          />
        </div>
        <div className="max-h-72 space-y-0.5 overflow-auto p-2">
          {pageItems.map((p) => {
            const id = String(p.id);
            const checked = value.includes(id);
            return (
              <label
                key={id}
                className={cn(
                  "flex cursor-pointer items-center gap-2.5 rounded-lg px-2 py-2 text-sm transition-colors hover:bg-secondary/70",
                  checked && "bg-primary/10",
                )}
              >
                <Checkbox checked={checked} onCheckedChange={() => toggle(id)} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-medium">{getDisplayName(p as Record<string, unknown>) || `Publisher ${id}`}</span>
                  <span className="block font-mono text-xs text-muted-foreground">Publisher #{id}</span>
                </span>
              </label>
            );
          })}
          {!pageItems.length && <p className="p-3 text-center text-xs text-muted-foreground">No publishers match your search.</p>}
        </div>
        <div className="p-2 border-t flex items-center justify-between gap-2">
          <Button variant="ghost" size="sm" disabled={currentPage <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-xs text-muted-foreground">
            Page {currentPage} / {totalPages} · {filtered.length} items
          </span>
          <Button variant="ghost" size="sm" disabled={currentPage >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        {hasMore && (
          <div className="p-2 border-t">
            <Button variant="outline" size="sm" className="w-full" disabled={loading} onClick={onLoadMore}>
              {loading ? "Loading…" : "Load more publishers"}
            </Button>
          </div>
        )}
        <div className="flex items-center justify-between gap-2 border-t hairline p-2">
          <Button
            variant="ghost"
            size="sm"
            className="focus-ring h-8 rounded-lg text-xs"
            onClick={() => onChange(Array.from(new Set([...value, ...pageItems.map((it) => String(it.id))])))}
          >
            Select all visible
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="focus-ring h-8 rounded-lg text-xs"
            disabled={!value.length}
            onClick={() => onChange([])}
          >
            Clear ({value.length})
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

function CampaignMultiSelect({
  campaigns, loading, value, onChange, hasMore, onLoadMore, query, onQueryChange,
}: {
  campaigns: Campaign[]; loading: boolean; value: string[]; onChange: (v: string[]) => void; hasMore: boolean; onLoadMore: () => void; query: string; onQueryChange: (v: string) => void;
}) {
  const [page, setPage] = useState(1);
  const pageSize = 100;
  const filtered = campaigns;
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  useEffect(() => { setPage(1); }, [query]);
  const currentPage = Math.min(page, totalPages);
  const pageItems = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);
  const toggle = (id: string) => {
    onChange(value.includes(id) ? value.filter((v) => v !== id) : [...value, id]);
  };
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className="focus-ring h-10 flex-1 justify-between rounded-lg font-normal">
          {loading ? "Loading…" : value.length ? `${value.length} campaign(s)` : `Select campaigns (${campaigns.length})`}
          <ChevronRight className="h-4 w-4 rotate-90 text-muted-foreground" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[400px] overflow-hidden rounded-xl p-0 shadow-card" align="start" onOpenAutoFocus={(e) => e.preventDefault()}>
        <div className="sticky top-0 z-10 border-b hairline bg-popover p-2">
          <Input
            className="focus-ring h-9 rounded-lg"
            placeholder="Search campaigns…"
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            onKeyDown={(e) => e.stopPropagation()}
            autoFocus
          />
        </div>
        <div className="max-h-72 space-y-0.5 overflow-auto p-2">
          {pageItems.map((c) => {
            const id = String(c.id);
            const checked = value.includes(id);
            return (
              <label
                key={id}
                className={cn(
                  "flex cursor-pointer items-center gap-2.5 rounded-lg px-2 py-2 text-sm transition-colors hover:bg-secondary/70",
                  checked && "bg-primary/10",
                )}
              >
                <Checkbox checked={checked} onCheckedChange={() => toggle(id)} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-medium">{getDisplayName(c as Record<string, unknown>) || `Campaign ${id}`}</span>
                  <span className="block font-mono text-xs text-muted-foreground">Campaign #{id}</span>
                </span>
                {typeof c.status === "string" && c.status && (
                  <span className="chip shrink-0 border-success/30 bg-success/15 text-[10px] text-success">{c.status}</span>
                )}
              </label>
            );
          })}
          {!pageItems.length && <p className="p-3 text-center text-xs text-muted-foreground">No campaigns match your search.</p>}
        </div>
        <div className="p-2 border-t flex items-center justify-between gap-2">
          <Button variant="ghost" size="sm" disabled={currentPage <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-xs text-muted-foreground">
            Page {currentPage} / {totalPages} · {filtered.length} items
          </span>
          <Button variant="ghost" size="sm" disabled={currentPage >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        {hasMore && (
          <div className="p-2 border-t">
            <Button variant="outline" size="sm" className="w-full" disabled={loading} onClick={onLoadMore}>
              {loading ? "Loading…" : "Load more campaigns"}
            </Button>
          </div>
        )}
        <div className="flex items-center justify-between gap-2 border-t hairline p-2">
          <Button
            variant="ghost"
            size="sm"
            className="focus-ring h-8 rounded-lg text-xs"
            onClick={() => onChange(Array.from(new Set([...value, ...pageItems.map((it) => String(it.id))])))}
          >
            Select all visible
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="focus-ring h-8 rounded-lg text-xs"
            disabled={!value.length}
            onClick={() => onChange([])}
          >
            Clear ({value.length})
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

export default Index;
