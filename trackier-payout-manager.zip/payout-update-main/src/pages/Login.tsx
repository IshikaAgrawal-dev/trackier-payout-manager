import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Zap, Shield } from "lucide-react";
import { z } from "zod";

const schema = z.object({
  email: z.string().trim().email("Invalid email").max(255),
  password: z.string().min(8, "Min 8 characters").max(72),
});

const Login = () => {
  const { signIn, user, loading } = useAuth();
  const nav = useNavigate();
  const [params] = useSearchParams();
  const rawNext = params.get("next") ?? "";
  const nextPath = rawNext.startsWith("/") && !rawNext.startsWith("//") ? rawNext : "/";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [needsBootstrap, setNeedsBootstrap] = useState(false);
  const checking = false;

  useEffect(() => {
    if (user && !loading) nav(nextPath, { replace: true });
  }, [user, loading, nav, nextPath]);

  const handleSignInError = (msg: string) => {
    // If sign-in fails, optionally surface bootstrap UI when no admin exists.
    // We probe lazily here instead of on every page load.
    if (/invalid/i.test(msg)) {
      fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/bootstrap-admin`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({ _probe: true }),
      })
        .then((r) => r.json())
        .then((j) => {
          if (j?.error && !String(j.error).includes("already complete")) {
            setNeedsBootstrap(true);
          }
        })
        .catch(() => {});
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse({ email, password });
    if (!parsed.success) {
      toast({ title: "Invalid input", description: parsed.error.errors[0].message, variant: "destructive" });
      return;
    }
    setSubmitting(true);
    const { error } = await signIn(parsed.data.email, parsed.data.password);
    setSubmitting(false);
    if (error) {
      toast({ title: "Login failed", description: error, variant: "destructive" });
      handleSignInError(error);
    } else {
      toast({ title: "Welcome back" });
    }
  };

  const handleBootstrap = async () => {
    const parsed = schema.safeParse({ email, password });
    if (!parsed.success) {
      toast({ title: "Invalid input", description: parsed.error.errors[0].message, variant: "destructive" });
      return;
    }
    setSubmitting(true);
    const res = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/bootstrap-admin`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json", apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY },
        body: JSON.stringify({ email: parsed.data.email, password: parsed.data.password }),
      }
    );
    const j = await res.json();
    if (!res.ok) {
      setSubmitting(false);
      toast({ title: "Bootstrap failed", description: j.error, variant: "destructive" });
      return;
    }
    const { error } = await signIn(parsed.data.email, parsed.data.password);
    setSubmitting(false);
    if (error) toast({ title: "Login failed", description: error, variant: "destructive" });
    else toast({ title: "Admin account created" });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center gap-3 mb-8 animate-fade-in">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-primary shadow-glow animate-pulse-glow">
            <Zap className="h-7 w-7 text-primary-foreground" />
          </div>
          <div className="text-center">
            <h1 className="font-display text-3xl font-bold neon-text">Trackier Console</h1>
            <p className="text-sm text-muted-foreground mt-1">Internal access only</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="glow-card p-8 space-y-5 animate-fade-in">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" autoComplete="email" required value={email}
              onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" autoComplete="current-password" required value={password}
              onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
          </div>

          <Button type="submit" disabled={submitting || checking}
            className="w-full bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow font-semibold">
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Sign in"}
          </Button>

          {needsBootstrap && (
            <div className="rounded-lg border border-primary/40 bg-primary/5 p-4 space-y-3">
              <div className="flex items-start gap-2">
                <Shield className="h-4 w-4 text-primary mt-0.5" />
                <div>
                  <p className="text-sm font-semibold">No admin yet</p>
                  <p className="text-xs text-muted-foreground">
                    Create the first admin with the email & password above.
                  </p>
                </div>
              </div>
              <Button type="button" onClick={handleBootstrap} disabled={submitting}
                variant="outline" className="w-full border-primary/40 hover:bg-primary/10">
                Bootstrap admin account
              </Button>
            </div>
          )}

          <p className="text-xs text-center text-muted-foreground">
            New users must be invited by an admin.
          </p>
        </form>
      </div>
    </div>
  );
};

export default Login;
