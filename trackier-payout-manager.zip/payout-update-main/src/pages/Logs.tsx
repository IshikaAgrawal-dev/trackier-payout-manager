import { useEffect, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Loader2, RefreshCw, ScrollText } from "lucide-react";
import { format } from "date-fns";

interface AuditLog {
  id: string;
  user_email: string | null;
  action: string;
  campaign_id: string | null;
  goal_id: string | null;
  publisher_id: string | null;
  payload: any;
  created_at: string;
}

const actionColor: Record<string, string> = {
  UPLOAD_PAYOUT: "bg-success/20 text-success border-success/40",
  FETCH_CAMPAIGNS: "bg-primary/15 text-primary border-primary/30",
  FETCH_PUBLISHERS: "bg-primary/15 text-primary border-primary/30",
  FETCH_GOALS: "bg-accent/15 text-accent border-accent/30",
  INVITE_USER: "bg-warning/20 text-warning border-warning/40",
};

const Logs = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [q, setQ] = useState("");

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("audit_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(500);
    setLoading(false);
    if (!error) setLogs(data as AuditLog[]);
  };
  useEffect(() => { void load(); }, []);

  const filtered = logs.filter((l) =>
    `${l.user_email} ${l.action} ${l.campaign_id} ${l.publisher_id}`
      .toLowerCase().includes(q.toLowerCase())
  );

  return (
    <AppShell>
      <h1 className="sr-only">Audit Logs</h1>
      <div className="panel p-6 md:p-8">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <ScrollText className="h-5 w-5 text-muted-foreground" />
              <h2 className="text-[22px] font-semibold tracking-tight">Audit Logs</h2>
              <Badge variant="outline">{filtered.length}</Badge>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">Every payout and publisher action, newest first.</p>
          </div>
          <div className="flex gap-2">
            <Input placeholder="Search user, action, campaign…" value={q} onChange={(e) => setQ(e.target.value)} className="focus-ring h-10 w-64 rounded-lg" />
            <Button variant="outline" size="icon" className="focus-ring h-10 w-10 rounded-lg" onClick={load} disabled={loading} aria-label="Refresh logs">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        <div className="max-h-[640px] overflow-auto rounded-xl border hairline">
          <Table>
            <TableHeader className="sticky top-0 z-10 bg-surface-2/95 backdrop-blur">
              <TableRow className="hover:bg-transparent">
                <TableHead>Time</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Campaign</TableHead>
                <TableHead>Goal</TableHead>
                <TableHead>Publisher</TableHead>
                <TableHead>Payload</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((l, i) => (
                <TableRow key={l.id} className={i % 2 === 1 ? "row-stripe" : ""}>
                  <TableCell className="text-xs font-mono whitespace-nowrap">
                    {format(new Date(l.created_at), "yyyy-MM-dd HH:mm:ss")}
                  </TableCell>
                  <TableCell className="text-xs">{l.user_email || "—"}</TableCell>
                  <TableCell>
                    <span className={`rounded-full border px-2.5 py-1 text-[11px] font-medium ${actionColor[l.action] || "hairline bg-secondary text-muted-foreground"}`}>
                      {l.action}
                    </span>
                  </TableCell>
                  <TableCell className="font-mono text-xs">{l.campaign_id || "—"}</TableCell>
                  <TableCell className="font-mono text-xs">{l.goal_id || "—"}</TableCell>
                  <TableCell className="font-mono text-xs">{l.publisher_id || "—"}</TableCell>
                  <TableCell className="text-xs text-muted-foreground max-w-xs truncate font-mono">
                    {l.payload ? JSON.stringify(l.payload) : "—"}
                  </TableCell>
                </TableRow>
              ))}
              {!filtered.length && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground text-sm py-8">
                    No logs yet.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </AppShell>
  );
};

export default Logs;
