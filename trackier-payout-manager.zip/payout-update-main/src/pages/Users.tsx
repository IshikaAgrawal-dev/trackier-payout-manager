import { useEffect, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Loader2, UserPlus, Users as UsersIcon } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { z } from "zod";

const inviteSchema = z.object({
  email: z.string().trim().email().max(255),
  password: z.string().min(8).max(72),
  displayName: z.string().trim().max(100).optional(),
  role: z.enum(["admin", "user"]),
});

type ProfileRow = { user_id: string; email: string; display_name: string | null; created_at: string };
type RoleRow = { user_id: string; role: "admin" | "user" };

const Users = () => {
  const [profiles, setProfiles] = useState<ProfileRow[]>([]);
  const [roles, setRoles] = useState<RoleRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [role, setRole] = useState<"admin" | "user">("user");

  const load = async () => {
    setLoading(true);
    const [{ data: ps }, { data: rs }] = await Promise.all([
      supabase.from("profiles").select("user_id, email, display_name, created_at").order("created_at"),
      supabase.from("user_roles").select("user_id, role"),
    ]);
    setProfiles((ps as ProfileRow[]) || []);
    setRoles((rs as RoleRow[]) || []);
    setLoading(false);
  };
  useEffect(() => { void load(); }, []);

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = inviteSchema.safeParse({ email, password, displayName, role });
    if (!parsed.success) {
      toast({ title: "Invalid input", description: parsed.error.errors[0].message, variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke("admin-invite-user", { body: parsed.data });
      let message: string | null = (data as any)?.error ?? null;
      if (error) {
        message = error.message;
        try {
          const ctx = (error as any).context;
          if (ctx && typeof ctx.json === "function") {
            const body = await ctx.json();
            if (body?.error) message = body.error;
          }
        } catch { /* ignore parse failure */ }
      }
      if (message) {
        toast({ title: "Could not create user", description: message, variant: "destructive" });
        return;
      }
    } catch (err) {
      toast({ title: "Could not create user", description: String(err), variant: "destructive" });
      return;
    } finally {
      setSubmitting(false);
    }
    toast({ title: "User invited", description: email });
    setEmail(""); setPassword(""); setDisplayName(""); setRole("user");
    void load();
  };

  const userRoles = (uid: string) => roles.filter((r) => r.user_id === uid).map((r) => r.role);

  return (
    <AppShell>
      <h1 className="sr-only">User Management</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <section className="panel p-6 lg:col-span-1">
          <div className="mb-5 flex items-center gap-2">
            <UserPlus className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-[22px] font-semibold tracking-tight">Invite User</h2>
          </div>
          <form onSubmit={handleInvite} className="space-y-3">
            <div className="space-y-1">
              <Label>Email</Label>
              <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Temporary password</Label>
              <div className="flex gap-2">
                <Input type="text" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Min 8 chars, avoid common words" className="font-mono" />
                <Button type="button" variant="outline" size="sm" className="focus-ring h-10 shrink-0 rounded-lg"
                  onClick={() => {
                    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*";
                    const buf = new Uint32Array(16);
                    crypto.getRandomValues(buf);
                    setPassword(Array.from(buf, (n) => chars[n % chars.length]).join(""));
                  }}>
                  Generate
                </Button>
              </div>
            </div>
            <div className="space-y-1">
              <Label>Display name (optional)</Label>
              <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Role</Label>
              <Select value={role} onValueChange={(v) => setRole(v as "admin" | "user")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">User</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button type="submit" disabled={submitting}
              className="focus-ring w-full rounded-lg bg-primary font-medium text-primary-foreground shadow-glow hover:bg-primary/90">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Create account"}
            </Button>
          </form>
        </section>

        <section className="panel p-6 lg:col-span-2">
          <div className="mb-5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <UsersIcon className="h-5 w-5 text-muted-foreground" />
              <h2 className="text-[22px] font-semibold tracking-tight">Users</h2>
              <Badge variant="outline">{profiles.length}</Badge>
            </div>
            <Button variant="outline" size="sm" className="focus-ring rounded-lg" onClick={load} disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Refresh"}
            </Button>
          </div>
          <div className="overflow-x-auto rounded-xl border hairline">
            <Table>
              <TableHeader className="bg-surface-2/95">
                <TableRow><TableHead>Email</TableHead><TableHead>Name</TableHead><TableHead>Roles</TableHead><TableHead>Created</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {profiles.map((p, i) => (
                  <TableRow key={p.user_id} className={i % 2 === 1 ? "row-stripe" : ""}>
                    <TableCell className="text-sm">
                      <div className="flex items-center gap-2.5">
                        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border hairline bg-secondary text-[11px] font-semibold">
                          {(p.display_name || p.email).slice(0, 2).toUpperCase()}
                        </span>
                        {p.email}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{p.display_name || "—"}</TableCell>
                    <TableCell className="space-x-1">
                      {userRoles(p.user_id).map((r) => (
                        <Badge key={r} variant="outline" className={r === "admin" ? "border-primary/30 bg-primary/15 text-primary" : "hairline bg-secondary text-muted-foreground"}>
                          {r}
                        </Badge>
                      ))}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground font-mono">
                      {new Date(p.created_at).toLocaleDateString()}
                    </TableCell>
                  </TableRow>
                ))}
                {!profiles.length && (
                  <TableRow><TableCell colSpan={4} className="text-center text-sm text-muted-foreground py-8">No users yet.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </section>
      </div>
    </AppShell>
  );
};

export default Users;
