import { createClient, SupabaseClient } from 'https://esm.sh/@supabase/supabase-js@2.95.0';

export function userClient(authHeader: string): SupabaseClient {
  return createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_ANON_KEY')!,
    { global: { headers: { Authorization: authHeader } } }
  );
}

export function adminClient(): SupabaseClient {
  return createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    { auth: { persistSession: false } }
  );
}

export async function requireUser(req: Request) {
  const authHeader = req.headers.get('Authorization');
  if (!authHeader?.startsWith('Bearer ')) {
    return { error: new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 }) };
  }
  const supa = userClient(authHeader);
  const token = authHeader.replace('Bearer ', '');
  const { data, error } = await supa.auth.getClaims(token);
  if (error || !data?.claims) {
    console.error('requireUser getClaims failed:', error);
    return { error: new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 }) };
  }
  const claims = data.claims as { sub: string; email?: string };
  return { userId: claims.sub, email: claims.email ?? '', supa };
}

export async function isAdmin(userId: string): Promise<boolean> {
  const admin = adminClient();
  const { data } = await admin
    .from('user_roles')
    .select('role')
    .eq('user_id', userId)
    .eq('role', 'admin')
    .maybeSingle();
  return !!data;
}

export async function writeAuditLog(params: {
  userId: string;
  userEmail: string;
  action: string;
  campaignId?: string | null;
  goalId?: string | null;
  publisherId?: string | null;
  payload?: unknown;
}) {
  const admin = adminClient();
  await admin.from('audit_logs').insert({
    user_id: params.userId,
    user_email: params.userEmail,
    action: params.action,
    campaign_id: params.campaignId ?? null,
    goal_id: params.goalId ?? null,
    publisher_id: params.publisherId ?? null,
    payload: params.payload ?? null,
  });
}
