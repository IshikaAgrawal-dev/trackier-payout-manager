const RAW_BASE = (Deno.env.get('TRACKIER_BASE_URL') || 'https://api.trackier.com/v2').replace(/\/$/, '');
const KEY = Deno.env.get('TRACKIER_API_KEY') || '';

export function getTrackierBaseUrl() {
  if (!RAW_BASE) return 'https://api.trackier.com/v2';
  const withoutTrailingSlash = RAW_BASE.replace(/\/$/, '');
  if (withoutTrailingSlash === 'https://api.trackier.com') return `${withoutTrailingSlash}/v2`;
  return withoutTrailingSlash;
}

export function buildTrackierUrl(path: string) {
  const base = getTrackierBaseUrl();
  const joined = `${base}${path.startsWith('/') ? '' : '/'}${path}`;
  return KEY
    ? `${joined}${joined.includes('?') ? '&' : '?'}apiKey=${encodeURIComponent(KEY)}`
    : joined;
}

function redactApiKey(url: string) {
  return url.replace(/([?&]apiKey=)[^&]+/i, '$1[redacted]');
}

export async function trackierFetch(path: string, init: RequestInit = {}) {
  const url = buildTrackierUrl(path);
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(init.headers as Record<string, string> | undefined),
  };
  delete headers.Authorization;
  delete headers.authorization;
  delete headers['x-api-key'];
  const res = await fetch(url, { ...init, headers });
  const text = await res.text();
  let body: unknown = text;
  try { body = JSON.parse(text); } catch { /* keep text */ }
  const safeUrl = redactApiKey(url);
  if (!res.ok) {
    console.error(`trackierFetch ${init.method || 'GET'} ${safeUrl} -> ${res.status}: ${text.slice(0, 500)}`);
  } else {
    console.log(`trackierFetch ${init.method || 'GET'} ${safeUrl} -> ${res.status}`);
  }
  return { ok: res.ok, status: res.status, body };
}

// Try to extract a list from a Trackier response of unknown shape
export function extractList(body: unknown): unknown[] {
  if (Array.isArray(body)) return body;
  if (body && typeof body === 'object') {
    const obj = body as Record<string, unknown>;
    for (const key of ['data', 'result', 'results', 'items', 'campaigns', 'publishers', 'goals', 'payouts']) {
      const v = obj[key];
      if (Array.isArray(v)) return v;
      if (v && typeof v === 'object') {
        const inner = v as Record<string, unknown>;
        for (const k2 of ['data', 'items', 'list']) {
          if (Array.isArray(inner[k2])) return inner[k2] as unknown[];
        }
      }
    }
  }
  return [];
}

export function extractLastId(body: unknown): string | number | null {
  if (body && typeof body === 'object') {
    const obj = body as Record<string, unknown>;
    if (obj.lastId != null && obj.lastId !== '') return obj.lastId as string | number;
  }
  return null;
}

export function extractTotalCount(body: unknown): number | null {
  if (body && typeof body === 'object') {
    const p = (body as Record<string, unknown>).pagination as Record<string, unknown> | undefined;
    if (p && typeof p === 'object' && p.totalCount != null) return Number(p.totalCount);
  }
  return null;
}

export async function fetchPaginatedPage(basePath: string, page = 1, limit = 1000, lastId?: string | number | null) {
  const safePage = Math.max(1, Math.floor(Number(page) || 1));
  const safeLimit = Math.min(1000, Math.max(1, Math.floor(Number(limit) || 1000)));
  const sep = basePath.includes('?') ? '&' : '?';
  const cursor = lastId != null && lastId !== '' ? `&lastId=${encodeURIComponent(String(lastId))}` : '';
  const path = `${basePath}${sep}page=${safePage}&limit=${safeLimit}${cursor}`;
  const maxAttempts = 3;
  let lastStatus = 0;
  let lastBody: unknown = null;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const { ok, status, body } = await trackierFetch(path);
      if (ok) {
        const list = extractList(body);
        return {
          list,
          page: safePage,
          limit: safeLimit,
          hasMore: list.length >= safeLimit,
          lastId: extractLastId(body),
          totalCount: extractTotalCount(body),
        };
      }
      lastStatus = status;
      lastBody = body;
      if (status !== 502 && status !== 503 && status !== 504 && status !== 429) break;
    } catch (e) {
      lastBody = String(e);
    }
    if (attempt < maxAttempts) {
      await new Promise((r) => setTimeout(r, 400 * attempt));
    }
  }
  const detail = typeof lastBody === 'string' ? lastBody : JSON.stringify(lastBody);
  throw new Error(`Trackier ${path} returned ${lastStatus || 'network error'}: ${String(detail).slice(0, 500)}`);
}

// Paginated fetch — sequential, fetches every page until an empty/short page is returned.
export async function fetchAllPaginated(basePath: string): Promise<unknown[]> {
  const pageSize = 1000;
  const maxPages = 200;
  const fetchPage = async (page: number) => {
    const sep = basePath.includes('?') ? '&' : '?';
    const path = `${basePath}${sep}page=${page}&limit=${pageSize}`;
    const maxAttempts = 3;
    let lastStatus = 0;
    let lastBody: unknown = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const { ok, status, body } = await trackierFetch(path);
        if (ok) return { ok, list: extractList(body) };
        lastStatus = status;
        lastBody = body;
        if (status !== 502 && status !== 503 && status !== 504 && status !== 429) break;
      } catch (e) {
        lastBody = String(e);
      }
      if (attempt < maxAttempts) {
        await new Promise((r) => setTimeout(r, 400 * attempt));
      }
    }
    // Don't fail the whole aggregation on a persistent transient upstream error;
    // log and return an empty page so remaining pages still surface.
    console.error(`fetchAllPaginated: giving up on ${path} after ${maxAttempts} attempts (last ${lastStatus})`);
    return { ok: false, list: [] as unknown[] };
  };

  // Larger batches let us finish within the 150s edge idle timeout even when
  // Trackier is slow. Individual page failures are tolerated (empty page).
  const batchSize = 10;
  const all: unknown[] = [];
  let nextPage = 1;
  let done = false;
  while (!done && nextPage <= maxPages) {
    const pages = Array.from({ length: batchSize }, (_, i) => nextPage + i)
      .filter((p) => p <= maxPages);
    const results = await Promise.all(pages.map(fetchPage));
    for (const { list } of results) {
      all.push(...list);
      if (list.length < pageSize) { done = true; }
    }
    nextPage += batchSize;
  }
  console.log(`fetchAllPaginated(${basePath}) -> ${all.length} items`);
  return all;
}
