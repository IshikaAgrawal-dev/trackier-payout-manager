// Admin-only: invite a new user (creates auth user with auto-confirm).
import { corsHeaders } from '../_shared/cors.ts';
import { requireUser, isAdmin, adminClient, writeAuditLog } from '../_shared/auth.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const auth = await requireUser(req);
  if ('error' in auth) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
  if (!(await isAdmin(auth.userId))) {
    return new Response(JSON.stringify({ error: 'Forbidden' }), {
      status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
  try {
    const { email, password, role, displayName } = await req.json();
    if (!email || !password || password.length < 8) {
      return new Response(JSON.stringify({ error: 'Invalid email or password (min 8 chars)' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    const admin = adminClient();
    const { data, error } = await admin.auth.admin.createUser({
      email, password, email_confirm: true,
      user_metadata: { display_name: displayName || email },
    });
    if (error || !data.user) {
      return new Response(JSON.stringify({ error: error?.message || 'Failed' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    // If admin role requested, add it (trigger already added 'user')
    if (role === 'admin') {
      await admin.from('user_roles').insert({ user_id: data.user.id, role: 'admin' });
    }
    await writeAuditLog({
      userId: auth.userId, userEmail: auth.email,
      action: 'INVITE_USER',
      payload: { invited_email: email, role: role || 'user' },
    });
    return new Response(JSON.stringify({ user: { id: data.user.id, email: data.user.email } }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
