// One-time bootstrap: creates the very first admin if no users exist yet.
// Public (no auth) by necessity, but only works while user_roles is empty.
import { corsHeaders } from '../_shared/cors.ts';
import { adminClient } from '../_shared/auth.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const admin = adminClient();
    const { count } = await admin
      .from('user_roles')
      .select('*', { count: 'exact', head: true });
    if ((count ?? 0) > 0) {
      return new Response(JSON.stringify({ error: 'Bootstrap already complete' }), {
        status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    const { email, password, displayName } = await req.json();
    if (!email || !password || password.length < 8) {
      return new Response(JSON.stringify({ error: 'Invalid email or password (min 8 chars)' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    const { data, error } = await admin.auth.admin.createUser({
      email, password, email_confirm: true,
      user_metadata: { display_name: displayName || email },
    });
    if (error || !data.user) {
      return new Response(JSON.stringify({ error: error?.message || 'Failed' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    // Trigger handle_new_user already set this user as admin (first user).
    return new Response(JSON.stringify({ user: { id: data.user.id, email: data.user.email } }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
