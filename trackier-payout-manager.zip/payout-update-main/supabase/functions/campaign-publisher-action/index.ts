import { corsHeaders } from '../_shared/cors.ts';
import { requireUser, writeAuditLog } from '../_shared/auth.ts';
import { buildTrackierUrl, trackierFetch } from '../_shared/trackier.ts';

const ACTION_MAP: Record<string, string> = {
  assign: 'ASSIGN_PUBLISHER',
  remove: 'REMOVE_PUBLISHER',
  block: 'BLOCK_PUBLISHER',
  unblock: 'UNBLOCK_PUBLISHER',
};

// Documented Trackier endpoint for publisher access control:
// POST /v2/campaigns/access  { campaign_ids: number[], publisher_ids: number[], type }
const ACCESS_PATH = '/campaigns/access';

function redact(url: string) {
  return url.replace(/([?&]apiKey=)[^&]+/i, '$1[redacted]');
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const auth = await requireUser(req);
  if ('error' in auth) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  try {
    const body = await req.json();
    const campaign_ids: number[] = Array.isArray(body?.campaign_ids)
      ? body.campaign_ids.map((v: unknown) => Number(String(v ?? '').trim())).filter((n: number) => Number.isInteger(n) && n > 0)
      : [];
    const publisher_ids: number[] = Array.isArray(body?.publisher_ids)
      ? body.publisher_ids.map((v: unknown) => Number(String(v ?? '').trim())).filter((n: number) => Number.isInteger(n) && n > 0)
      : [];
    const type = String(body?.type || '').toLowerCase();

    if (!campaign_ids.length) {
      return new Response(JSON.stringify({ error: 'At least one campaign required' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    if (!publisher_ids.length) {
      return new Response(JSON.stringify({ error: 'At least one publisher required' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    if (!ACTION_MAP[type]) {
      return new Response(JSON.stringify({ error: 'Invalid action type' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // One bulk call handles every combination: multiple campaigns,
    // multiple publishers, one campaign + many publishers, etc.
    const payload = { campaign_ids, publisher_ids, type };
    const endpoint = redact(buildTrackierUrl(ACCESS_PATH));

    console.log('[campaign-publisher-action] POST', endpoint);
    console.log('[campaign-publisher-action] body', JSON.stringify(payload));

    const res = await trackierFetch(ACCESS_PATH, {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    console.log('[campaign-publisher-action] status', res.status);
    console.log('[campaign-publisher-action] response', JSON.stringify(res.body).slice(0, 2000));

    const result = {
      campaignId: campaign_ids.join(','),
      endpoint,
      method: 'POST',
      payload,
      status: res.status,
      ok: res.ok,
      response: res.body,
    };

    await writeAuditLog({
      userId: auth.userId, userEmail: auth.email,
      action: ACTION_MAP[type],
      payload: { request: payload, results: [result] },
    });

    return new Response(JSON.stringify({
      ok: res.ok,
      type,
      sentPayload: payload,
      endpoint,
      method: 'POST',
      status: res.status,
      response: res.body,
      results: [result],
      requestsSucceeded: res.ok ? 1 : 0,
      requestsFailed: res.ok ? 0 : 1,
    }), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

  } catch (e) {
    console.error('[campaign-publisher-action] error', e);
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
