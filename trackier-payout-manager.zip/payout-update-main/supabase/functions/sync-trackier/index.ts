import { corsHeaders } from '../_shared/cors.ts';
import { adminClient, requireUser } from '../_shared/auth.ts';
import { fetchPaginatedPage } from '../_shared/trackier.ts';

// Sync Trackier campaigns/publishers into the local cache tables.
// Runs page-by-page and UPSERTs each page as it arrives so a partial run still
// commits useful data. Never duplicates: conflict target is trackier_id.

const PAGE_SIZE = 500;
const MAX_PAGES = 400;
// Edge functions are killed at ~150s, so each invocation syncs what it can and
// reports where it stopped; the caller resumes from that page.
const TIME_BUDGET_MS = 100_000;

function str(v: unknown): string | null {
  if (v == null || v === '') return null;
  return String(v);
}

// Active is decided ONLY by Trackier's actual `status` field (normalized).
// No inference from flags, presence, cache, or previous state.
function isActiveCampaign(c: Record<string, unknown>) {
  const raw = c.status ?? c.campaign_status ?? c.campaignStatus;
  return typeof raw === 'string' && raw.trim().toLowerCase() === 'active';
}

function campaignRow(c: Record<string, unknown>) {
  return {
    trackier_id: String(c.id ?? c._id ?? ''),
    title: str(c.title ?? c.name),
    status: str(c.status ?? c.state ?? c.campaign_status ?? c.campaignStatus),
    is_active: isActiveCampaign(c),
    hash_id: str(c.hashId),
    raw: {
      id: c.id,
      title: c.title,
      name: c.name,
      status: c.status,
      state: c.state,
      campaign_status: c.campaign_status,
      campaignStatus: c.campaignStatus,
      hashId: c.hashId,
    },
    synced_at: new Date().toISOString(),
  };
}

function publisherRow(p: Record<string, unknown>) {
  return {
    trackier_id: String(p.id ?? p._id ?? ''),
    name: str(p.company ?? p.name ?? p.email),
    hash_id: str(p.hashId),
    long_id: str(p.publisherLongId ?? p.longId),
    status: str(p.status),
    raw: {
      id: p.id,
      company: p.company,
      name: p.name,
      email: p.email,
      hashId: p.hashId,
      publisherLongId: p.publisherLongId,
      longId: p.longId,
      _id: p._id,
    },
    synced_at: new Date().toISOString(),
  };
}

type Entity = 'campaigns' | 'publishers';

async function syncEntity(entity: Entity, startPage = 1) {
  const admin = adminClient();
  const deadline = Date.now() + TIME_BUDGET_MS;
  // Guard against overlapping runs (StrictMode double-effect, impatient clicks, cron overlap).
  // A run can never outlive the edge function's ~150s limit, so anything older
  // than 3 minutes is a crashed run and must not block a new sync.
  const staleCutoff = new Date(Date.now() - 3 * 60 * 1000).toISOString();
  const { data: inFlight } = await admin
    .from('sync_runs')
    .select('id')
    .eq('entity', entity)
    .eq('status', 'running')
    .gte('started_at', staleCutoff)
    .limit(1);
  if (inFlight?.length) {
    return { entity, records: 0, error: null, skipped: true };
  }

  const { data: run } = await admin
    .from('sync_runs')
    .insert({ entity, status: 'running' })
    .select('id')
    .single();
  const runId = run?.id as string | undefined;

  const table = entity === 'campaigns' ? 'campaigns' : 'publishers';
  const path = entity === 'campaigns' ? '/campaigns' : '/publishers';
  let total = 0;
  let failure: string | null = null;
  let done = false;
  let nextPage = startPage;
  let cursor: string | number | null = null;
  const seen = new Set<string>();

  let received = 0;
  let filteredOut = 0;
  try {
    for (let page = startPage; page <= MAX_PAGES; page++) {
      nextPage = page;
      const result = await fetchPaginatedPage(path, page, PAGE_SIZE, cursor);
      let list = result.list as Record<string, unknown>[];
      received += list.length;
      // Active-only filter applied BEFORE caching: only campaigns whose
      // Trackier `status` field is "active" (case-insensitive) are stored.
      if (entity === 'campaigns') {
        const inactiveIds = list
          .filter((c) => !isActiveCampaign(c))
          .map((c) => String(c.id ?? c._id ?? ''))
          .filter(Boolean);
        list = list.filter(isActiveCampaign);
        filteredOut += inactiveIds.length;
        // Remove any previously cached copy of campaigns Trackier now reports as non-active.
        if (inactiveIds.length) {
          const { error: delErr } = await admin.from('campaigns').delete().in('trackier_id', inactiveIds);
          if (delErr) console.error(`sync-trackier remove inactive failed: ${delErr.message}`);
        }
      }
      const rows = list
        .map((item) => (entity === 'campaigns' ? campaignRow(item) : publisherRow(item)))
        .filter((r) => r.trackier_id && !seen.has(r.trackier_id));
      // de-dupe within the page so ON CONFLICT never sees the same key twice
      const byId = new Map<string, typeof rows[number]>();
      rows.forEach((r) => byId.set(r.trackier_id, r));
      const unique = Array.from(byId.values());
      if (unique.length) {
        const { error } = await admin.from(table).upsert(unique, { onConflict: 'trackier_id' });
        if (error) throw new Error(`upsert ${table}: ${error.message}`);
        unique.forEach((r) => seen.add(r.trackier_id));
        total += unique.length;
      }
      // Trackier ignores `page` and paginates with a `lastId` cursor.
      // A page can be fully filtered out (non-active), so an empty upsert
      // batch must NOT end the run — only hasMore/cursor do.
      const nextCursor = result.lastId ?? null;
      if (!result.hasMore || nextCursor == null || nextCursor === cursor) {
        done = true;
        break;
      }
      cursor = nextCursor;
      nextPage = page + 1;
      if (Date.now() > deadline) break;
    }
  } catch (e) {
    failure = String(e);
    console.error(`sync-trackier ${entity} failed:`, failure);
  }

  if (entity === 'campaigns') {
    console.log(
      `sync-trackier campaigns: total received=${received}, active retained=${total}, non-active filtered out=${filteredOut}`,
    );
    // On a complete run, purge cached campaigns that are no longer active so
    // the cache only ever holds active campaigns.
    if (done && !failure && startPage === 1) {
      // Full run: drop every cached campaign Trackier did not return as active.
      const { data: cached } = await admin.from('campaigns').select('trackier_id');
      const stale = (cached ?? []).map((r) => String(r.trackier_id)).filter((id) => !seen.has(id));
      for (let i = 0; i < stale.length; i += 200) {
        const { error: purgeError } = await admin.from('campaigns').delete().in('trackier_id', stale.slice(i, i + 200));
        if (purgeError) console.error(`sync-trackier campaigns purge failed: ${purgeError.message}`);
      }
      console.log(`sync-trackier campaigns: purged ${stale.length} stale cached rows`);
    }
  }

  if (runId) {
    await admin
      .from('sync_runs')
      .update({
        status: failure ? (total > 0 ? 'partial' : 'failed') : done ? 'success' : 'partial',
        records_upserted: total,
        error: failure ? failure.slice(0, 1000) : null,
        finished_at: new Date().toISOString(),
      })
      .eq('id', runId);
  }

  return { entity, records: total, error: failure, done: done && !failure, nextPage };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), {
      status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  const url = new URL(req.url);
  const cronSecret = Deno.env.get('SYNC_CRON_SECRET');
  const providedSecret = req.headers.get('x-sync-secret') ?? url.searchParams.get('secret');
  const isCron = !!cronSecret && providedSecret === cronSecret;

  if (!isCron) {
    const auth = await requireUser(req);
    if ('error' in auth) return json({ error: 'Unauthorized' }, 401);
  }

  let entity = (url.searchParams.get('entity') ?? '').toLowerCase();
  if (!entity && req.method === 'POST') {
    try {
      const body = await req.json();
      entity = String(body?.entity ?? '').toLowerCase();
    } catch { /* no body */ }
  }
  if (!entity) entity = 'all';

  const targets: Entity[] =
    entity === 'campaigns' ? ['campaigns'] : entity === 'publishers' ? ['publishers'] : ['campaigns', 'publishers'];

  const startPage = Math.max(1, Number(url.searchParams.get('startPage') ?? 1) || 1);
  const results = [];
  for (const t of targets) {
    results.push(await syncEntity(t, targets.length === 1 ? startPage : 1));
    if (Date.now() > 0 && results[results.length - 1].done === false) break;
  }

  const ok = results.every((r) => !r.error);
  return json({ ok, results }, ok ? 200 : 207);
});