import { corsHeaders } from '../_shared/cors.ts';
import { requireUser, writeAuditLog } from '../_shared/auth.ts';
import { fetchAllPaginated, fetchPaginatedPage } from '../_shared/trackier.ts';

function isActiveCampaign(campaign: Record<string, unknown>) {
  const raw = campaign.status ?? campaign.campaign_status ?? campaign.campaignStatus;
  return typeof raw === 'string' && raw.trim().toLowerCase() === 'active';
}

function campaignOption(campaign: Record<string, unknown>) {
  return {
    id: campaign.id,
    title: campaign.title,
    name: campaign.name,
    status: campaign.status,
    state: campaign.state,
    campaign_status: campaign.campaign_status,
    campaignStatus: campaign.campaignStatus,
    hashId: campaign.hashId,
  };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const auth = await requireUser(req);
  if ('error' in auth) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
  try {
    const url = new URL(req.url);
    const paged = url.searchParams.get('paged') === '1';
    const page = Number(url.searchParams.get('page') || '1');
    const limit = Number(url.searchParams.get('limit') || '1000');
    if (paged) {
      const result = await fetchPaginatedPage('/campaigns', page, limit);
      const rawCampaigns = result.list as Record<string, unknown>[];
      const campaigns = rawCampaigns.filter(isActiveCampaign).map(campaignOption);
      await writeAuditLog({
        userId: auth.userId, userEmail: auth.email,
        action: 'FETCH_CAMPAIGNS', payload: { count: campaigns.length, page: result.page, paged: true },
      });
      return new Response(JSON.stringify({ campaigns, page: result.page, limit: result.limit, hasMore: result.hasMore }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    const campaigns = (await fetchAllPaginated('/campaigns') as Record<string, unknown>[]).filter(isActiveCampaign).map(campaignOption);
    await writeAuditLog({
      userId: auth.userId, userEmail: auth.email,
      action: 'FETCH_CAMPAIGNS', payload: { count: campaigns.length },
    });
    return new Response(JSON.stringify({ campaigns }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
