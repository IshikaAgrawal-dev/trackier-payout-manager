import { corsHeaders } from '../_shared/cors.ts';
import { requireUser } from '../_shared/auth.ts';
import { trackierFetch, extractList, buildTrackierUrl, getTrackierBaseUrl } from '../_shared/trackier.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const auth = await requireUser(req);
  if ('error' in auth) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const url = new URL(req.url);
  const resource = url.searchParams.get('resource') ?? 'campaigns';
  const method = (url.searchParams.get('method') ?? 'GET').toUpperCase();
  let path: string;
  if (method === 'GET') {
    const page = url.searchParams.get('page') ?? '1';
    const limit = url.searchParams.get('limit') ?? '1000';
    path = `/${resource}?page=${page}&limit=${limit}`;
  } else {
    path = `/${resource}`;
  }
  let bodyText: string | undefined;
  if (method !== 'GET' && method !== 'HEAD') {
    try { bodyText = await req.text(); } catch { /* none */ }
  }

  const baseUrl = getTrackierBaseUrl();
  const hasKey = !!Deno.env.get('TRACKIER_API_KEY');
  const fullUrl = buildTrackierUrl(path).replace(/([?&]apiKey=)[^&]+/i, '$1[redacted]');

  try {
    const { ok, status, body } = await trackierFetch(path, {
      method,
      ...(bodyText ? { body: bodyText } : {}),
    });
    const list = ok ? extractList(body) : [];
    return new Response(JSON.stringify({
      requestedPath: path,
      method,
      sentBody: bodyText ? safeParse(bodyText) : null,
      fullUrl,
      baseUrl,
      hasApiKey: hasKey,
      upstreamStatus: status,
      upstreamOk: ok,
      extractedCount: list.length,
      upstreamBody: body,
    }, null, 2), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({
      requestedPath: path,
      method,
      fullUrl,
      baseUrl,
      hasApiKey: hasKey,
      error: String(e),
    }, null, 2), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

function safeParse(s: string): unknown {
  try { return JSON.parse(s); } catch { return s; }
}