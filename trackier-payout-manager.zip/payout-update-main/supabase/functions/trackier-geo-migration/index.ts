import { corsHeaders } from '../_shared/cors.ts';
import { requireUser, isAdmin, writeAuditLog } from '../_shared/auth.ts';
import { trackierFetch, extractList } from '../_shared/trackier.ts';

// Campaign geo migration — preview and apply. READ-ONLY on Trackier for preview;
// apply ONLY edits existing payouts (POST /campaigns/{id}/payouts/{payoutId}) and
// changes ONLY the geo field, preserving every other payout value. It never calls
// the create endpoint and never deletes payouts, so no duplicates can be created.

interface PayoutInfo {
  _id: string;
  geo: string[];
  isDefault: boolean;
  goalId: string | null;
  publisherCount: number;
  payout: number | null;
}

function asStringArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.flatMap(asStringArray);
  if (value == null || value === '') return [];
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return [];
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return asStringArray(parsed);
    } catch { /* keep plain string */ }
    return trimmed.split(',').map((part) => part.trim()).filter(Boolean);
  }
  return [String(value).trim()].filter(Boolean);
}

// Normalized exact geo set: uppercase, unique, sorted. Empty → ["ALL"].
function normGeo(v: unknown): string[] {
  const list = asStringArray(v).map((g) => g.trim().toUpperCase()).filter(Boolean);
  const uniq = Array.from(new Set(list)).sort();
  return uniq.length ? uniq : ['ALL'];
}

function normGoal(v: unknown): string | null {
  const s = String(v ?? '').trim();
  if (!s || s.toLowerCase() === 'default' || s === '0') return null;
  return s;
}

function payoutIdOf(p: Record<string, unknown>): string | null {
  const id = p._id ?? p.id;
  return id != null && String(id).trim() ? String(id).trim() : null;
}

function payoutListFromCampaign(body: unknown): Record<string, unknown>[] {
  if (!body || typeof body !== 'object') return [];
  const root = body as Record<string, unknown>;
  const candidates = [root, root.campaign, root.data, root.result]
    .filter((item): item is Record<string, unknown> => !!item && typeof item === 'object');
  for (const item of candidates) {
    if (Array.isArray(item.payouts)) return item.payouts as Record<string, unknown>[];
  }
  return [];
}

function mapPayout(p: Record<string, unknown>): PayoutInfo {
  const pubIds = [
    ...asStringArray(p.pubIds),
    ...asStringArray(p.publisherIds),
    ...asStringArray(p.publisherId),
  ];
  return {
    _id: payoutIdOf(p) ?? '',
    geo: normGeo(p.geo),
    isDefault: pubIds.length === 0,
    goalId: normGoal(p.goalId ?? p.goal_id),
    publisherCount: pubIds.length,
    payout: p.payout == null ? null : Number(p.payout),
  };
}

async function mapPool<T, R>(items: T[], pool: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(pool, items.length) }, async () => {
    while (next < items.length) {
      const idx = next++;
      results[idx] = await fn(items[idx]);
    }
  });
  await Promise.all(workers);
  return results;
}

async function loadCampaignPayouts(campaignId: string): Promise<{ payouts: PayoutInfo[]; error?: string }> {
  const resp = await trackierFetch(`/campaigns/${campaignId}/payouts`);
  let list: Record<string, unknown>[] = [];
  if (resp.ok) list = extractList(resp.body) as Record<string, unknown>[];
  if (list.length === 0) {
    const campaignResp = await trackierFetch(`/campaigns/${campaignId}`);
    if (campaignResp.ok) list = payoutListFromCampaign(campaignResp.body);
  }
  if (list.length === 0 && !resp.ok) {
    return { payouts: [], error: `Trackier ${resp.status} while loading payouts` };
  }
  return { payouts: list.map(mapPayout).filter((p) => p._id) };
}

// Change ONLY the geo field; preserve every other existing payout configuration.
function buildEditPayload(existing: Record<string, unknown>, targetGeo: 'IN' | 'ALL') {
  const payload: Record<string, unknown> = {
    payout: existing.payout,
    revenue: existing.revenue,
    geo: [targetGeo],
  };
  if (typeof existing.currency === 'string' && existing.currency.trim()) {
    payload.currency = existing.currency;
  }
  const pubIds = [
    ...asStringArray(existing.pubIds),
    ...asStringArray(existing.publisherIds),
    ...asStringArray(existing.publisherId),
  ];
  if (pubIds.length) payload.pubIds = pubIds;
  const goalId = existing.goalId ?? existing.goal_id;
  if (goalId != null && String(goalId).trim() && String(goalId) !== 'default') {
    payload.goalId = String(goalId);
  }
  for (const key of ['landingPages', 'region', 'city'] as const) {
    const values = asStringArray(existing[key]);
    if (values.length) payload[key] = values;
  }
  return payload;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const auth = await requireUser(req);
  if ('error' in auth) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
  if (!(await isAdmin(auth.userId))) {
    return new Response(JSON.stringify({ error: 'Admin access required' }), {
      status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), {
      status, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  try {
    const body = await req.json();
    const action = String(body?.action ?? '');

    if (action === 'preview') {
      const ids: string[] = Array.isArray(body?.campaignIds) ? body.campaignIds.map(String) : [];
      if (!ids.length || ids.length > 40) {
        return json({ error: 'campaignIds must contain between 1 and 40 campaign IDs' }, 400);
      }
      const results = await mapPool(ids, 6, async (campaignId) => {
        const { payouts, error } = await loadCampaignPayouts(campaignId);
        return { campaignId, payouts, error: error ?? null };
      });
      return json({ results });
    }

    if (action === 'apply') {
      const rows: { campaignId: string; payoutId: string; targetGeo: 'IN' | 'ALL' }[] =
        Array.isArray(body?.rows) ? body.rows : [];
      if (!rows.length || rows.length > 200) {
        return json({ error: 'rows must contain between 1 and 200 payout rows' }, 400);
      }
      for (const r of rows) {
        if (!r?.campaignId || !r?.payoutId || (r?.targetGeo !== 'IN' && r?.targetGeo !== 'ALL')) {
          return json({ error: 'Each row needs campaignId, payoutId and targetGeo of IN or ALL' }, 400);
        }
      }

      // Group rows per campaign so each campaign's payouts are fetched only once.
      const byCampaign = new Map<string, Map<string, Record<string, unknown>>>();
      const success: unknown[] = [];
      const skipped: unknown[] = [];
      const failed: unknown[] = [];

      const uniqueCampaignIds = Array.from(new Set(rows.map((r) => r.campaignId)));
      const loaded = await mapPool(uniqueCampaignIds, 6, async (campaignId) => {
        // Fetch the RAW payout records so every field can be preserved on edit.
        const byId = new Map<string, Record<string, unknown>>();
        const resp = await trackierFetch(`/campaigns/${campaignId}/payouts`);
        let rawList: Record<string, unknown>[] = [];
        if (resp.ok) rawList = extractList(resp.body) as Record<string, unknown>[];
        if (rawList.length === 0) {
          const campaignResp = await trackierFetch(`/campaigns/${campaignId}`);
          if (campaignResp.ok) rawList = payoutListFromCampaign(campaignResp.body);
        }
        for (const p of rawList) {
          const id = payoutIdOf(p);
          if (id) byId.set(id, p);
        }
        return { campaignId, byId, error: byId.size === 0 && !resp.ok ? `Trackier ${resp.status} while loading payouts` : null };
      });
      for (const l of loaded) byCampaign.set(l.campaignId, l.byId);

      for (const r of rows) {
        const existing = byCampaign.get(r.campaignId)?.get(r.payoutId);
        if (!existing) {
          const err = loaded.find((l) => l.campaignId === r.campaignId)?.error;
          failed.push({ ...r, reason: err ?? 'Payout not found for this campaign' });
          continue;
        }
        const fromGeo = normGeo(existing.geo).join(',');
        // Already on the requested geo — never touch the payout again.
        if (fromGeo === r.targetGeo) {
          skipped.push({ ...r, reason: 'already-target' });
          continue;
        }
        const editPath = `/campaigns/${r.campaignId}/payouts/${encodeURIComponent(r.payoutId)}`;
        const payload = buildEditPayload(existing, r.targetGeo);
        console.log('[trackier-geo-migration] Editing payout:', {
          campaignId: r.campaignId, payoutId: r.payoutId, fromGeo, toGeo: r.targetGeo, payload,
        });
        const resp = await trackierFetch(editPath, { method: 'POST', body: JSON.stringify(payload) });
        if (!resp.ok) {
          failed.push({ ...r, reason: `Trackier ${resp.status}`, body: resp.body });
          continue;
        }
        await writeAuditLog({
          userId: auth.userId, userEmail: auth.email,
          action: 'GEO_MIGRATION',
          campaignId: r.campaignId,
          payload: { payoutId: r.payoutId, fromGeo, toGeo: r.targetGeo, payout: existing.payout },
        });
        success.push({ campaignId: r.campaignId, payoutId: r.payoutId, fromGeo, toGeo: r.targetGeo });
      }

      return json({ success, skipped, failed });
    }

    return json({ error: 'Unknown action' }, 400);
  } catch (e) {
    console.error('[trackier-geo-migration] error:', e);
    return json({ error: String(e) }, 500);
  }
});
