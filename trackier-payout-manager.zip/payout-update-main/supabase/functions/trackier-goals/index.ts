import { corsHeaders } from '../_shared/cors.ts';
import { requireUser, writeAuditLog, adminClient } from '../_shared/auth.ts';
import { trackierFetch, extractList } from '../_shared/trackier.ts';

function pickNum(obj: Record<string, unknown>, keys: string[]): number | null {
  for (const k of keys) {
    const v = obj[k];
    if (v != null && v !== '') {
      const n = Number(v);
      if (!Number.isNaN(n)) return n;
    }
  }
  return null;
}

function asStringArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.flatMap(asStringArray);
  if (value == null || value === '') return [];
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return [];
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return asStringArray(parsed);
    } catch { /* keep plain string */ }
    return trimmed.split(',').map((part) => part.trim()).filter(Boolean);
  }
  return [String(value).trim()].filter(Boolean);
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const auth = await requireUser(req);
  if ('error' in auth) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
  try {
    const url = new URL(req.url);
    const campaignId = url.searchParams.get('campaignId');
    if (!campaignId) {
      return new Response(JSON.stringify({ error: 'campaignId required' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Fetch campaign details (for default revenue/payout fallback)
    const campResp = await trackierFetch(`/campaigns/${campaignId}`);
    let defaultRevenue: number | null = null;
    let defaultPayout: number | null = null;
    if (campResp.ok && campResp.body && typeof campResp.body === 'object') {
      const c = campResp.body as Record<string, unknown>;
      const data = ((c.data as Record<string, unknown>) || c);
      defaultRevenue = pickNum(data, ['default_revenue', 'defaultRevenue', 'revenue']);
      defaultPayout = pickNum(data, ['default_payout', 'defaultPayout', 'payout']);
    }

    // Try goals
    const goalsResp = await trackierFetch(`/campaigns/${campaignId}/goals`);
    const rawGoals = goalsResp.ok ? extractList(goalsResp.body) : [];

    // Fallback: if no goals, fetch campaign-level payouts to derive revenue/payout
    if (rawGoals.length === 0) {
      const payoutsResp = await trackierFetch(`/campaigns/${campaignId}/payouts`);
      if (payoutsResp.ok) {
        const list = extractList(payoutsResp.body) as Record<string, unknown>[];
        const p = list.length > 0 ? list[0] : null;
        if (p) {
          const r = pickNum(p, ['revenue']);
          const pay = pickNum(p, ['payout']);
          if (r != null) defaultRevenue = r;
          if (pay != null) defaultPayout = pay;
          // If revenue missing, fall back to payout per spec
          if (defaultRevenue == null && defaultPayout != null) defaultRevenue = defaultPayout;
        }
      }
      // Last resort: use payout as base if revenue still missing
      if ((defaultRevenue == null || defaultRevenue === 0) && defaultPayout != null) {
        defaultRevenue = defaultPayout;
      }
      console.log('[trackier-goals] No goals, using campaign payouts fallback:', { defaultRevenue, defaultPayout });
    }

    // Normalize goals — extract revenue/payout from goal.payouts[0] per Trackier API
    const goals = (rawGoals as Record<string, unknown>[]).map((g) => {
      const payoutsArr = Array.isArray(g.payouts) ? (g.payouts as Record<string, unknown>[]) : [];
      const payoutInfo = payoutsArr.length > 0 ? payoutsArr[0] : null;

      const revenue = payoutInfo
        ? (pickNum(payoutInfo, ['revenue']) ?? 0)
        : (pickNum(g, ['revenue', 'default_revenue', 'defaultRevenue']) ?? 0);
      const payout = payoutInfo
        ? (pickNum(payoutInfo, ['payout']) ?? 0)
        : (pickNum(g, ['payout', 'default_payout', 'defaultPayout']) ?? 0);

      return {
        id: String(g.id ?? g._id ?? ''),
        title: g.title ?? g.name ?? null,
        name: g.name ?? null,
        revenue,
        payout,
      };
    });

    let resolvedGoals = goals;

    // Reliability: if Trackier's goals call failed, fall back to the cached goals
    // so the console keeps working while Trackier is slow or down.
    if (!goalsResp.ok) {
      try {
        const { data: cached } = await adminClient()
          .from('campaign_goals')
          .select('goal_trackier_id, title, payout, revenue')
          .eq('campaign_trackier_id', String(campaignId));
        if (cached?.length) {
          resolvedGoals = cached.map((g: Record<string, unknown>) => ({
            id: String(g.goal_trackier_id),
            title: (g.title as string) ?? null,
            name: (g.title as string) ?? null,
            revenue: Number(g.revenue ?? 0),
            payout: Number(g.payout ?? 0),
          }));
          console.log(`[trackier-goals] served ${resolvedGoals.length} goal(s) from cache for ${campaignId}`);
        }
      } catch (e) {
        console.error('[trackier-goals] cache fallback failed:', String(e));
      }
    } else if (goals.length) {
      // Write-through cache so the fallback above has fresh data.
      try {
        await adminClient().from('campaign_goals').upsert(
          goals.map((g) => ({
            campaign_trackier_id: String(campaignId),
            goal_trackier_id: String(g.id),
            title: (g.title as string) ?? null,
            payout: g.payout,
            revenue: g.revenue,
            raw: g,
            synced_at: new Date().toISOString(),
          })),
          { onConflict: 'campaign_trackier_id,goal_trackier_id' },
        );
      } catch (e) {
        console.error('[trackier-goals] goal cache write failed:', String(e));
      }
    }

    const isDefault = resolvedGoals.length === 0;

    // Always fetch existing campaign-level payouts so the UI can match (pubIds + goalId + geo).
    // Source of truth = GET /campaigns/{id}/payouts (full page).
    const existingResp = await trackierFetch(`/campaigns/${campaignId}/payouts?page=1&limit=1000`);
    let existingRaw = existingResp.ok ? extractList(existingResp.body) as Record<string, unknown>[] : [];
    if (existingRaw.length === 0 && campResp.ok && campResp.body && typeof campResp.body === 'object') {
      // Fallback: some campaigns expose payouts only on the campaign object.
      const root = campResp.body as Record<string, unknown>;
      for (const item of [root, root.campaign, root.data, root.result]) {
        if (item && typeof item === 'object' && Array.isArray((item as Record<string, unknown>).payouts)) {
          existingRaw = (item as Record<string, unknown>).payouts as Record<string, unknown>[];
          break;
        }
      }
    }
    const normalizeGoal = (v: unknown): string | null => {
      if (v == null) return null;
      const s = String(v).trim();
      if (!s || s.toLowerCase() === 'default' || s === '0') return null;
      return s;
    };
    const existingPayouts = existingRaw.map((p) => ({
      id: String(p._id ?? p.id ?? ''),
      pubIds: [
        ...asStringArray(p.pubIds),
        ...asStringArray(p.publisherIds),
        ...asStringArray(p.publisherId),
      ],
      goalId: normalizeGoal(p.goalId ?? p.goal_id),
      geo: asStringArray(p.geo).map((g) => String(g).toUpperCase()),
      payout: pickNum(p, ['payout']) ?? 0,
      revenue: pickNum(p, ['revenue']) ?? 0,
      currency: typeof p.currency === 'string' ? p.currency : null,
    }));
    console.log('[trackier-goals] existing payouts for', campaignId, existingPayouts.map((p) => ({
      id: p.id, pubIds: p.pubIds, goalId: p.goalId, geo: p.geo, payout: p.payout,
    })));

    await writeAuditLog({
      userId: auth.userId, userEmail: auth.email,
      action: 'FETCH_GOALS', campaignId,
      payload: { count: resolvedGoals.length, isDefault, defaultRevenue, defaultPayout, existingPayouts: existingPayouts.length },
    });

    return new Response(JSON.stringify({
      goals: resolvedGoals,
      isDefault,
      defaultRevenue: defaultRevenue ?? 0,
      defaultPayout: defaultPayout ?? 0,
      existingPayouts,
      // Backward compat
      basePayout: defaultRevenue ?? defaultPayout ?? 0,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
