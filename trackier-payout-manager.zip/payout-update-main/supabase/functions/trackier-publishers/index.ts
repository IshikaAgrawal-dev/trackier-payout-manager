import { corsHeaders } from '../_shared/cors.ts';
import { requireUser, writeAuditLog } from '../_shared/auth.ts';
import { fetchAllPaginated, fetchPaginatedPage } from '../_shared/trackier.ts';

function publisherOption(publisher: Record<string, unknown>) {
  return {
    id: publisher.id,
    company: publisher.company,
    name: publisher.name,
    email: publisher.email,
    hashId: publisher.hashId,
    publisherLongId: publisher.publisherLongId,
    longId: publisher.longId,
    _id: publisher._id,
  };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const auth = await requireUser(req);
  if ('error' in auth) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
  try {
    const url = new URL(req.url);
    const paged = url.searchParams.get('paged') === '1';
    const page = Number(url.searchParams.get('page') || '1');
    const limit = Number(url.searchParams.get('limit') || '1000');
    if (paged) {
      const result = await fetchPaginatedPage('/publishers', page, limit);
      const publishers = (result.list as Record<string, unknown>[]).map(publisherOption);
      await writeAuditLog({
        userId: auth.userId, userEmail: auth.email,
        action: 'FETCH_PUBLISHERS', payload: { count: publishers.length, page: result.page, paged: true },
      });
      return new Response(JSON.stringify({ publishers, page: result.page, limit: result.limit, hasMore: result.hasMore }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    const publishers = (await fetchAllPaginated('/publishers') as Record<string, unknown>[]).map(publisherOption);
    await writeAuditLog({
      userId: auth.userId, userEmail: auth.email,
      action: 'FETCH_PUBLISHERS', payload: { count: publishers.length },
    });
    return new Response(JSON.stringify({ publishers }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
