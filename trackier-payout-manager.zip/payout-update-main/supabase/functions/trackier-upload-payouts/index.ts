import { corsHeaders } from '../_shared/cors.ts';
import { requireUser, adminClient, writeAuditLog } from '../_shared/auth.ts';
import { trackierFetch, extractList } from '../_shared/trackier.ts';

interface PayoutRow {
  campaignId: string;
  goalId?: string | null;
  publisherId?: string | null;
  publisherMatchIds?: string[];
  applyAll?: boolean;
  basePayout: number;
  adjustedPayout: number;
  percentage: number;
  existingPayoutId?: string | null;
  geo?: string[] | string | null;
}

// Normalized exact geo set: uppercase, unique, sorted. Empty → ["ALL"].
function normGeo(v: unknown): string[] {
  const list = asStringArray(v).map((g) => g.trim().toUpperCase()).filter(Boolean);
  const uniq = Array.from(new Set(list)).sort();
  return uniq.length ? uniq : ['ALL'];
}

function asStringArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.flatMap(asStringArray);
  if (value == null || value === '') return [];
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return [];
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return asStringArray(parsed);
    } catch { /* keep plain string */ }
    return trimmed.split(',').map((part) => part.trim()).filter(Boolean);
  }
  return [String(value).trim()].filter(Boolean);
}

function payoutListFromCampaign(body: unknown): Record<string, unknown>[] {
  if (!body || typeof body !== 'object') return [];
  const root = body as Record<string, unknown>;
  const candidates = [root, root.campaign, root.data, root.result]
    .filter((item): item is Record<string, unknown> => !!item && typeof item === 'object');
  for (const item of candidates) {
    if (Array.isArray(item.payouts)) return item.payouts as Record<string, unknown>[];
  }
  return [];
}

function normId(v: unknown): string {
  return String(v ?? '').trim().toLowerCase();
}

function normGoal(v: unknown): string | null {
  const s = String(v ?? '').trim();
  if (!s || s.toLowerCase() === 'default' || s === '0') return null;
  return s;
}

function payoutMatches(
  payout: Record<string, unknown>,
  publisherMatchIds: string[],
  _publisherMatchNums: Set<number>,
  goalKey: string | null,
  requestedGeo: string[],
): boolean {
  const pubIds = [
    ...asStringArray(payout.pubIds),
    ...asStringArray(payout.publisherIds),
    ...asStringArray(payout.publisherId),
  ].map(normId).filter(Boolean);
  // Publisher-Specific Payout match: publisher MUST be present in pubIds.
  // Default Payout (empty pubIds) must NEVER be edited here.
  if (pubIds.length === 0) return false;
  const wanted = new Set(publisherMatchIds.map(normId).filter(Boolean));
  const pubMatch = pubIds.some((id) => wanted.has(id));
  const pGoal = normGoal(payout.goalId ?? payout.goal_id);
  const goalMatch = goalKey ? pGoal === normGoal(goalKey) : pGoal === null;
  if (!pubMatch || !goalMatch) return false;
  // GEO must match exactly (normalized set). IN ≠ ALL.
  const have = normGeo(payout.geo).join(',');
  const want = normGeo(requestedGeo).join(',');
  if (have !== want) {
    console.log(`[trackier-upload-payouts] Geo mismatch: ${have} != ${want}`, { payoutId: payoutIdOf(payout) });
    return false;
  }
  return true;
}

function payoutIdOf(payout: Record<string, unknown>): string | null {
  const id = payout._id ?? payout.id;
  return id != null && String(id).trim() ? String(id).trim() : null;
}

function editPayloadFromExisting(
  existing: Record<string, unknown>,
  fallback: Record<string, unknown>,
): Record<string, unknown> {
  const edited: Record<string, unknown> = {
    payout: fallback.payout,
    revenue: fallback.revenue,
    // Requested geo already equals the matched payout's exact geo; never coerce to ALL.
    geo: fallback.geo,
    currency: typeof existing.currency === 'string' && existing.currency.trim() ? existing.currency : fallback.currency,
  };
  const existingPubIds = [
    ...asStringArray(existing.pubIds),
    ...asStringArray(existing.publisherIds),
    ...asStringArray(existing.publisherId),
  ];
  if (existingPubIds.length) edited.pubIds = existingPubIds;
  else if (!Object.prototype.hasOwnProperty.call(existing, 'pubIds') && fallback.pubIds) edited.pubIds = fallback.pubIds;
  const goalId = existing.goalId ?? existing.goal_id ?? fallback.goalId;
  if (goalId != null && String(goalId).trim() && String(goalId) !== 'default') edited.goalId = String(goalId);
  for (const key of ['landingPages', 'region', 'city'] as const) {
    const values = asStringArray(existing[key]);
    if (values.length) edited[key] = values;
  }
  return edited;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const auth = await requireUser(req);
  if ('error' in auth) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  try {
    const body = await req.json();
    const rows: PayoutRow[] = Array.isArray(body?.rows) ? body.rows : [];
    if (!rows.length) {
      return new Response(JSON.stringify({ error: 'No rows' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    const admin = adminClient();
    const success: unknown[] = [];
    const failed: unknown[] = [];
    // Cache campaign payouts per request to avoid re-fetching the same campaign
    // (which can hold thousands of payouts) for every row — this was the main
    // cause of the 150s idle timeout when uploading many rows.
    const campaignPayoutCache = new Map<string, Record<string, unknown>[]>();

    // Resolve every publisher's Trackier identifiers (hash_id / long_id) from the
    // local publishers cache. Trackier stores hash IDs inside payout.pubIds, so a
    // numeric UI id alone will never match an existing publisher-specific payout.
    const publisherIdentityMap = new Map<string, string[]>();
    const numericPublisherIds = Array.from(new Set(
      rows.map((r) => String(r.publisherId ?? '').trim()).filter(Boolean),
    ));
    if (numericPublisherIds.length) {
      const { data: pubRows, error: pubErr } = await admin
        .from('publishers')
        .select('trackier_id,hash_id,long_id,raw')
        .in('trackier_id', numericPublisherIds);
      if (pubErr) console.error('[trackier-upload-payouts] publisher lookup failed:', pubErr);
      for (const p of pubRows ?? []) {
        const raw = (p.raw ?? {}) as Record<string, unknown>;
        const ids = Array.from(new Set([
          p.trackier_id, p.hash_id, p.long_id,
          raw.hashId, raw.publisherLongId, raw.longId, raw._id, raw.id,
        ].map((v) => String(v ?? '').trim()).filter(Boolean)));
        publisherIdentityMap.set(String(p.trackier_id), ids);
      }
      console.log('[trackier-upload-payouts] Resolved publisher identities:',
        Object.fromEntries(publisherIdentityMap));
    }

    // Load live payouts for a campaign; falls back to the cached campaign_payouts
    // table if Trackier momentarily returns nothing.
    const loadCampaignPayouts = async (
      campaignId: string,
      force = false,
    ): Promise<Record<string, unknown>[] | { error: string; body?: unknown }> => {
      if (!force) {
        const hit = campaignPayoutCache.get(campaignId);
        if (hit) return hit;
      }
      const campaignResp = await trackierFetch(`/campaigns/${campaignId}`);
      let list: Record<string, unknown>[] = [];
      if (campaignResp.ok) {
        list = payoutListFromCampaign(campaignResp.body);
      }
      if (list.length === 0) {
        const listResp = await trackierFetch(`/campaigns/${campaignId}/payouts?page=1&limit=1000`);
        if (listResp.ok) list = extractList(listResp.body) as Record<string, unknown>[];
        else if (!campaignResp.ok) {
          const { data: cached } = await admin
            .from('campaign_payouts')
            .select('raw')
            .eq('campaign_trackier_id', campaignId);
          if (cached?.length) {
            list = cached
              .map((c) => (c.raw ?? {}) as Record<string, unknown>)
              .filter((c) => Object.keys(c).length > 0);
            console.log('[trackier-upload-payouts] Using cached campaign_payouts fallback:', {
              campaignId, count: list.length,
            });
          } else {
            return { error: `Trackier ${campaignResp.status} while loading campaign`, body: campaignResp.body };
          }
        }
      }
      campaignPayoutCache.set(campaignId, list);
      return list;
    };


    for (const r of rows) {
      if (!r.campaignId || r.adjustedPayout == null) {
        failed.push({ row: r, reason: 'Missing required fields' });
        continue;
      }
      if (!r.applyAll && !r.publisherId) {
        failed.push({ row: r, reason: 'Missing publisherId' });
        continue;
      }

      const isRealGoal = !!(r.goalId && r.goalId !== 'default');
      const requestedGeo = normGeo(r.geo);

      // Build Trackier payload — exact shape required for overwrite-match.
      // Trackier matches strict equality on pubIds (numeric) + goalId (string) + geo (["ALL"]).
      const payload: Record<string, unknown> = {
        payout: Number(r.adjustedPayout),
        revenue: 0,
        geo: requestedGeo,
        currency: "INR",
      };
      if (!r.applyAll && r.publisherId != null) {
        payload.pubIds = [Number(r.publisherId)];
      }
      if (isRealGoal) {
        payload.goalId = String(r.goalId);
      }

      const payoutPath = `/campaigns/${r.campaignId}/payouts`;

      // Trackier payout creation is append-only. Existing rows must be edited
      // through the documented endpoint: POST /campaigns/{id}/payouts/{payoutId}.
      if (!r.applyAll && r.publisherId != null) {
        const publisherMatchIds = Array.from(new Set([
          r.publisherId,
          ...(r.publisherMatchIds ?? []),
          ...(publisherIdentityMap.get(String(r.publisherId)) ?? []),
        ].map((id) => String(id ?? '').trim()).filter(Boolean)));
        const publisherMatchNums = new Set(publisherMatchIds.map(Number).filter((n) => !Number.isNaN(n)));
        const goalKey = isRealGoal ? String(r.goalId) : null;
        const existingId = r.existingPayoutId ? String(r.existingPayoutId) : '';
        const isSamePayout = (p: Record<string, unknown>) => {
          const pid = payoutIdOf(p) ?? '';
          const matches = payoutMatches(p, publisherMatchIds, publisherMatchNums, goalKey, requestedGeo);
          // Even the UI-provided id must agree on geo, so an ALL payout is never edited for an IN request.
          return matches || (!!existingId && pid === existingId && normGeo(p.geo).join(',') === requestedGeo.join(','));
        };

        const findMatch = async (force: boolean) => {
          const loaded = await loadCampaignPayouts(r.campaignId, force);
          if (!Array.isArray(loaded)) return loaded;
          const matching = loaded.filter(isSamePayout);
          console.log('[trackier-upload-payouts] Match scan:', {
            campaignId: r.campaignId, publisherId: r.publisherId, goalKey, requestedGeo,
            publisherMatchIds,
            existingIdFromUI: existingId || null,
            forcedRefresh: force,
            campaignPayoutCount: loaded.length,
            matchedCount: matching.length,
            matchedIds: matching.map(payoutIdOf),
          });
          return matching;
        };

        let matching = await findMatch(false);
        if (!Array.isArray(matching)) {
          failed.push({ row: r, reason: matching.error, body: matching.body });
          continue;
        }
        // Safety re-check immediately before creating: refetch live payouts so a
        // payout added since the preview (or by a concurrent row) is updated,
        // never duplicated.
        if (!matching.length) {
          const rechecked = await findMatch(true);
          if (!Array.isArray(rechecked)) {
            failed.push({ row: r, reason: rechecked.error, body: rechecked.body });
            continue;
          }
          matching = rechecked;
        }

        if (matching.length) {
          const matchedPayout = matching.find((p) => existingId && payoutIdOf(p) === existingId)
            ?? matching[0];
          const payoutId = payoutIdOf(matchedPayout);
          if (!payoutId) {
            console.error('[trackier-upload-payouts] Matched payout has no _id; refusing to fall back to create:', matchedPayout);
            failed.push({ row: r, reason: 'Existing payout matched but Trackier did not return a payout _id for editing', matched: matchedPayout });
            continue;
          }
          const existingAmount = Number(matchedPayout.payout);
          console.log('[trackier-upload-payouts] Row:', {
            campaign: r.campaignId, publisher: r.publisherId, goal: goalKey ?? 'default',
            requestedGeo, existingPayoutId: payoutId, existingGeo: normGeo(matchedPayout.geo),
            existingPayout: existingAmount, newPayout: Number(r.adjustedPayout),
          });
          if (Math.round(existingAmount * 10000) === Math.round(Number(r.adjustedPayout) * 10000)) {
            console.log('[trackier-upload-payouts] Status: DUPLICATE — skipped');
            success.push({ ...r, skipped: 'duplicate' });
            continue;
          }
          console.log('[trackier-upload-payouts] Matched existing payout:', matchedPayout);
          console.log('[trackier-upload-payouts] Matched payoutId:', payoutId);
          console.log('[trackier-upload-payouts] Status: will_update');
          const editPath = `${payoutPath}/${encodeURIComponent(payoutId)}`;
          const editPayload = editPayloadFromExisting(matchedPayout, payload);
          console.log('[trackier-upload-payouts] Upload endpoint:', editPath);
          console.log('[trackier-upload-payouts] Payload:', editPayload);
          const resp = await trackierFetch(editPath, {
            method: 'POST',
            body: JSON.stringify(editPayload),
          });
          if (!resp.ok) {
            failed.push({ row: r, reason: `Trackier ${resp.status}`, body: resp.body });
            continue;
          }
          await Promise.all([
            admin.from("payout_uploads").insert({
              user_id: auth.userId,
              campaign_id: r.campaignId,
              goal_id: r.goalId || null,
              publisher_id: r.publisherId,
              base_payout: r.basePayout,
              adjusted_payout: r.adjustedPayout,
              percentage: r.percentage,
              trackier_response: resp.body as object,
              status: "success",
            }),
            writeAuditLog({
              userId: auth.userId, userEmail: auth.email,
              action: "EDIT_PAYOUT",
              campaignId: r.campaignId, goalId: r.goalId || null,
              publisherId: r.publisherId,
              payload: { basePayout: r.basePayout, adjusted: r.adjustedPayout, percentage: r.percentage, payoutId, matched: matching.length },
            })
          ]);
          success.push(r);
          continue;
        } else if (existingId) {
          failed.push({ row: r, reason: 'Existing payout was detected in the UI, but Trackier did not return that payout for safe overwrite' });
          continue;
        } else {
          console.log('[trackier-upload-payouts] No existing payout matched; creating new payout via payout endpoint:', { path: payoutPath, payload });
        }
      }


      console.log('[trackier-upload-payouts] Creating payout:', { path: payoutPath, payload });
      const resp = await trackierFetch(payoutPath, {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      if (resp.ok) {
        await Promise.all([
          admin.from("payout_uploads").insert({
            user_id: auth.userId,
            campaign_id: r.campaignId,
            goal_id: r.goalId || null,
            publisher_id: r.applyAll ? "__all__" : (r.publisherId as string),
            base_payout: r.basePayout,
            adjusted_payout: r.adjustedPayout,
            percentage: r.percentage,
            trackier_response: resp.body as object,
            status: "success",
          }),
          writeAuditLog({
            userId: auth.userId, userEmail: auth.email,
            action: "UPLOAD_PAYOUT",
            campaignId: r.campaignId, goalId: r.goalId || null,
            publisherId: r.applyAll ? "__all__" : (r.publisherId as string),
            payload: { basePayout: r.basePayout, adjusted: r.adjustedPayout, percentage: r.percentage, applyAll: !!r.applyAll },
          })
        ]);
        success.push(r);
      } else {
        failed.push({ row: r, reason: `Trackier ${resp.status}`, body: resp.body });
      }
    }

    return new Response(JSON.stringify({ success, failed }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
