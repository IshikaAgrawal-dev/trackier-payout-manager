CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE IF NOT EXISTS public.campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trackier_id text NOT NULL UNIQUE,
  title text,
  status text,
  is_active boolean NOT NULL DEFAULT true,
  hash_id text,
  raw jsonb NOT NULL DEFAULT '{}'::jsonb,
  synced_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.publishers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trackier_id text NOT NULL UNIQUE,
  name text,
  hash_id text,
  long_id text,
  status text,
  raw jsonb NOT NULL DEFAULT '{}'::jsonb,
  synced_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.campaign_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_trackier_id text NOT NULL,
  goal_trackier_id text NOT NULL,
  title text,
  payout numeric,
  revenue numeric,
  raw jsonb NOT NULL DEFAULT '{}'::jsonb,
  synced_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (campaign_trackier_id, goal_trackier_id)
);

CREATE TABLE IF NOT EXISTS public.sync_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity text NOT NULL,
  status text NOT NULL DEFAULT 'running',
  records_upserted integer NOT NULL DEFAULT 0,
  error text,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.campaigns TO authenticated;
GRANT ALL ON public.campaigns TO service_role;
GRANT SELECT ON public.publishers TO authenticated;
GRANT ALL ON public.publishers TO service_role;
GRANT SELECT ON public.campaign_goals TO authenticated;
GRANT ALL ON public.campaign_goals TO service_role;
GRANT SELECT ON public.sync_runs TO authenticated;
GRANT ALL ON public.sync_runs TO service_role;

ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.publishers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaign_goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sync_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated read campaigns" ON public.campaigns FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated read publishers" ON public.publishers FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated read campaign goals" ON public.campaign_goals FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated read sync runs" ON public.sync_runs FOR SELECT TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS campaigns_is_active_idx ON public.campaigns (is_active);
CREATE INDEX IF NOT EXISTS campaigns_title_trgm_idx ON public.campaigns USING gin (lower(coalesce(title,'')) gin_trgm_ops);
CREATE INDEX IF NOT EXISTS campaigns_trackier_id_idx ON public.campaigns (trackier_id);
CREATE INDEX IF NOT EXISTS publishers_name_trgm_idx ON public.publishers USING gin (lower(coalesce(name,'')) gin_trgm_ops);
CREATE INDEX IF NOT EXISTS publishers_trackier_id_idx ON public.publishers (trackier_id);
CREATE INDEX IF NOT EXISTS campaign_goals_campaign_idx ON public.campaign_goals (campaign_trackier_id);
CREATE INDEX IF NOT EXISTS sync_runs_entity_started_idx ON public.sync_runs (entity, started_at DESC);

CREATE TRIGGER update_campaigns_updated_at BEFORE UPDATE ON public.campaigns FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_publishers_updated_at BEFORE UPDATE ON public.publishers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_campaign_goals_updated_at BEFORE UPDATE ON public.campaign_goals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();