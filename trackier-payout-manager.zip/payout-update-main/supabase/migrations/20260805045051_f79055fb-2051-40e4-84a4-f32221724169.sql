CREATE INDEX IF NOT EXISTS campaigns_title_trgm2_idx ON public.campaigns USING gin (title extensions.gin_trgm_ops);
CREATE INDEX IF NOT EXISTS campaigns_trackier_id_trgm_idx ON public.campaigns USING gin (trackier_id extensions.gin_trgm_ops);
CREATE INDEX IF NOT EXISTS publishers_name_trgm2_idx ON public.publishers USING gin (name extensions.gin_trgm_ops);
CREATE INDEX IF NOT EXISTS publishers_trackier_id_trgm_idx ON public.publishers USING gin (trackier_id extensions.gin_trgm_ops);
DROP INDEX IF EXISTS public.campaigns_title_trgm_idx;
DROP INDEX IF EXISTS public.publishers_name_trgm_idx;