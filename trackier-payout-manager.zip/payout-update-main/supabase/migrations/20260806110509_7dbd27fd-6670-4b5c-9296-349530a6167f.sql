-- Reference tables: read-only for authenticated, writes only via service role (sync)
REVOKE INSERT, UPDATE, DELETE ON public.campaigns FROM authenticated, anon;
REVOKE INSERT, UPDATE, DELETE ON public.publishers FROM authenticated, anon;
REVOKE INSERT, UPDATE, DELETE ON public.campaign_goals FROM authenticated, anon;
GRANT SELECT ON public.campaigns TO authenticated;
GRANT SELECT ON public.publishers TO authenticated;
GRANT SELECT ON public.campaign_goals TO authenticated;
GRANT ALL ON public.campaigns TO service_role;
GRANT ALL ON public.publishers TO service_role;
GRANT ALL ON public.campaign_goals TO service_role;

-- payout_uploads: inserts happen server-side only
REVOKE INSERT, UPDATE, DELETE ON public.payout_uploads FROM authenticated, anon;
GRANT SELECT ON public.payout_uploads TO authenticated;
GRANT ALL ON public.payout_uploads TO service_role;

-- sync_runs: admins only
DROP POLICY IF EXISTS "Authenticated read sync runs" ON public.sync_runs;
CREATE POLICY "Admins read sync runs"
ON public.sync_runs
FOR SELECT
TO authenticated
USING (private.has_role(auth.uid(), 'admin'::app_role));
REVOKE INSERT, UPDATE, DELETE ON public.sync_runs FROM authenticated, anon;
GRANT SELECT ON public.sync_runs TO authenticated;
GRANT ALL ON public.sync_runs TO service_role;