CREATE TABLE public.campaign_payouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_trackier_id text NOT NULL,
  payout_trackier_id text NOT NULL,
  publisher_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  goal_trackier_id text,
  geo jsonb NOT NULL DEFAULT '[]'::jsonb,
  payout numeric,
  revenue numeric,
  currency text,
  raw jsonb NOT NULL DEFAULT '{}'::jsonb,
  synced_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (campaign_trackier_id, payout_trackier_id)
);

GRANT SELECT ON public.campaign_payouts TO authenticated;
GRANT ALL ON public.campaign_payouts TO service_role;

ALTER TABLE public.campaign_payouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated read campaign payouts"
ON public.campaign_payouts
FOR SELECT
TO authenticated
USING (true);

CREATE INDEX campaign_payouts_campaign_idx ON public.campaign_payouts (campaign_trackier_id);
CREATE INDEX campaign_payouts_publisher_ids_idx ON public.campaign_payouts USING gin (publisher_ids);
CREATE INDEX campaign_payouts_synced_at_idx ON public.campaign_payouts (synced_at DESC);

CREATE TRIGGER update_campaign_payouts_updated_at
BEFORE UPDATE ON public.campaign_payouts
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();