import { build } from "esbuild";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

export type Call = { method: string; path: string; query: string; body: any };
export type Fake = {
  claims: Record<string, unknown> | null;
  admin: boolean;
  tables: Record<string, unknown[]>;
  writes: { table: string; op: string; row: any }[];
};

const FAKE_SUPABASE = `
export function createClient() {
  const g = globalThis.__fake;
  const chain = (table) => new Proxy(function () {}, {
    get(_t, prop) {
      if (prop === "then") return (res) => res({ data: g.tables[table] || [], error: null });
      if (prop === "insert" || prop === "upsert") return (row) => { g.writes.push({ table, op: String(prop), row }); return chain(table); };
      if (prop === "maybeSingle") return async () => ({ data: table === "user_roles" && g.admin ? { role: "admin" } : null, error: null });
      return () => chain(table);
    },
  });
  return {
    auth: { getClaims: async () => g.claims ? { data: { claims: g.claims }, error: null } : { data: null, error: { message: "bad token" } } },
    from: (table) => chain(table),
  };
}`;

export const state = { calls: [] as Call[], router: (() => new Response("{}")) as (c: Call) => Response | Promise<Response> };
export const fake: Fake = { claims: { sub: "user-1", email: "ops@example.com" }, admin: true, tables: {}, writes: [] };

export function reset() {
  state.calls = []; state.router = () => new Response("{}");
  fake.claims = { sub: "user-1", email: "ops@example.com" }; fake.admin = true; fake.tables = {}; fake.writes = [];
}
export const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status });

let installed = false;
function installGlobals() {
  if (installed) return; installed = true;
  const env: Record<string, string> = { TRACKIER_API_KEY: "test-key", TRACKIER_BASE_URL: "https://trackier.test/v2", SUPABASE_URL: "https://proj.supabase.co", SUPABASE_ANON_KEY: "anon", SUPABASE_SERVICE_ROLE_KEY: "service" };
  (globalThis as any).Deno = { env: { get: (k: string) => env[k] }, serve: (h: unknown) => { (globalThis as any).__handler = h; } };
  (globalThis as any).__fake = fake;
  (globalThis as any).fetch = async (url: string, init?: RequestInit) => {
    const u = new URL(url);
    const call: Call = { method: init?.method || "GET", path: u.pathname.replace(/^\/v2/, ""), query: u.search, body: init?.body ? JSON.parse(String(init.body)) : null };
    state.calls.push(call);
    return state.router(call);
  };
}

export async function loadHandler(fn: string): Promise<(req: Request) => Promise<Response>> {
  installGlobals();
  const dir = mkdtempSync(join(tmpdir(), "edge-"));
  const fakeFile = join(dir, "fake-supabase.mjs"); writeFileSync(fakeFile, FAKE_SUPABASE);
  const out = await build({
    entryPoints: [resolve("supabase/functions", fn, "index.ts")], bundle: true, write: false, format: "esm", platform: "node", logLevel: "silent",
    plugins: [{ name: "stub-esm-sh", setup(b) { b.onResolve({ filter: /^https:\/\/esm\.sh\// }, () => ({ path: fakeFile })); } }],
  });
  const file = join(dir, "fn.mjs"); writeFileSync(file, out.outputFiles[0].text);
  (globalThis as any).__handler = undefined;
  await import(pathToFileURL(file).href);
  return (globalThis as any).__handler;
}

export const req = (body: unknown, auth = true) =>
  new Request("http://localhost/fn", { method: "POST", headers: { "Content-Type": "application/json", ...(auth ? { Authorization: "Bearer test-token" } : {}) }, body: JSON.stringify(body) });

export const isCreate = (c: Call) => c.method === "POST" && /^\/campaigns\/\d+\/payouts$/.test(c.path);
export const isEdit = (c: Call) => c.method === "POST" && /^\/campaigns\/\d+\/payouts\/[^/]+$/.test(c.path);
