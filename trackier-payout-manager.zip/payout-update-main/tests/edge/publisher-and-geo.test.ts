import { beforeAll, beforeEach, describe, expect, it } from "vitest";
import { fake, isCreate, isEdit, json, loadHandler, req, reset, state, type Call } from "./harness";

describe("campaign-publisher-action: assignment is separate from payouts", () => {
  let handler: (r: Request) => Promise<Response>;
  beforeAll(async () => { handler = await loadHandler("campaign-publisher-action"); });
  beforeEach(() => { reset(); state.router = () => json({ success: true }); });

  it.each(["assign", "remove", "block", "unblock"])("%s only calls POST /campaigns/access and never a payout endpoint", async (type) => {
    const res = await handler(req({ campaign_ids: [101, 102], publisher_ids: [679], type }));
    expect((await res.json()).ok).toBe(true);
    expect(state.calls).toHaveLength(1);
    expect(state.calls[0]).toMatchObject({ method: "POST", path: "/campaigns/access" });
    expect(state.calls[0].body).toEqual({ campaign_ids: [101, 102], publisher_ids: [679], type });
    expect(state.calls.some((c) => /payouts/.test(c.path))).toBe(false);
    expect(fake.writes.some((w) => w.table === "audit_logs" && w.row.action === `${type.toUpperCase()}_PUBLISHER`)).toBe(true);
  });

  it("rejects unknown actions and requires auth", async () => {
    expect((await handler(req({ campaign_ids: [1], publisher_ids: [2], type: "setPayout" }))).status).toBe(400);
    expect((await handler(req({ campaign_ids: [1], publisher_ids: [2], type: "assign" }, false))).status).toBe(401);
    expect(state.calls).toHaveLength(0);
  });

  it("reports Trackier rejection as ok=false (never a fake success)", async () => {
    state.router = () => json({ error: "nope" }, 400);
    const body = await (await handler(req({ campaign_ids: [1], publisher_ids: [2], type: "assign" }))).json();
    expect(body.ok).toBe(false); expect(body.requestsFailed).toBe(1);
  });
});

describe("trackier-geo-migration: geo-only edits of existing payouts", () => {
  let handler: (r: Request) => Promise<Response>;
  beforeAll(async () => { handler = await loadHandler("trackier-geo-migration"); });
  beforeEach(() => reset());
  const existing = { _id: "pay-1", pubIds: ["hashA"], goalId: "g1", geo: ["ALL"], payout: 42, revenue: 5, currency: "INR" };
  const trackier = (payouts: unknown[], postStatus = 200) => {
    state.router = (c: Call) => c.method === "GET" ? json({ data: payouts }) : json({ ok: true }, postStatus);
  };

  it("is admin only", async () => {
    fake.admin = false; trackier([existing]);
    const res = await handler(req({ action: "apply", rows: [{ campaignId: "101", payoutId: "pay-1", targetGeo: "IN" }] }));
    expect(res.status).toBe(403); expect(state.calls).toHaveLength(0);
  });

  it("apply edits only geo by payout id, preserving value, publishers and goal; never creates", async () => {
    trackier([existing]);
    const body = await (await handler(req({ action: "apply", rows: [{ campaignId: "101", payoutId: "pay-1", targetGeo: "IN" }] }))).json();
    expect(body.success).toHaveLength(1);
    const posts = state.calls.filter((c) => c.method === "POST");
    expect(posts).toHaveLength(1);
    expect(posts[0].path).toBe("/campaigns/101/payouts/pay-1");
    expect(posts[0].body).toMatchObject({ payout: 42, revenue: 5, geo: ["IN"], pubIds: ["hashA"], goalId: "g1" });
    expect(state.calls.some(isCreate)).toBe(false);
    expect(fake.writes.some((w) => w.row.action === "GEO_MIGRATION" && w.row.payload.fromGeo === "ALL" && w.row.payload.toGeo === "IN")).toBe(true);
  });

  it("payout already on the target geo is skipped without a write", async () => {
    trackier([{ ...existing, geo: ["IN"] }]);
    const body = await (await handler(req({ action: "apply", rows: [{ campaignId: "101", payoutId: "pay-1", targetGeo: "IN" }] }))).json();
    expect(body.skipped).toHaveLength(1); expect(state.calls.filter((c) => c.method === "POST")).toHaveLength(0);
  });

  it("failed edit is reported as failed and nothing is created", async () => {
    trackier([existing], 500);
    const body = await (await handler(req({ action: "apply", rows: [{ campaignId: "101", payoutId: "pay-1", targetGeo: "IN" }] }))).json();
    expect(body.failed).toHaveLength(1); expect(body.success).toHaveLength(0);
    expect(state.calls.some(isCreate)).toBe(false);
  });

  it("unknown payout id fails without any write; invalid target geo is rejected", async () => {
    trackier([existing]);
    const body = await (await handler(req({ action: "apply", rows: [{ campaignId: "101", payoutId: "ghost", targetGeo: "IN" }] }))).json();
    expect(body.failed).toHaveLength(1); expect(state.calls.filter((c) => c.method === "POST")).toHaveLength(0);
    const bad = await handler(req({ action: "apply", rows: [{ campaignId: "101", payoutId: "pay-1", targetGeo: "US" }] }));
    expect(bad.status).toBe(400);
  });

  it("preview is read-only", async () => {
    trackier([existing]);
    await handler(req({ action: "preview", campaignIds: ["101"] }));
    expect(state.calls.every((c) => c.method === "GET")).toBe(true);
    expect(state.calls.some(isEdit) || state.calls.some(isCreate)).toBe(false);
  });
});
