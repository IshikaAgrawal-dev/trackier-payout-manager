import { beforeAll, beforeEach, describe, expect, it } from "vitest";
import { fake, isCreate, isEdit, json, loadHandler, req, reset, state, type Call } from "./harness";

let handler: (r: Request) => Promise<Response>;
beforeAll(async () => { handler = await loadHandler("trackier-upload-payouts"); });
beforeEach(() => { reset(); });

const row = (o: Record<string, unknown> = {}) => ({
  campaignId: "101", goalId: undefined, publisherId: "679", publisherMatchIds: ["679", "hashA"],
  basePayout: 100, adjustedPayout: 75, percentage: 75, geo: ["ALL"], ...o,
});
const P = (o: Record<string, unknown> = {}) => ({ _id: "pay-1", pubIds: ["hashA"], goalId: undefined, geo: ["ALL"], payout: 50, revenue: 0, currency: "INR", ...o });

// Trackier stub: GET /campaigns/101 returns these payouts; POSTs answer per `postStatus`.
function trackier(payouts: unknown[], postStatus = 200) {
  state.router = (c: Call) => {
    if (c.method === "GET" && c.path === "/campaigns/101") return json({ payouts });
    if (c.method === "GET") return json({ data: payouts });
    return json({ ok: postStatus < 400 }, postStatus);
  };
}
const run = async (rows: unknown[]) => {
  const res = await handler(req({ rows }));
  return { status: res.status, body: await res.json() as { success: any[]; failed: any[] } };
};

describe("trackier-upload-payouts: payout safety rules (real edge-function code)", () => {
  it("requires an authenticated user", async () => {
    const res = await handler(req({ rows: [row()] }, false));
    expect(res.status).toBe(401); expect(state.calls).toHaveLength(0);
  });

  it("identical existing payout => Duplicate, skipped, nothing written to Trackier", async () => {
    trackier([P({ payout: 75 })]);
    const { body } = await run([row()]);
    expect(body.success[0].skipped).toBe("duplicate");
    expect(state.calls.filter((c) => c.method === "POST")).toHaveLength(0);
    expect(fake.writes).toHaveLength(0);
  });

  it("matching payout with a different value => edited by its real Trackier payout id, never created", async () => {
    trackier([P({ _id: "pay-1", payout: 50 })]);
    const { body } = await run([row()]);
    expect(body.failed).toHaveLength(0); expect(body.success).toHaveLength(1);
    const posts = state.calls.filter((c) => c.method === "POST");
    expect(posts).toHaveLength(1);
    expect(posts[0].path).toBe("/campaigns/101/payouts/pay-1");
    expect(posts[0].body).toMatchObject({ payout: 75, geo: ["ALL"], pubIds: ["hashA"] });
    expect(state.calls.some(isCreate)).toBe(false);
    expect(fake.writes.some((w) => w.table === "audit_logs" && w.row.action === "EDIT_PAYOUT" && w.row.payload.payoutId === "pay-1")).toBe(true);
  });

  it("failed update => reported as failed and NO replacement payout is created", async () => {
    trackier([P({ payout: 50 })], 500);
    const { body } = await run([row()]);
    expect(body.success).toHaveLength(0); expect(body.failed).toHaveLength(1);
    expect(state.calls.some(isCreate)).toBe(false);
    expect(state.calls.filter(isEdit)).toHaveLength(1);
    expect(fake.writes.filter((w) => w.table === "audit_logs")).toHaveLength(0);
  });

  it("default campaign payout (no pubIds) is never matched or edited", async () => {
    trackier([P({ _id: "default-1", pubIds: [], payout: 10 })]);
    const { body } = await run([row()]);
    expect(state.calls.some((c) => c.path.endsWith("/payouts/default-1"))).toBe(false);
    expect(state.calls.filter(isEdit)).toHaveLength(0);
    // no publisher-specific payout exists, so a NEW publisher-specific payout is created for this publisher only
    const create = state.calls.filter(isCreate);
    expect(create).toHaveLength(1);
    expect(create[0].body.pubIds).toEqual([679]);
    expect(body.success[0]).toMatchObject({ publisherId: "679" });
  });

  it("IN is never ALL: existing ALL payout is untouched when IN is requested", async () => {
    trackier([P({ _id: "all-1", geo: ["ALL"], payout: 50 })]);
    await run([row({ geo: ["IN"] })]);
    expect(state.calls.some((c) => c.path.endsWith("/payouts/all-1"))).toBe(false);
    const create = state.calls.filter(isCreate);
    expect(create).toHaveLength(1); expect(create[0].body.geo).toEqual(["IN"]);
  });

  it("IN is never ALL: existing IN payout is untouched when ALL is requested", async () => {
    trackier([P({ _id: "in-1", geo: ["IN"], payout: 50 })]);
    await run([row({ geo: ["ALL"] })]);
    expect(state.calls.some((c) => c.path.endsWith("/payouts/in-1"))).toBe(false);
    expect(state.calls.filter(isCreate)[0].body.geo).toEqual(["ALL"]);
  });

  it("exact geo match is edited in place even when other geos exist", async () => {
    trackier([P({ _id: "all-1", geo: ["ALL"], payout: 50 }), P({ _id: "in-1", geo: ["IN"], payout: 60 })]);
    await run([row({ geo: ["IN"] })]);
    expect(state.calls.filter(isEdit).map((c) => c.path)).toEqual(["/campaigns/101/payouts/in-1"]);
    expect(state.calls.some(isCreate)).toBe(false);
  });

  it("goal must match: a default-goal payout is not edited for a real goal", async () => {
    trackier([P({ _id: "g-none", goalId: undefined, payout: 50 })]);
    await run([row({ goalId: "g1" })]);
    expect(state.calls.some((c) => c.path.endsWith("/payouts/g-none"))).toBe(false);
    expect(state.calls.filter(isCreate)[0].body.goalId).toBe("g1");
  });

  it("UI says an existing payout was found but Trackier does not return it => failed, not created", async () => {
    trackier([]);
    const { body } = await run([row({ existingPayoutId: "ghost" })]);
    expect(body.failed).toHaveLength(1); expect(body.success).toHaveLength(0);
    expect(state.calls.some(isCreate)).toBe(false);
  });

  it("UI-supplied payout id with a different geo is not edited", async () => {
    trackier([P({ _id: "all-1", geo: ["ALL"], payout: 50 })]);
    const { body } = await run([row({ geo: ["IN"], existingPayoutId: "all-1" })]);
    expect(state.calls.some((c) => c.path.endsWith("/payouts/all-1"))).toBe(false);
    expect(body.failed).toHaveLength(1);
    expect(state.calls.some(isCreate)).toBe(false);
  });

  it("matched payout without a Trackier _id => refuses to fall back to create", async () => {
    trackier([{ pubIds: ["hashA"], geo: ["ALL"], payout: 50 }]);
    const { body } = await run([row()]);
    expect(body.failed).toHaveLength(1);
    expect(state.calls.some(isCreate)).toBe(false);
  });

  it("cannot load campaign payouts => failed, nothing created", async () => {
    state.router = () => json({ error: "down" }, 500);
    const { body } = await run([row()]);
    expect(body.failed).toHaveLength(1); expect(body.success).toHaveLength(0);
    expect(state.calls.some(isCreate)).toBe(false);
  });

  it("resolves the publisher's hash id from the cache so numeric ids match Trackier pubIds", async () => {
    fake.tables.publishers = [{ trackier_id: "679", hash_id: "hashZ", long_id: null, raw: {} }];
    trackier([P({ _id: "pay-9", pubIds: ["hashZ"], payout: 50 })]);
    await run([row({ publisherMatchIds: [] })]);
    expect(state.calls.filter(isEdit).map((c) => c.path)).toEqual(["/campaigns/101/payouts/pay-9"]);
    expect(state.calls.some(isCreate)).toBe(false);
  });

  it("no matching payout (after a live re-check) => creates one publisher-specific payout", async () => {
    trackier([]);
    const { body } = await run([row()]);
    expect(body.success).toHaveLength(1);
    const create = state.calls.filter(isCreate);
    expect(create).toHaveLength(1);
    expect(create[0].body).toMatchObject({ payout: 75, geo: ["ALL"], pubIds: [679], currency: "INR" });
    // the live re-check refetched payouts before creating
    expect(state.calls.filter((c) => c.method === "GET" && c.path === "/campaigns/101").length).toBeGreaterThanOrEqual(2);
  });

  it("the Trackier API key is only sent to Trackier, never returned to the caller", async () => {
    trackier([P({ payout: 50 })]);
    const res = await handler(req({ rows: [row()] }));
    expect(await res.text()).not.toContain("test-key");
  });
});
