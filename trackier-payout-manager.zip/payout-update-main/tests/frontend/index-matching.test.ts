import { describe, expect, it } from "vitest";
import { transformSync } from "esbuild";
import { readFileSync } from "node:fs";

// Loads the REAL matching/status helpers straight out of src/pages/Index.tsx (no copy), so this test
// breaks if the console's classification rules change.
const src = readFileSync("src/pages/Index.tsx", "utf8");
const start = src.indexOf("type RowStatus");
const end = src.indexOf("const Index = () => {");
if (start < 0 || end < 0) throw new Error("Index.tsx structure changed: update this test's slice markers");
const code = transformSync(
  src.slice(start, end) + "\nexport { findExistingPayout, computeStatus, requestedGeosFor, normalizeGeo };",
  { loader: "ts", format: "cjs" },
).code;
const mod: { exports: any } = { exports: {} };
new Function("module", "exports", "console", code)(mod, mod.exports, { log() {} });
const { findExistingPayout, computeStatus, requestedGeosFor } = mod.exports;

const P = (o: Record<string, unknown> = {}) => ({ id: "p1", pubIds: ["hashA"], goalId: null, geo: ["ALL"], payout: 50, revenue: 0, currency: "INR", ...o });
const ids = ["679", "hashA"];

describe("console classification (real code from Index.tsx)", () => {
  it("identical value => duplicate; different value => will_update; no match => new", () => {
    expect(computeStatus(P({ payout: 75 }), 75)).toBe("duplicate");
    expect(computeStatus(P({ payout: 50 }), 75)).toBe("will_update");
    expect(computeStatus(undefined, 75)).toBe("new");
  });
  it("default payout (no pubIds) is never matched", () => {
    expect(findExistingPayout([P({ pubIds: [] })], ids, null, 50, ["ALL"])).toBeUndefined();
  });
  it("IN and ALL are never interchangeable", () => {
    expect(findExistingPayout([P({ geo: ["ALL"] })], ids, null, 50, ["IN"])).toBeUndefined();
    expect(findExistingPayout([P({ geo: ["IN"] })], ids, null, 50, ["ALL"])).toBeUndefined();
    expect(findExistingPayout([P({ geo: ["IN"] })], ids, null, 50, ["IN"])?.id).toBe("p1");
  });
  it("matches by publisher hash id and by goal", () => {
    expect(findExistingPayout([P({ goalId: "g1" })], ids, "g1", 50, ["ALL"])?.id).toBe("p1");
    expect(findExistingPayout([P({ goalId: "g1" })], ids, null, 50, ["ALL"])).toBeUndefined();
    expect(findExistingPayout([P({ pubIds: ["someoneElse"] })], ids, null, 50, ["ALL"])).toBeUndefined();
  });
  it("requestedGeosFor reuses each existing exact geo, falls back to ALL only when none exist", () => {
    expect(requestedGeosFor([P({ geo: ["IN"] }), P({ id: "p2", geo: ["ALL"] })], ids, null)).toEqual([["ALL"], ["IN"]]);
    expect(requestedGeosFor([], ids, null)).toEqual([["ALL"]]);
  });
  it("exposes the existing Trackier payout id for will_update rows", () => {
    expect(findExistingPayout([P({ id: "real-trackier-id", payout: 10 })], ids, null, 75, ["ALL"])?.id).toBe("real-trackier-id");
  });
});

describe("console upload wiring (static checks on Index.tsx)", () => {
  it("sends the existing payout id and exact geo, skips duplicates, and only calls the upload function", () => {
    expect(src).toMatch(/existingPayoutId:\s*r\.existingPayoutId \|\| undefined/);
    expect(src).toMatch(/geo:\s*r\.geo \?\? \["ALL"\]/);
    expect(src).toMatch(/rows\.filter\(\(r\) => r\.status !== "duplicate"\)/);
    expect(src).toMatch(/functions\.invoke\("trackier-upload-payouts"/);
  });
  it("publisher assignment only calls campaign-publisher-action and never sends payout values", () => {
    const m = src.match(/const handlePublisherAction = async[\s\S]*?\n  };/);
    expect(m).toBeTruthy();
    const body = m![0];
    expect(body).toMatch(/functions\.invoke\("campaign-publisher-action"/);
    expect(body).not.toMatch(/adjusted|percentage|trackier-upload-payouts|basePayout/);
  });
});
