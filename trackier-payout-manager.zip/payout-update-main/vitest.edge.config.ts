import { defineConfig } from "vitest/config";

// Runs the REAL Supabase edge-function source (supabase/functions/**) in Node with Deno, Supabase and Trackier stubbed,
// to verify the payout safety rules. Does not touch the network or any real credential.
export default defineConfig({
  test: { environment: "node", include: ["tests/**/*.test.ts"], testTimeout: 30000, silent: true },
});
